<?php
defined('BASEPATH') or exit('No direct script access allowed');
date_default_timezone_set("Asia/Jakarta");

class Metode_jadwal
{
    function nama_jadwal($nama_jadwal)
    {
        
    }
}
