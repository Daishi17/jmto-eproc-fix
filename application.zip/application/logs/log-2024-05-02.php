<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2024-05-02 11:45:49 --> Severity: Notice --> Trying to get property 'nip' of non-object C:\laragon\www\jmto-eproc\application\libraries\Role_login.php 21
ERROR - 2024-05-02 04:50:03 --> 404 Page Not Found: Assets/swa2.min.js
ERROR - 2024-05-02 13:45:16 --> Severity: error --> Exception: Too few arguments to function Daftar_paket::by_id_rup(), 0 passed in C:\laragon\www\jmto-eproc\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 388
ERROR - 2024-05-02 21:59:11 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_rkap\M_rkap.php 19
ERROR - 2024-05-02 21:59:11 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_rkap\M_rkap.php 19
ERROR - 2024-05-02 21:59:11 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_rkap\M_rkap.php 19
ERROR - 2024-05-02 21:59:11 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_rkap\M_rkap.php 19
ERROR - 2024-05-02 21:59:11 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_rkap\M_rkap.php 19
ERROR - 2024-05-02 21:59:11 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_rkap\M_rkap.php 19
ERROR - 2024-05-02 21:59:11 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_rkap\M_rkap.php 19
ERROR - 2024-05-02 21:59:11 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_rkap\M_rkap.php 19
ERROR - 2024-05-02 21:59:11 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_rkap\M_rkap.php 19
ERROR - 2024-05-02 21:59:11 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_rkap\M_rkap.php 19
ERROR - 2024-05-02 21:59:11 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_rkap\M_rkap.php 19
ERROR - 2024-05-02 21:59:11 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_rkap\M_rkap.php 19
ERROR - 2024-05-02 21:59:11 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_rkap\M_rkap.php 19
ERROR - 2024-05-02 21:59:11 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_rkap\M_rkap.php 19
ERROR - 2024-05-02 21:59:11 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_rkap\M_rkap.php 19
ERROR - 2024-05-02 21:59:11 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_rkap\M_rkap.php 19
ERROR - 2024-05-02 21:59:11 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_rkap\M_rkap.php 19
ERROR - 2024-05-02 21:59:11 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_rkap\M_rkap.php 19
ERROR - 2024-05-02 21:59:11 --> Severity: Notice --> Undefined index: length C:\laragon\www\jmto-eproc\application\models\M_rkap\M_rkap.php 48
ERROR - 2024-05-02 21:59:11 --> Severity: Notice --> Undefined index: length C:\laragon\www\jmto-eproc\application\models\M_rkap\M_rkap.php 49
ERROR - 2024-05-02 21:59:11 --> Severity: Notice --> Undefined index: start C:\laragon\www\jmto-eproc\application\models\M_rkap\M_rkap.php 49
ERROR - 2024-05-02 21:59:11 --> Severity: Notice --> Undefined index: start C:\laragon\www\jmto-eproc\application\controllers\administrator\Sirup_rka.php 61
ERROR - 2024-05-02 21:59:11 --> Severity: Notice --> Undefined index: draw C:\laragon\www\jmto-eproc\application\controllers\administrator\Sirup_rka.php 96
ERROR - 2024-05-02 21:59:12 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_rkap\M_rkap.php 19
ERROR - 2024-05-02 21:59:12 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_rkap\M_rkap.php 19
ERROR - 2024-05-02 21:59:12 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_rkap\M_rkap.php 19
ERROR - 2024-05-02 21:59:12 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_rkap\M_rkap.php 19
ERROR - 2024-05-02 21:59:12 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_rkap\M_rkap.php 19
ERROR - 2024-05-02 21:59:12 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_rkap\M_rkap.php 19
ERROR - 2024-05-02 21:59:12 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_rkap\M_rkap.php 19
ERROR - 2024-05-02 21:59:12 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_rkap\M_rkap.php 19
ERROR - 2024-05-02 21:59:12 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_rkap\M_rkap.php 19
ERROR - 2024-05-02 21:59:12 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_rkap\M_rkap.php 19
ERROR - 2024-05-02 21:59:12 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_rkap\M_rkap.php 19
ERROR - 2024-05-02 21:59:12 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_rkap\M_rkap.php 19
ERROR - 2024-05-02 21:59:12 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_rkap\M_rkap.php 19
ERROR - 2024-05-02 21:59:12 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_rkap\M_rkap.php 19
ERROR - 2024-05-02 21:59:12 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_rkap\M_rkap.php 19
ERROR - 2024-05-02 21:59:12 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_rkap\M_rkap.php 19
ERROR - 2024-05-02 21:59:12 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_rkap\M_rkap.php 19
ERROR - 2024-05-02 21:59:12 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_rkap\M_rkap.php 19
