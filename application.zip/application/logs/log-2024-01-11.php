<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2024-01-11 12:40:51 --> 404 Page Not Found: panitia/info_tender/Informasi_tender_terbatas_pra_1_file/ba_penjelasan_kualifiaksi
ERROR - 2024-01-11 12:41:08 --> 404 Page Not Found: panitia/info_tender/Informasi_tender_terbatas_pra_1_file/ba_penjelasan_kualifiaksi
ERROR - 2024-01-11 12:45:48 --> Severity: error --> Exception: Call to undefined method M_panitia::cek_direktur_utama() C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_terbatas_pra_1_file.php 2435
ERROR - 2024-01-11 12:45:59 --> Severity: error --> Exception: Call to undefined method M_panitia::cek_direktur_utama() C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_terbatas_pra_1_file.php 2435
ERROR - 2024-01-11 12:52:18 --> 404 Page Not Found: panitia/info_tender/Informasi_tender_terbatas_pra_1_file/save_status_kirim
ERROR - 2024-01-11 14:56:04 --> Severity: Notice --> Trying to get property 'nip' of non-object C:\laragon\www\jmto-eproc\application\libraries\Role_login.php 21
ERROR - 2024-01-11 23:15:33 --> Severity: error --> Exception: Too few arguments to function Daftar_paket::by_id_rup(), 0 passed in C:\laragon\www\jmto-eproc\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 388
ERROR - 2024-01-11 23:48:06 --> Severity: error --> Exception: Too few arguments to function Daftar_paket::by_id_rup(), 0 passed in C:\laragon\www\jmto-eproc\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 388
ERROR - 2024-01-11 16:54:23 --> 404 Page Not Found: panitia/daftar_paket/Setujui_pakta_integritas/index
ERROR - 2024-01-11 23:57:47 --> Query error: Unknown column 'id_rup_global' in 'where clause' - Invalid query: UPDATE `tbl_panitia` SET `sts_pakta_integritas` = 1
WHERE `id_manajemen_user` = '26'
AND `id_rup_global` = '208'
ERROR - 2024-01-11 23:59:15 --> Severity: error --> Exception: Too few arguments to function Daftar_paket::by_id_rup(), 0 passed in C:\laragon\www\jmto-eproc\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 388
