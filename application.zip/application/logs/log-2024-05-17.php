<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2024-05-17 13:35:41 --> Query error: Unknown column 'NAN' in 'field list' - Invalid query: UPDATE `tbl_vendor` SET `nilai_vendor` = NAN
WHERE `id_vendor` = '123'
ERROR - 2024-05-17 13:37:39 --> Query error: Unknown column 'NAN' in 'field list' - Invalid query: UPDATE `tbl_vendor` SET `nilai_vendor` = NAN
WHERE `id_vendor` = '123'
ERROR - 2024-05-17 13:39:58 --> Query error: Unknown column 'NAN' in 'field list' - Invalid query: UPDATE `tbl_vendor` SET `nilai_vendor` = NAN
WHERE `id_vendor` = '123'
ERROR - 2024-05-17 13:41:14 --> Query error: Unknown column 'NAN' in 'field list' - Invalid query: UPDATE `tbl_vendor` SET `nilai_vendor` = NAN
WHERE `id_vendor` = '123'
ERROR - 2024-05-17 13:41:32 --> Query error: Unknown column 'NAN' in 'field list' - Invalid query: UPDATE `tbl_vendor` SET `nilai_vendor` = NAN
WHERE `id_vendor` = '123'
ERROR - 2024-05-17 13:43:41 --> Severity: error --> Exception: Too few arguments to function Penilaian_kinerja::print_pelaksanaan_satgas(), 0 passed in C:\laragon\www\jmto-eproc\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\laragon\www\jmto-eproc\application\controllers\administrator\Penilaian_kinerja.php 1028
ERROR - 2024-05-17 13:45:01 --> Query error: Column 'id_rup' in order clause is ambiguous - Invalid query: SELECT *
FROM `tbl_vendor_mengikuti_paket`
LEFT JOIN `tbl_rup` ON `tbl_rup`.`id_rup` = `tbl_vendor_mengikuti_paket`.`id_rup`
LEFT JOIN `tbl_vendor` ON `tbl_vendor`.`id_vendor` = `tbl_vendor_mengikuti_paket`.`id_vendor`
LEFT JOIN `tbl_departemen` ON `tbl_rup`.`id_departemen` = `tbl_departemen`.`id_departemen`
LEFT JOIN `tbl_section` ON `tbl_rup`.`id_section` = `tbl_section`.`id_section`
LEFT JOIN `tbl_rkap` ON `tbl_rup`.`id_rkap` = `tbl_rkap`.`id_rkap`
LEFT JOIN `tbl_provinsi` ON `tbl_rup`.`id_provinsi` = `tbl_provinsi`.`id_provinsi`
LEFT JOIN `tbl_kabupaten` ON `tbl_rup`.`id_kabupaten` = `tbl_kabupaten`.`id_kabupaten`
LEFT JOIN `tbl_jenis_pengadaan` ON `tbl_rup`.`id_jenis_pengadaan` = `tbl_jenis_pengadaan`.`id_jenis_pengadaan`
LEFT JOIN `tbl_metode_pengadaan` ON `tbl_rup`.`id_metode_pengadaan` = `tbl_metode_pengadaan`.`id_metode_pengadaan`
LEFT JOIN `tbl_jenis_anggaran` ON `tbl_rup`.`id_jenis_anggaran` = `tbl_jenis_anggaran`.`id_jenis_anggaran`
LEFT JOIN `mst_ruas` ON `tbl_rup`.`id_ruas` = `mst_ruas`.`id_ruas`
WHERE `tbl_rup`.`status_paket_diumumkan` = 1
AND `tbl_rup`.`id_metode_pengadaan` = 4
AND `tbl_rup`.`id_vendor_pemenang` IS NOT NULL
AND `tbl_rup`.`id_jadwal_tender` IN(1, 2, 3, 6)
GROUP BY `tbl_vendor_mengikuti_paket`.`id_rup`
ORDER BY `id_rup` ASC
 LIMIT 10
ERROR - 2024-05-17 13:45:04 --> Query error: Unknown column 'NAN' in 'field list' - Invalid query: UPDATE `tbl_vendor` SET `nilai_vendor` = NAN
WHERE `id_vendor` = '123'
ERROR - 2024-05-17 15:10:48 --> Severity: error --> Exception: Too few arguments to function Daftar_paket::by_id_rup(), 0 passed in C:\laragon\www\jmto-eproc\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 388
ERROR - 2024-05-17 15:10:59 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 2111
ERROR - 2024-05-17 15:10:59 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 2112
ERROR - 2024-05-17 15:11:03 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 2111
ERROR - 2024-05-17 15:11:03 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 2112
