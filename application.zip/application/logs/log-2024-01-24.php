<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2024-01-24 00:03:25 --> Severity: error --> Exception: Too few arguments to function Daftar_paket::by_id_rup(), 0 passed in C:\laragon\www\jmto-eproc\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 388
ERROR - 2024-01-24 01:20:42 --> Unable to connect to the database
ERROR - 2024-01-24 01:51:48 --> Unable to connect to the database
