<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2024-01-24 00:07:24 --> Severity: Notice --> Undefined variable: jadwal_selesai C:\xampp\htdocs\jmto-eproc-fix\application\controllers\post_jadwal\Post_jadwal.php 433
ERROR - 2024-01-24 00:07:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc-fix\application\controllers\post_jadwal\Post_jadwal.php 433
ERROR - 2024-01-24 00:07:24 --> Severity: Notice --> Undefined variable: jadwal_selesai C:\xampp\htdocs\jmto-eproc-fix\application\controllers\post_jadwal\Post_jadwal.php 433
ERROR - 2024-01-24 00:07:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc-fix\application\controllers\post_jadwal\Post_jadwal.php 433
ERROR - 2024-01-24 00:07:25 --> Severity: Notice --> Undefined variable: jadwal_selesai C:\xampp\htdocs\jmto-eproc-fix\application\controllers\post_jadwal\Post_jadwal.php 433
ERROR - 2024-01-24 00:07:25 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc-fix\application\controllers\post_jadwal\Post_jadwal.php 433
ERROR - 2024-01-24 00:07:25 --> Severity: Notice --> Undefined variable: jadwal_selesai C:\xampp\htdocs\jmto-eproc-fix\application\controllers\post_jadwal\Post_jadwal.php 433
ERROR - 2024-01-24 00:07:25 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc-fix\application\controllers\post_jadwal\Post_jadwal.php 433
ERROR - 2024-01-24 00:07:25 --> Severity: Notice --> Undefined variable: jadwal_selesai C:\xampp\htdocs\jmto-eproc-fix\application\controllers\post_jadwal\Post_jadwal.php 433
ERROR - 2024-01-24 00:07:25 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc-fix\application\controllers\post_jadwal\Post_jadwal.php 433
ERROR - 2024-01-24 00:07:25 --> Severity: Notice --> Undefined variable: jadwal_selesai C:\xampp\htdocs\jmto-eproc-fix\application\controllers\post_jadwal\Post_jadwal.php 433
ERROR - 2024-01-24 00:07:25 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc-fix\application\controllers\post_jadwal\Post_jadwal.php 433
ERROR - 2024-01-24 00:07:25 --> Severity: Notice --> Undefined variable: jadwal_selesai C:\xampp\htdocs\jmto-eproc-fix\application\controllers\post_jadwal\Post_jadwal.php 433
ERROR - 2024-01-24 00:07:25 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc-fix\application\controllers\post_jadwal\Post_jadwal.php 433
ERROR - 2024-01-24 00:07:25 --> Severity: Notice --> Undefined variable: jadwal_selesai C:\xampp\htdocs\jmto-eproc-fix\application\controllers\post_jadwal\Post_jadwal.php 433
ERROR - 2024-01-24 00:07:25 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc-fix\application\controllers\post_jadwal\Post_jadwal.php 433
ERROR - 2024-01-24 00:07:25 --> Severity: Notice --> Undefined variable: jadwal_selesai C:\xampp\htdocs\jmto-eproc-fix\application\controllers\post_jadwal\Post_jadwal.php 433
ERROR - 2024-01-24 00:07:25 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc-fix\application\controllers\post_jadwal\Post_jadwal.php 433
ERROR - 2024-01-24 00:07:25 --> Severity: Notice --> Undefined variable: jadwal_selesai C:\xampp\htdocs\jmto-eproc-fix\application\controllers\post_jadwal\Post_jadwal.php 433
ERROR - 2024-01-24 00:07:25 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc-fix\application\controllers\post_jadwal\Post_jadwal.php 433
ERROR - 2024-01-24 00:07:25 --> Severity: Notice --> Undefined variable: jadwal_selesai C:\xampp\htdocs\jmto-eproc-fix\application\controllers\post_jadwal\Post_jadwal.php 433
ERROR - 2024-01-24 00:07:25 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc-fix\application\controllers\post_jadwal\Post_jadwal.php 433
ERROR - 2024-01-24 00:07:25 --> Severity: Notice --> Undefined variable: jadwal_selesai C:\xampp\htdocs\jmto-eproc-fix\application\controllers\post_jadwal\Post_jadwal.php 433
ERROR - 2024-01-24 00:07:25 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc-fix\application\controllers\post_jadwal\Post_jadwal.php 433
ERROR - 2024-01-24 00:07:25 --> Severity: Notice --> Undefined variable: jadwal_selesai C:\xampp\htdocs\jmto-eproc-fix\application\controllers\post_jadwal\Post_jadwal.php 433
ERROR - 2024-01-24 00:07:25 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc-fix\application\controllers\post_jadwal\Post_jadwal.php 433
ERROR - 2024-01-24 00:07:25 --> Severity: Notice --> Undefined variable: jadwal_selesai C:\xampp\htdocs\jmto-eproc-fix\application\controllers\post_jadwal\Post_jadwal.php 433
ERROR - 2024-01-24 00:07:25 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc-fix\application\controllers\post_jadwal\Post_jadwal.php 433
ERROR - 2024-01-24 00:07:25 --> Severity: Notice --> Undefined variable: jadwal_selesai C:\xampp\htdocs\jmto-eproc-fix\application\controllers\post_jadwal\Post_jadwal.php 433
ERROR - 2024-01-24 00:07:25 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc-fix\application\controllers\post_jadwal\Post_jadwal.php 433
ERROR - 2024-01-24 00:07:25 --> Severity: Notice --> Undefined variable: jadwal_selesai C:\xampp\htdocs\jmto-eproc-fix\application\controllers\post_jadwal\Post_jadwal.php 433
ERROR - 2024-01-24 00:07:25 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc-fix\application\controllers\post_jadwal\Post_jadwal.php 433
ERROR - 2024-01-24 00:07:25 --> Severity: Notice --> Undefined variable: jadwal_selesai C:\xampp\htdocs\jmto-eproc-fix\application\controllers\post_jadwal\Post_jadwal.php 433
ERROR - 2024-01-24 00:07:25 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc-fix\application\controllers\post_jadwal\Post_jadwal.php 433
ERROR - 2024-01-24 00:07:25 --> Severity: Notice --> Undefined variable: jadwal_selesai C:\xampp\htdocs\jmto-eproc-fix\application\controllers\post_jadwal\Post_jadwal.php 433
ERROR - 2024-01-24 00:07:25 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc-fix\application\controllers\post_jadwal\Post_jadwal.php 433
ERROR - 2024-01-24 00:07:25 --> Severity: Notice --> Undefined variable: jadwal_selesai C:\xampp\htdocs\jmto-eproc-fix\application\controllers\post_jadwal\Post_jadwal.php 433
ERROR - 2024-01-24 00:07:25 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc-fix\application\controllers\post_jadwal\Post_jadwal.php 433
ERROR - 2024-01-24 00:07:25 --> Severity: Notice --> Undefined variable: jadwal_selesai C:\xampp\htdocs\jmto-eproc-fix\application\controllers\post_jadwal\Post_jadwal.php 433
ERROR - 2024-01-24 00:07:25 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc-fix\application\controllers\post_jadwal\Post_jadwal.php 433
ERROR - 2024-01-24 00:07:25 --> Severity: Notice --> Undefined variable: jadwal_selesai C:\xampp\htdocs\jmto-eproc-fix\application\controllers\post_jadwal\Post_jadwal.php 433
ERROR - 2024-01-24 00:07:25 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc-fix\application\controllers\post_jadwal\Post_jadwal.php 433
ERROR - 2024-01-24 00:07:25 --> Severity: Notice --> Undefined variable: jadwal_selesai C:\xampp\htdocs\jmto-eproc-fix\application\controllers\post_jadwal\Post_jadwal.php 433
ERROR - 2024-01-24 00:07:25 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc-fix\application\controllers\post_jadwal\Post_jadwal.php 433
ERROR - 2024-01-24 00:07:34 --> Severity: Notice --> Undefined variable: jadwal_selesai C:\xampp\htdocs\jmto-eproc-fix\application\controllers\post_jadwal\Post_jadwal.php 433
ERROR - 2024-01-24 00:07:34 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc-fix\application\controllers\post_jadwal\Post_jadwal.php 433
ERROR - 2024-01-24 00:07:34 --> Severity: Notice --> Undefined variable: jadwal_selesai C:\xampp\htdocs\jmto-eproc-fix\application\controllers\post_jadwal\Post_jadwal.php 433
ERROR - 2024-01-24 00:07:34 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc-fix\application\controllers\post_jadwal\Post_jadwal.php 433
ERROR - 2024-01-24 00:07:34 --> Severity: Notice --> Undefined variable: jadwal_selesai C:\xampp\htdocs\jmto-eproc-fix\application\controllers\post_jadwal\Post_jadwal.php 433
ERROR - 2024-01-24 00:07:34 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc-fix\application\controllers\post_jadwal\Post_jadwal.php 433
ERROR - 2024-01-24 00:07:34 --> Severity: Notice --> Undefined variable: jadwal_selesai C:\xampp\htdocs\jmto-eproc-fix\application\controllers\post_jadwal\Post_jadwal.php 433
ERROR - 2024-01-24 00:07:34 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc-fix\application\controllers\post_jadwal\Post_jadwal.php 433
ERROR - 2024-01-24 00:07:34 --> Severity: Notice --> Undefined variable: jadwal_selesai C:\xampp\htdocs\jmto-eproc-fix\application\controllers\post_jadwal\Post_jadwal.php 433
ERROR - 2024-01-24 00:07:34 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc-fix\application\controllers\post_jadwal\Post_jadwal.php 433
ERROR - 2024-01-24 00:07:34 --> Severity: Notice --> Undefined variable: jadwal_selesai C:\xampp\htdocs\jmto-eproc-fix\application\controllers\post_jadwal\Post_jadwal.php 433
ERROR - 2024-01-24 00:07:34 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc-fix\application\controllers\post_jadwal\Post_jadwal.php 433
ERROR - 2024-01-24 00:07:34 --> Severity: Notice --> Undefined variable: jadwal_selesai C:\xampp\htdocs\jmto-eproc-fix\application\controllers\post_jadwal\Post_jadwal.php 433
ERROR - 2024-01-24 00:07:34 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc-fix\application\controllers\post_jadwal\Post_jadwal.php 433
ERROR - 2024-01-24 00:07:34 --> Severity: Notice --> Undefined variable: jadwal_selesai C:\xampp\htdocs\jmto-eproc-fix\application\controllers\post_jadwal\Post_jadwal.php 433
ERROR - 2024-01-24 00:07:34 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc-fix\application\controllers\post_jadwal\Post_jadwal.php 433
ERROR - 2024-01-24 00:07:34 --> Severity: Notice --> Undefined variable: jadwal_selesai C:\xampp\htdocs\jmto-eproc-fix\application\controllers\post_jadwal\Post_jadwal.php 433
ERROR - 2024-01-24 00:07:34 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc-fix\application\controllers\post_jadwal\Post_jadwal.php 433
ERROR - 2024-01-24 00:07:34 --> Severity: Notice --> Undefined variable: jadwal_selesai C:\xampp\htdocs\jmto-eproc-fix\application\controllers\post_jadwal\Post_jadwal.php 433
ERROR - 2024-01-24 00:07:34 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc-fix\application\controllers\post_jadwal\Post_jadwal.php 433
ERROR - 2024-01-24 00:07:34 --> Severity: Notice --> Undefined variable: jadwal_selesai C:\xampp\htdocs\jmto-eproc-fix\application\controllers\post_jadwal\Post_jadwal.php 433
ERROR - 2024-01-24 00:07:34 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc-fix\application\controllers\post_jadwal\Post_jadwal.php 433
ERROR - 2024-01-24 00:07:34 --> Severity: Notice --> Undefined variable: jadwal_selesai C:\xampp\htdocs\jmto-eproc-fix\application\controllers\post_jadwal\Post_jadwal.php 433
ERROR - 2024-01-24 00:07:34 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc-fix\application\controllers\post_jadwal\Post_jadwal.php 433
ERROR - 2024-01-24 00:07:34 --> Severity: Notice --> Undefined variable: jadwal_selesai C:\xampp\htdocs\jmto-eproc-fix\application\controllers\post_jadwal\Post_jadwal.php 433
ERROR - 2024-01-24 00:07:34 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc-fix\application\controllers\post_jadwal\Post_jadwal.php 433
ERROR - 2024-01-24 00:07:34 --> Severity: Notice --> Undefined variable: jadwal_selesai C:\xampp\htdocs\jmto-eproc-fix\application\controllers\post_jadwal\Post_jadwal.php 433
ERROR - 2024-01-24 00:07:34 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc-fix\application\controllers\post_jadwal\Post_jadwal.php 433
ERROR - 2024-01-24 00:07:34 --> Severity: Notice --> Undefined variable: jadwal_selesai C:\xampp\htdocs\jmto-eproc-fix\application\controllers\post_jadwal\Post_jadwal.php 433
ERROR - 2024-01-24 00:07:34 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc-fix\application\controllers\post_jadwal\Post_jadwal.php 433
ERROR - 2024-01-24 00:07:34 --> Severity: Notice --> Undefined variable: jadwal_selesai C:\xampp\htdocs\jmto-eproc-fix\application\controllers\post_jadwal\Post_jadwal.php 433
ERROR - 2024-01-24 00:07:34 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc-fix\application\controllers\post_jadwal\Post_jadwal.php 433
ERROR - 2024-01-24 00:07:34 --> Severity: Notice --> Undefined variable: jadwal_selesai C:\xampp\htdocs\jmto-eproc-fix\application\controllers\post_jadwal\Post_jadwal.php 433
ERROR - 2024-01-24 00:07:34 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc-fix\application\controllers\post_jadwal\Post_jadwal.php 433
ERROR - 2024-01-24 00:07:35 --> Severity: Notice --> Undefined variable: jadwal_selesai C:\xampp\htdocs\jmto-eproc-fix\application\controllers\post_jadwal\Post_jadwal.php 433
ERROR - 2024-01-24 00:07:35 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc-fix\application\controllers\post_jadwal\Post_jadwal.php 433
ERROR - 2024-01-24 00:07:35 --> Severity: Notice --> Undefined variable: jadwal_selesai C:\xampp\htdocs\jmto-eproc-fix\application\controllers\post_jadwal\Post_jadwal.php 433
ERROR - 2024-01-24 00:07:35 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc-fix\application\controllers\post_jadwal\Post_jadwal.php 433
ERROR - 2024-01-24 00:07:35 --> Severity: Notice --> Undefined variable: jadwal_selesai C:\xampp\htdocs\jmto-eproc-fix\application\controllers\post_jadwal\Post_jadwal.php 433
ERROR - 2024-01-24 00:07:35 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc-fix\application\controllers\post_jadwal\Post_jadwal.php 433
ERROR - 2024-01-24 00:07:35 --> Severity: Notice --> Undefined variable: jadwal_selesai C:\xampp\htdocs\jmto-eproc-fix\application\controllers\post_jadwal\Post_jadwal.php 433
ERROR - 2024-01-24 00:07:35 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc-fix\application\controllers\post_jadwal\Post_jadwal.php 433
ERROR - 2024-01-24 00:07:35 --> Severity: Notice --> Undefined variable: jadwal_selesai C:\xampp\htdocs\jmto-eproc-fix\application\controllers\post_jadwal\Post_jadwal.php 433
ERROR - 2024-01-24 00:07:35 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc-fix\application\controllers\post_jadwal\Post_jadwal.php 433
ERROR - 2024-01-24 01:15:39 --> 404 Page Not Found: Export_chat/export_chat_anwijing
ERROR - 2024-01-24 01:29:04 --> 404 Page Not Found: Export_chat/export_chat_anwijing
