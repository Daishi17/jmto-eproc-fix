<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-12-29 09:43:27 --> Severity: error --> Exception: Too few arguments to function Daftar_paket::by_id_rup(), 0 passed in C:\xampp\htdocs\jmto-eproc-fix\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\xampp\htdocs\jmto-eproc-fix\application\controllers\panitia\daftar_paket\Daftar_paket.php 387
ERROR - 2023-12-29 11:47:55 --> Query error: Unknown column 'keterangan_dokumen' in 'field list' - Invalid query: UPDATE `tbl_dokumen_pengadaan` SET `keterangan_dokumen` = 'Perubahan Dokumen silakan Cek'
WHERE `id_dokumen_pengadaan` = '56'
ERROR - 2023-12-29 11:48:11 --> Query error: Unknown column 'keterangan_dokumen' in 'field list' - Invalid query: UPDATE `tbl_dokumen_pengadaan` SET `keterangan_dokumen` = 'Perubahan Dokumen silakan Cek'
WHERE `id_dokumen_pengadaan` = '56'
ERROR - 2023-12-29 11:48:37 --> Query error: Unknown column 'Array' in 'where clause' - Invalid query: SELECT *
FROM `tbl_dokumen_pengadaan`
WHERE `id_rup` = Array
ERROR - 2023-12-29 11:58:07 --> Query error: MySQL server has gone away - Invalid query: SELECT *
FROM `tbl_panitia`
LEFT JOIN `tbl_manajemen_user` ON `tbl_panitia`.`id_manajemen_user` = `tbl_manajemen_user`.`id_manajemen_user`
LEFT JOIN `tbl_pegawai` ON `tbl_manajemen_user`.`id_pegawai` = `tbl_pegawai`.`id_pegawai`
WHERE `id_rup` = '200'
AND `tbl_manajemen_user`.`role` = 5
