<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2024-04-29 07:01:37 --> Severity: error --> Exception: Too few arguments to function Daftar_paket::by_id_rup(), 0 passed in C:\laragon\www\jmto-eproc\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 388
ERROR - 2024-04-29 19:40:58 --> The upload path does not appear to be valid.
ERROR - 2024-04-29 19:42:26 --> The upload path does not appear to be valid.
ERROR - 2024-04-29 19:43:08 --> The upload path does not appear to be valid.
ERROR - 2024-04-29 19:46:28 --> Severity: error --> Exception: Class 'ReaderEntityFactory' not found C:\laragon\www\jmto-eproc\application\controllers\administrator\Sirup_rka.php 214
ERROR - 2024-04-29 19:46:48 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'ORDER BY `tbl_rkap` DESC
 LIMIT 1' at line 3 - Invalid query: SELECT MAX(`kode_rkap`) AS `kode_rkap`
FROM `2024`.
ORDER BY `tbl_rkap` DESC
 LIMIT 1
ERROR - 2024-04-29 19:50:54 --> Query error: Unknown column 'kode_urut_rup' in 'where clause' - Invalid query: SELECT MAX(`kode_rkap`) AS `kode_rkap`
FROM `tbl_rkap`
WHERE `kode_urut_rup` LIKE '2024.%' ESCAPE '!'
ORDER BY `kode_urut_rup` DESC
 LIMIT 1
ERROR - 2024-04-29 19:54:31 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'LIKE 'tbl!_rkap%' ESCAPE '!'
 LIMIT 1' at line 3 - Invalid query: SELECT MAX(`kode_rkap`) AS `kode_rkap`
FROM `kode_rkap`
WHERE  LIKE 'tbl!_rkap%' ESCAPE '!'
 LIMIT 1
ERROR - 2024-04-29 19:54:32 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'LIKE 'tbl!_rkap%' ESCAPE '!'
 LIMIT 1' at line 3 - Invalid query: SELECT MAX(`kode_rkap`) AS `kode_rkap`
FROM `kode_rkap`
WHERE  LIKE 'tbl!_rkap%' ESCAPE '!'
 LIMIT 1
ERROR - 2024-04-29 19:54:36 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'LIKE 'tbl!_rkap%' ESCAPE '!'
 LIMIT 1' at line 3 - Invalid query: SELECT MAX(`kode_rkap`) AS `kode_rkap`
FROM `kode_rkap`
WHERE  LIKE 'tbl!_rkap%' ESCAPE '!'
 LIMIT 1
