<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2024-05-20 08:16:24 --> 404 Page Not Found: administrator/Penilaian_kinerja/get_penilaian_pelaksanaan
ERROR - 2024-05-20 16:04:32 --> Query error: Unknown column 'NAN' in 'field list' - Invalid query: UPDATE `tbl_vendor` SET `nilai_vendor` = NAN
WHERE `id_vendor` = '123'
ERROR - 2024-05-20 16:06:05 --> Query error: Unknown column 'NAN' in 'field list' - Invalid query: UPDATE `tbl_vendor` SET `nilai_vendor` = NAN
WHERE `id_vendor` = '123'
