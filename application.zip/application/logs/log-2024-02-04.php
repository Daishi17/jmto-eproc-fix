<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2024-02-04 14:27:40 --> Severity: Notice --> Undefined variable: peserta_tender_pq_penawaran C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1311
ERROR - 2024-02-04 14:27:40 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1311
ERROR - 2024-02-04 14:27:41 --> Severity: Notice --> Undefined variable: peserta_tender_pq_penawaran C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1311
ERROR - 2024-02-04 14:27:41 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1311
ERROR - 2024-02-04 14:27:42 --> Severity: Notice --> Undefined variable: peserta_tender_pq_penawaran C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1311
ERROR - 2024-02-04 14:27:42 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1311
ERROR - 2024-02-04 14:27:43 --> Severity: Notice --> Undefined variable: peserta_tender_pq_penawaran C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1311
ERROR - 2024-02-04 14:27:43 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1311
