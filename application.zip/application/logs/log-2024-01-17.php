<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2024-01-17 00:23:59 --> Severity: error --> Exception: Too few arguments to function Daftar_paket::by_id_rup(), 0 passed in C:\xampp\htdocs\jmto-eproc-fix\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\xampp\htdocs\jmto-eproc-fix\application\controllers\panitia\daftar_paket\Daftar_paket.php 388
ERROR - 2024-01-17 00:46:54 --> Unable to connect to the database
ERROR - 2024-01-17 00:47:06 --> Unable to connect to the database
ERROR - 2024-01-17 00:48:46 --> Unable to connect to the database
ERROR - 2024-01-17 00:49:09 --> Unable to connect to the database
ERROR - 2024-01-17 00:49:10 --> Unable to connect to the database
ERROR - 2024-01-17 00:49:10 --> Unable to connect to the database
ERROR - 2024-01-17 00:49:10 --> Unable to connect to the database
ERROR - 2024-01-17 00:49:46 --> Unable to connect to the database
ERROR - 2024-01-17 03:58:14 --> Severity: Warning --> mysqli::real_connect(): php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\xampp\htdocs\jmto-eproc-fix\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2024-01-17 03:58:14 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\xampp\htdocs\jmto-eproc-fix\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2024-01-17 03:58:14 --> Unable to connect to the database
ERROR - 2024-01-17 13:53:21 --> Query error: MySQL server has gone away - Invalid query: SELECT *
FROM `tbl_vendor_mengikuti_paket`
LEFT JOIN `tbl_rup` ON `tbl_vendor_mengikuti_paket`.`id_rup` = `tbl_rup`.`id_rup`
LEFT JOIN `tbl_vendor` ON `tbl_vendor_mengikuti_paket`.`id_vendor` = `tbl_vendor`.`id_vendor`
WHERE `tbl_vendor_mengikuti_paket`.`id_rup` = '205'
AND `tbl_vendor_mengikuti_paket`.`sts_mengikuti_paket` = 1
ORDER BY `tbl_rup`.`id_rup` DESC
 LIMIT 10
ERROR - 2024-01-17 13:53:21 --> Query error: MySQL server has gone away - Invalid query: SELECT *
FROM `tbl_vendor_mengikuti_paket`
LEFT JOIN `tbl_rup` ON `tbl_vendor_mengikuti_paket`.`id_rup` = `tbl_rup`.`id_rup`
LEFT JOIN `tbl_vendor` ON `tbl_vendor_mengikuti_paket`.`id_vendor` = `tbl_vendor`.`id_vendor`
WHERE `tbl_vendor_mengikuti_paket`.`id_rup` = '205'
AND `tbl_vendor_mengikuti_paket`.`sts_mengikuti_paket` = 1
ORDER BY `tbl_rup`.`id_rup` DESC
 LIMIT 10
ERROR - 2024-01-17 21:01:35 --> Query error: MySQL server has gone away - Invalid query: SELECT *
FROM `tbl_rup`
LEFT JOIN `tbl_departemen` ON `tbl_rup`.`id_departemen` = `tbl_departemen`.`id_departemen`
LEFT JOIN `tbl_jadwal_tender` ON `tbl_rup`.`id_jadwal_tender` = `tbl_jadwal_tender`.`id_jadwal_tender`
LEFT JOIN `tbl_section` ON `tbl_rup`.`id_section` = `tbl_section`.`id_section`
LEFT JOIN `tbl_rkap` ON `tbl_rup`.`id_rkap` = `tbl_rkap`.`id_rkap`
LEFT JOIN `tbl_provinsi` ON `tbl_rup`.`id_provinsi` = `tbl_provinsi`.`id_provinsi`
LEFT JOIN `tbl_kabupaten` ON `tbl_rup`.`id_kabupaten` = `tbl_kabupaten`.`id_kabupaten`
LEFT JOIN `tbl_jenis_pengadaan` ON `tbl_rup`.`id_jenis_pengadaan` = `tbl_jenis_pengadaan`.`id_jenis_pengadaan`
LEFT JOIN `tbl_metode_pengadaan` ON `tbl_rup`.`id_metode_pengadaan` = `tbl_metode_pengadaan`.`id_metode_pengadaan`
LEFT JOIN `tbl_jenis_anggaran` ON `tbl_rup`.`id_jenis_anggaran` = `tbl_jenis_anggaran`.`id_jenis_anggaran`
LEFT JOIN `mst_ruas` ON `tbl_rup`.`id_ruas` = `mst_ruas`.`id_ruas`
WHERE `id_url_rup` = '7d2aec7ff9a940e8be2eaeefabac54bf'
