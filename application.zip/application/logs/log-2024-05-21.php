<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2024-05-21 18:05:35 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'tbl_rup.sts_pengumuman_rup_terakhir = 1' at line 1 - Invalid query: SELECT SUM(total_pagu_rup) as total_pagu, SUM(total_hps_rup) as total_hps FROM tbl_rup WHERE tahun_rup = 2024 AND id_jadwal_tender = 9AND tbl_rup.sts_pengumuman_rup_terakhir = 1
ERROR - 2024-05-21 18:05:41 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'tbl_rup.sts_pengumuman_rup_terakhir = 1' at line 1 - Invalid query: SELECT SUM(total_pagu_rup) as total_pagu, SUM(total_hps_rup) as total_hps FROM tbl_rup WHERE tahun_rup = 2024 AND id_jadwal_tender = 9AND tbl_rup.sts_pengumuman_rup_terakhir = 1
ERROR - 2024-05-21 18:06:07 --> Query error: Unknown column 'tbl_rup.sts_pengumuman_rup_terakhir' in 'where clause' - Invalid query: SELECT SUM(total_pagu_rup) as total_pagu, SUM(total_hps_rup) as total_hps FROM tbl_rup WHERE tahun_rup = 2024 AND id_jadwal_tender = 9 AND tbl_rup.sts_pengumuman_rup_terakhir = 1
ERROR - 2024-05-21 18:08:14 --> Severity: Warning --> Division by zero C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 173
ERROR - 2024-05-21 18:08:15 --> Severity: Warning --> Division by zero C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 188
ERROR - 2024-05-21 18:08:15 --> Severity: Warning --> Division by zero C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 191
ERROR - 2024-05-21 18:08:15 --> Severity: Warning --> Division by zero C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 193
ERROR - 2024-05-21 18:22:13 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'IN(9,10) AND sts_pengumuman_rup_trakhir = 1' at line 1 - Invalid query: SELECT SUM(total_hasil_negosiasi) as total_nego FROM tbl_rup LEFT JOIN tbl_vendor_mengikuti_paket ON tbl_rup.id_vendor_pemenang = tbl_vendor_mengikuti_paket.id_vendor WHERE tahun_rup = 2024 AND IN(9,10) AND sts_pengumuman_rup_trakhir = 1
ERROR - 2024-05-21 18:22:54 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'IN(9,10)' at line 1 - Invalid query: SELECT SUM(total_hasil_negosiasi) as total_nego FROM tbl_rup LEFT JOIN tbl_vendor_mengikuti_paket ON tbl_rup.id_vendor_pemenang = tbl_vendor_mengikuti_paket.id_vendor WHERE tahun_rup = 2024 AND IN(9,10)
ERROR - 2024-05-21 18:48:27 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'AND id_jadwal_tender IN(9,10)  AND id_vendor_pemenang IS NOT NULL' at line 1 - Invalid query: SELECT SUM(total_pagu_rup) AS total_pagu, SUM(total_hps_rup) AS total_hps FROM tbl_rup WHERE tahun_rup =  AND id_jadwal_tender IN(9,10)  AND id_vendor_pemenang IS NOT NULL
ERROR - 2024-05-21 19:26:36 --> Severity: Warning --> Division by zero C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 173
ERROR - 2024-05-21 19:26:36 --> Severity: Warning --> Division by zero C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 178
ERROR - 2024-05-21 19:26:36 --> Severity: Warning --> Division by zero C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 183
ERROR - 2024-05-21 19:26:36 --> Severity: Warning --> Division by zero C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 188
ERROR - 2024-05-21 19:26:36 --> Severity: Warning --> Division by zero C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 191
ERROR - 2024-05-21 19:26:36 --> Severity: Warning --> Division by zero C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 193
ERROR - 2024-05-21 19:27:30 --> Severity: Warning --> Division by zero C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 173
ERROR - 2024-05-21 19:27:30 --> Severity: Warning --> Division by zero C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 178
ERROR - 2024-05-21 19:27:30 --> Severity: Warning --> Division by zero C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 183
ERROR - 2024-05-21 19:27:30 --> Severity: Warning --> Division by zero C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 188
ERROR - 2024-05-21 19:27:30 --> Severity: Warning --> Division by zero C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 191
ERROR - 2024-05-21 19:27:30 --> Severity: Warning --> Division by zero C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 193
ERROR - 2024-05-21 19:32:50 --> Severity: Warning --> Division by zero C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 173
ERROR - 2024-05-21 19:32:50 --> Severity: Warning --> Division by zero C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 185
ERROR - 2024-05-21 19:32:50 --> Severity: Warning --> Division by zero C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 197
ERROR - 2024-05-21 19:32:50 --> Severity: Warning --> Division by zero C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 210
ERROR - 2024-05-21 19:32:50 --> Severity: Warning --> Division by zero C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 211
ERROR - 2024-05-21 19:32:50 --> Severity: Warning --> Division by zero C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 212
ERROR - 2024-05-21 19:33:42 --> Severity: Warning --> Division by zero C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 181
ERROR - 2024-05-21 19:33:42 --> Severity: Warning --> Division by zero C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 195
ERROR - 2024-05-21 19:33:43 --> Severity: Warning --> Division by zero C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 209
ERROR - 2024-05-21 19:33:43 --> Severity: Warning --> Division by zero C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 224
ERROR - 2024-05-21 19:33:43 --> Severity: Warning --> Division by zero C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 225
ERROR - 2024-05-21 19:33:43 --> Severity: Warning --> Division by zero C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 226
ERROR - 2024-05-21 19:34:06 --> Severity: Warning --> Division by zero C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 181
ERROR - 2024-05-21 19:34:06 --> Severity: Warning --> Division by zero C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 195
ERROR - 2024-05-21 19:34:06 --> Severity: Warning --> Division by zero C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 209
ERROR - 2024-05-21 19:34:06 --> Severity: Warning --> Division by zero C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 224
ERROR - 2024-05-21 19:34:06 --> Severity: Warning --> Division by zero C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 225
ERROR - 2024-05-21 19:34:06 --> Severity: Warning --> Division by zero C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 226
ERROR - 2024-05-21 19:35:00 --> Severity: Warning --> Division by zero C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 183
ERROR - 2024-05-21 19:35:00 --> Severity: Warning --> Division by zero C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 197
ERROR - 2024-05-21 19:35:00 --> Severity: Warning --> Division by zero C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 211
ERROR - 2024-05-21 19:35:00 --> Severity: Warning --> Division by zero C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 226
ERROR - 2024-05-21 19:35:00 --> Severity: Warning --> Division by zero C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 227
ERROR - 2024-05-21 19:35:00 --> Severity: Warning --> Division by zero C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 228
ERROR - 2024-05-21 19:36:47 --> Query error: MySQL server has gone away - Invalid query: SELECT *
FROM `tbl_laporan_realisasi_pic`
ERROR - 2024-05-21 19:36:47 --> Query error: MySQL server has gone away - Invalid query: SELECT *
FROM `tbl_rup`
LEFT JOIN `tbl_departemen` ON `tbl_rup`.`id_departemen` = `tbl_departemen`.`id_departemen`
LEFT JOIN `tbl_section` ON `tbl_rup`.`id_section` = `tbl_section`.`id_section`
LEFT JOIN `tbl_rkap` ON `tbl_rup`.`id_rkap` = `tbl_rkap`.`id_rkap`
LEFT JOIN `tbl_provinsi` ON `tbl_rup`.`id_provinsi` = `tbl_provinsi`.`id_provinsi`
LEFT JOIN `tbl_kabupaten` ON `tbl_rup`.`id_kabupaten` = `tbl_kabupaten`.`id_kabupaten`
LEFT JOIN `tbl_jenis_pengadaan` ON `tbl_rup`.`id_jenis_pengadaan` = `tbl_jenis_pengadaan`.`id_jenis_pengadaan`
LEFT JOIN `tbl_metode_pengadaan` ON `tbl_rup`.`id_metode_pengadaan` = `tbl_metode_pengadaan`.`id_metode_pengadaan`
LEFT JOIN `tbl_jenis_anggaran` ON `tbl_rup`.`id_jenis_anggaran` = `tbl_jenis_anggaran`.`id_jenis_anggaran`
LEFT JOIN `mst_ruas` ON `tbl_rup`.`id_ruas` = `mst_ruas`.`id_ruas`
WHERE `tbl_rup`.`id_jadwal_tender` IN(4, 5, 7, 8)
AND `tbl_rup`.`sts_pengumuman_rup_trakhir` = 1
ORDER BY `tbl_rup`.`id_rup` ASC
 LIMIT 10
ERROR - 2024-05-21 19:36:47 --> Query error: MySQL server has gone away - Invalid query: SELECT SUM(total_pagu_rup) AS total_pagu, SUM(total_hps_rup) AS total_hps FROM tbl_rup WHERE tahun_rup = 2023 AND id_jadwal_tender IN(9,10)  AND id_vendor_pemenang IS NOT NULL
ERROR - 2024-05-21 19:38:11 --> Query error: MySQL server has gone away - Invalid query: SELECT *
FROM `tbl_rekap_bulanan`
ERROR - 2024-05-21 19:38:11 --> Query error: MySQL server has gone away - Invalid query: SELECT *
FROM `tbl_laporan_realisasi_pic`
ERROR - 2024-05-21 19:38:11 --> Query error: MySQL server has gone away - Invalid query: SELECT *
FROM `tbl_rekap_bulanan`
ERROR - 2024-05-21 19:38:11 --> Query error: MySQL server has gone away - Invalid query: SELECT *
FROM `tbl_rup`
LEFT JOIN `tbl_departemen` ON `tbl_rup`.`id_departemen` = `tbl_departemen`.`id_departemen`
LEFT JOIN `tbl_section` ON `tbl_rup`.`id_section` = `tbl_section`.`id_section`
LEFT JOIN `tbl_rkap` ON `tbl_rup`.`id_rkap` = `tbl_rkap`.`id_rkap`
LEFT JOIN `tbl_provinsi` ON `tbl_rup`.`id_provinsi` = `tbl_provinsi`.`id_provinsi`
LEFT JOIN `tbl_kabupaten` ON `tbl_rup`.`id_kabupaten` = `tbl_kabupaten`.`id_kabupaten`
LEFT JOIN `tbl_jenis_pengadaan` ON `tbl_rup`.`id_jenis_pengadaan` = `tbl_jenis_pengadaan`.`id_jenis_pengadaan`
LEFT JOIN `tbl_metode_pengadaan` ON `tbl_rup`.`id_metode_pengadaan` = `tbl_metode_pengadaan`.`id_metode_pengadaan`
LEFT JOIN `tbl_jenis_anggaran` ON `tbl_rup`.`id_jenis_anggaran` = `tbl_jenis_anggaran`.`id_jenis_anggaran`
LEFT JOIN `mst_ruas` ON `tbl_rup`.`id_ruas` = `mst_ruas`.`id_ruas`
WHERE `tbl_rup`.`id_jadwal_tender` IN(1, 2, 3, 6)
AND `tbl_rup`.`sts_pengumuman_rup_trakhir` = 1
ORDER BY `tbl_rup`.`id_rup` ASC
 LIMIT 10
ERROR - 2024-05-21 19:38:11 --> Query error: MySQL server has gone away - Invalid query: SELECT SUM(`total_pagu_rup`) AS `total_pagu_rup`
FROM `tbl_rup`
WHERE `id_vendor_pemenang` IS NOT NULL
AND `tbl_rup`.`id_departemen` = 1
ERROR - 2024-05-21 19:38:11 --> Query error: MySQL server has gone away - Invalid query: SELECT *
FROM `tbl_rup`
LEFT JOIN `tbl_departemen` ON `tbl_rup`.`id_departemen` = `tbl_departemen`.`id_departemen`
LEFT JOIN `tbl_section` ON `tbl_rup`.`id_section` = `tbl_section`.`id_section`
LEFT JOIN `tbl_rkap` ON `tbl_rup`.`id_rkap` = `tbl_rkap`.`id_rkap`
LEFT JOIN `tbl_provinsi` ON `tbl_rup`.`id_provinsi` = `tbl_provinsi`.`id_provinsi`
LEFT JOIN `tbl_kabupaten` ON `tbl_rup`.`id_kabupaten` = `tbl_kabupaten`.`id_kabupaten`
LEFT JOIN `tbl_jenis_pengadaan` ON `tbl_rup`.`id_jenis_pengadaan` = `tbl_jenis_pengadaan`.`id_jenis_pengadaan`
LEFT JOIN `tbl_metode_pengadaan` ON `tbl_rup`.`id_metode_pengadaan` = `tbl_metode_pengadaan`.`id_metode_pengadaan`
LEFT JOIN `tbl_jenis_anggaran` ON `tbl_rup`.`id_jenis_anggaran` = `tbl_jenis_anggaran`.`id_jenis_anggaran`
LEFT JOIN `mst_ruas` ON `tbl_rup`.`id_ruas` = `mst_ruas`.`id_ruas`
WHERE `tbl_rup`.`id_jadwal_tender` IN(4, 5, 7, 8)
AND `tbl_rup`.`sts_pengumuman_rup_trakhir` = 1
ORDER BY `tbl_rup`.`id_rup` ASC
 LIMIT 10
ERROR - 2024-05-21 19:38:11 --> Query error: MySQL server has gone away - Invalid query: SELECT *
FROM `tbl_rup`
LEFT JOIN `tbl_departemen` ON `tbl_rup`.`id_departemen` = `tbl_departemen`.`id_departemen`
LEFT JOIN `tbl_section` ON `tbl_rup`.`id_section` = `tbl_section`.`id_section`
LEFT JOIN `tbl_rkap` ON `tbl_rup`.`id_rkap` = `tbl_rkap`.`id_rkap`
LEFT JOIN `tbl_provinsi` ON `tbl_rup`.`id_provinsi` = `tbl_provinsi`.`id_provinsi`
LEFT JOIN `tbl_kabupaten` ON `tbl_rup`.`id_kabupaten` = `tbl_kabupaten`.`id_kabupaten`
LEFT JOIN `tbl_jenis_pengadaan` ON `tbl_rup`.`id_jenis_pengadaan` = `tbl_jenis_pengadaan`.`id_jenis_pengadaan`
LEFT JOIN `tbl_metode_pengadaan` ON `tbl_rup`.`id_metode_pengadaan` = `tbl_metode_pengadaan`.`id_metode_pengadaan`
LEFT JOIN `tbl_jenis_anggaran` ON `tbl_rup`.`id_jenis_anggaran` = `tbl_jenis_anggaran`.`id_jenis_anggaran`
LEFT JOIN `mst_ruas` ON `tbl_rup`.`id_ruas` = `mst_ruas`.`id_ruas`
WHERE `tbl_rup`.`id_jadwal_tender` = 9
AND `tbl_rup`.`sts_pengumuman_rup_trakhir` = 1
ORDER BY `tbl_rup`.`id_rup` ASC
 LIMIT 10
ERROR - 2024-05-21 19:38:13 --> Severity: Warning --> Division by zero C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 200
ERROR - 2024-05-21 19:38:13 --> Severity: Warning --> Division by zero C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 214
ERROR - 2024-05-21 19:38:13 --> Severity: Warning --> Division by zero C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 229
ERROR - 2024-05-21 19:38:13 --> Severity: Warning --> Division by zero C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 230
ERROR - 2024-05-21 19:38:13 --> Severity: Warning --> Division by zero C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 231
ERROR - 2024-05-21 19:38:13 --> Severity: Warning --> number_format() expects parameter 1 to be float, string given C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 241
ERROR - 2024-05-21 19:38:13 --> Severity: Warning --> number_format() expects parameter 1 to be float, string given C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 242
ERROR - 2024-05-21 19:38:56 --> Query error: MySQL server has gone away - Invalid query: SELECT *
FROM `tbl_rup`
LEFT JOIN `tbl_departemen` ON `tbl_rup`.`id_departemen` = `tbl_departemen`.`id_departemen`
LEFT JOIN `tbl_section` ON `tbl_rup`.`id_section` = `tbl_section`.`id_section`
LEFT JOIN `tbl_rkap` ON `tbl_rup`.`id_rkap` = `tbl_rkap`.`id_rkap`
LEFT JOIN `tbl_provinsi` ON `tbl_rup`.`id_provinsi` = `tbl_provinsi`.`id_provinsi`
LEFT JOIN `tbl_kabupaten` ON `tbl_rup`.`id_kabupaten` = `tbl_kabupaten`.`id_kabupaten`
LEFT JOIN `tbl_jenis_pengadaan` ON `tbl_rup`.`id_jenis_pengadaan` = `tbl_jenis_pengadaan`.`id_jenis_pengadaan`
LEFT JOIN `tbl_metode_pengadaan` ON `tbl_rup`.`id_metode_pengadaan` = `tbl_metode_pengadaan`.`id_metode_pengadaan`
LEFT JOIN `tbl_jenis_anggaran` ON `tbl_rup`.`id_jenis_anggaran` = `tbl_jenis_anggaran`.`id_jenis_anggaran`
LEFT JOIN `mst_ruas` ON `tbl_rup`.`id_ruas` = `mst_ruas`.`id_ruas`
WHERE `tbl_rup`.`id_jadwal_tender` IN(1, 2, 3, 6)
AND `tbl_rup`.`sts_pengumuman_rup_trakhir` = 1
ORDER BY `tbl_rup`.`id_rup` ASC
 LIMIT 10
ERROR - 2024-05-21 19:39:04 --> Query error: MySQL server has gone away - Invalid query: SELECT SUM(total_pagu_rup) AS total_pagu, SUM(total_hps_rup) AS total_hps FROM tbl_rup WHERE tahun_rup = 2023 AND id_jadwal_tender IN(9,10)  AND id_vendor_pemenang IS NOT NULL
ERROR - 2024-05-21 19:39:04 --> Severity: Warning --> mysqli::real_connect(): Error while reading greeting packet. PID=7728 C:\laragon\www\jmto-eproc\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2024-05-21 19:39:04 --> Severity: Warning --> mysqli::real_connect(): (HY000/2006): MySQL server has gone away C:\laragon\www\jmto-eproc\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2024-05-21 19:39:04 --> Unable to connect to the database
ERROR - 2024-05-21 19:39:04 --> Severity: Warning --> mysqli::real_connect(): Error while reading greeting packet. PID=7728 C:\laragon\www\jmto-eproc\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2024-05-21 19:39:04 --> Severity: Warning --> mysqli::real_connect(): (HY000/2006): MySQL server has gone away C:\laragon\www\jmto-eproc\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2024-05-21 19:39:04 --> Unable to connect to the database
ERROR - 2024-05-21 19:39:14 --> Severity: Warning --> Division by zero C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 200
ERROR - 2024-05-21 19:39:14 --> Severity: Warning --> Division by zero C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 214
ERROR - 2024-05-21 19:39:14 --> Severity: Warning --> Division by zero C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 229
ERROR - 2024-05-21 19:39:14 --> Severity: Warning --> Division by zero C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 230
ERROR - 2024-05-21 19:39:14 --> Severity: Warning --> Division by zero C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 231
ERROR - 2024-05-21 19:39:14 --> Severity: Warning --> number_format() expects parameter 1 to be float, string given C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 241
ERROR - 2024-05-21 19:39:14 --> Severity: Warning --> number_format() expects parameter 1 to be float, string given C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 242
ERROR - 2024-05-21 19:41:41 --> Severity: Warning --> Division by zero C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 181
ERROR - 2024-05-21 19:41:41 --> Severity: Warning --> Division by zero C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 195
ERROR - 2024-05-21 19:41:41 --> Severity: Warning --> Division by zero C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 209
ERROR - 2024-05-21 19:41:41 --> Severity: Warning --> Division by zero C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 224
ERROR - 2024-05-21 19:41:41 --> Severity: Warning --> Division by zero C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 225
ERROR - 2024-05-21 19:41:41 --> Severity: Warning --> Division by zero C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 226
ERROR - 2024-05-21 19:42:05 --> Severity: Warning --> Division by zero C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 181
ERROR - 2024-05-21 19:42:10 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'AND id_jadwal_tender IN(9,10)  AND id_vendor_pemenang IS NOT NULL' at line 1 - Invalid query: SELECT SUM(total_pagu_rup) AS total_pagu, SUM(total_hps_rup) AS total_hps FROM tbl_rup WHERE tahun_rup =  AND id_jadwal_tender IN(9,10)  AND id_vendor_pemenang IS NOT NULL
ERROR - 2024-05-21 19:42:40 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'AND id_jadwal_tender IN(9,10)  AND id_vendor_pemenang IS NOT NULL' at line 1 - Invalid query: SELECT SUM(total_pagu_rup) AS total_pagu, SUM(total_hps_rup) AS total_hps FROM tbl_rup WHERE tahun_rup =  AND id_jadwal_tender IN(9,10)  AND id_vendor_pemenang IS NOT NULL
ERROR - 2024-05-21 19:42:54 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'AND id_jadwal_tender IN(9,10)  AND id_vendor_pemenang IS NOT NULL' at line 1 - Invalid query: SELECT SUM(total_pagu_rup) AS total_pagu, SUM(total_hps_rup) AS total_hps FROM tbl_rup WHERE tahun_rup =  AND id_jadwal_tender IN(9,10)  AND id_vendor_pemenang IS NOT NULL
ERROR - 2024-05-21 19:43:25 --> Severity: Warning --> Division by zero C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 181
ERROR - 2024-05-21 19:43:25 --> Severity: Warning --> Division by zero C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 195
ERROR - 2024-05-21 19:43:25 --> Severity: Warning --> Division by zero C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 209
ERROR - 2024-05-21 19:43:25 --> Severity: Warning --> Division by zero C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 224
ERROR - 2024-05-21 19:43:25 --> Severity: Warning --> Division by zero C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 225
ERROR - 2024-05-21 19:43:25 --> Severity: Warning --> Division by zero C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 226
ERROR - 2024-05-21 19:45:10 --> Severity: Warning --> Division by zero C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 182
ERROR - 2024-05-21 19:45:10 --> Severity: Warning --> Division by zero C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 196
ERROR - 2024-05-21 19:45:10 --> Severity: Warning --> Division by zero C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 210
ERROR - 2024-05-21 19:45:10 --> Severity: Warning --> Division by zero C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 225
ERROR - 2024-05-21 19:45:10 --> Severity: Warning --> Division by zero C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 226
ERROR - 2024-05-21 19:45:10 --> Severity: Warning --> Division by zero C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 227
ERROR - 2024-05-21 19:45:56 --> Severity: Warning --> Illegal string offset 'total_pagu' C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 234
ERROR - 2024-05-21 19:45:56 --> Severity: Warning --> number_format() expects parameter 1 to be float, string given C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 234
ERROR - 2024-05-21 19:45:56 --> Severity: Warning --> Illegal string offset 'total_hps' C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 235
ERROR - 2024-05-21 19:45:56 --> Severity: Warning --> number_format() expects parameter 1 to be float, string given C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 235
ERROR - 2024-05-21 19:45:56 --> Severity: Warning --> Illegal string offset 'total_nego' C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 236
ERROR - 2024-05-21 19:45:56 --> Severity: Warning --> number_format() expects parameter 1 to be float, string given C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 236
ERROR - 2024-05-21 19:45:56 --> Severity: Warning --> number_format() expects parameter 1 to be float, string given C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 237
ERROR - 2024-05-21 19:45:56 --> Severity: Warning --> number_format() expects parameter 1 to be float, string given C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 238
ERROR - 2024-05-21 19:45:56 --> Severity: Notice --> Undefined variable: terbatas_efisiensi C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 243
ERROR - 2024-05-21 19:45:56 --> Severity: Notice --> Undefined variable: terbatas_persentase C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 244
ERROR - 2024-05-21 19:45:56 --> Severity: Warning --> Illegal string offset 'total_pagu' C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 246
ERROR - 2024-05-21 19:45:56 --> Severity: Warning --> number_format() expects parameter 1 to be float, string given C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 246
ERROR - 2024-05-21 19:45:56 --> Severity: Warning --> Illegal string offset 'total_hps' C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 247
ERROR - 2024-05-21 19:45:56 --> Severity: Warning --> number_format() expects parameter 1 to be float, string given C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 247
ERROR - 2024-05-21 19:45:56 --> Severity: Warning --> Illegal string offset 'total_nego' C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 248
ERROR - 2024-05-21 19:45:56 --> Severity: Warning --> number_format() expects parameter 1 to be float, string given C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 248
ERROR - 2024-05-21 19:45:56 --> Severity: Warning --> number_format() expects parameter 1 to be float, string given C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 249
ERROR - 2024-05-21 19:45:56 --> Severity: Warning --> number_format() expects parameter 1 to be float, string given C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 250
ERROR - 2024-05-21 19:45:56 --> Severity: Warning --> Illegal string offset 'total_pagu' C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 252
ERROR - 2024-05-21 19:45:56 --> Severity: Warning --> number_format() expects parameter 1 to be float, string given C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 252
ERROR - 2024-05-21 19:45:56 --> Severity: Warning --> Illegal string offset 'total_hps' C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 253
ERROR - 2024-05-21 19:45:56 --> Severity: Warning --> number_format() expects parameter 1 to be float, string given C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 253
ERROR - 2024-05-21 19:45:56 --> Severity: Warning --> Illegal string offset 'total_nego' C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 254
ERROR - 2024-05-21 19:45:56 --> Severity: Warning --> number_format() expects parameter 1 to be float, string given C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 254
ERROR - 2024-05-21 19:45:56 --> Severity: Warning --> number_format() expects parameter 1 to be float, string given C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 255
ERROR - 2024-05-21 19:45:56 --> Severity: Warning --> number_format() expects parameter 1 to be float, string given C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 256
ERROR - 2024-05-21 19:45:56 --> Severity: Warning --> number_format() expects parameter 1 to be float, string given C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 258
ERROR - 2024-05-21 19:45:56 --> Severity: Warning --> number_format() expects parameter 1 to be float, string given C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 260
ERROR - 2024-05-21 19:46:38 --> Severity: Warning --> Illegal string offset 'total_pagu' C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 234
ERROR - 2024-05-21 19:46:38 --> Severity: Warning --> number_format() expects parameter 1 to be float, string given C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 234
ERROR - 2024-05-21 19:46:38 --> Severity: Warning --> Illegal string offset 'total_hps' C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 235
ERROR - 2024-05-21 19:46:38 --> Severity: Warning --> number_format() expects parameter 1 to be float, string given C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 235
ERROR - 2024-05-21 19:46:38 --> Severity: Warning --> Illegal string offset 'total_nego' C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 236
ERROR - 2024-05-21 19:46:38 --> Severity: Warning --> number_format() expects parameter 1 to be float, string given C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 236
ERROR - 2024-05-21 19:46:38 --> Severity: Warning --> number_format() expects parameter 1 to be float, string given C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 237
ERROR - 2024-05-21 19:46:38 --> Severity: Warning --> number_format() expects parameter 1 to be float, string given C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 238
ERROR - 2024-05-21 19:46:38 --> Severity: Notice --> Undefined variable: terbatas_efisiensi C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 243
ERROR - 2024-05-21 19:46:38 --> Severity: Notice --> Undefined variable: terbatas_persentase C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 244
ERROR - 2024-05-21 19:46:38 --> Severity: Warning --> Illegal string offset 'total_pagu' C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 246
ERROR - 2024-05-21 19:46:38 --> Severity: Warning --> number_format() expects parameter 1 to be float, string given C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 246
ERROR - 2024-05-21 19:46:38 --> Severity: Warning --> Illegal string offset 'total_hps' C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 247
ERROR - 2024-05-21 19:46:38 --> Severity: Warning --> number_format() expects parameter 1 to be float, string given C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 247
ERROR - 2024-05-21 19:46:38 --> Severity: Warning --> Illegal string offset 'total_nego' C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 248
ERROR - 2024-05-21 19:46:38 --> Severity: Warning --> number_format() expects parameter 1 to be float, string given C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 248
ERROR - 2024-05-21 19:46:38 --> Severity: Warning --> number_format() expects parameter 1 to be float, string given C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 249
ERROR - 2024-05-21 19:46:38 --> Severity: Warning --> number_format() expects parameter 1 to be float, string given C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 250
ERROR - 2024-05-21 19:46:38 --> Severity: Warning --> Illegal string offset 'total_pagu' C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 252
ERROR - 2024-05-21 19:46:38 --> Severity: Warning --> number_format() expects parameter 1 to be float, string given C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 252
ERROR - 2024-05-21 19:46:38 --> Severity: Warning --> Illegal string offset 'total_hps' C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 253
ERROR - 2024-05-21 19:46:38 --> Severity: Warning --> number_format() expects parameter 1 to be float, string given C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 253
ERROR - 2024-05-21 19:46:38 --> Severity: Warning --> Illegal string offset 'total_nego' C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 254
ERROR - 2024-05-21 19:46:38 --> Severity: Warning --> number_format() expects parameter 1 to be float, string given C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 254
ERROR - 2024-05-21 19:46:38 --> Severity: Warning --> number_format() expects parameter 1 to be float, string given C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 255
ERROR - 2024-05-21 19:46:38 --> Severity: Warning --> number_format() expects parameter 1 to be float, string given C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 256
ERROR - 2024-05-21 19:46:38 --> Severity: Warning --> number_format() expects parameter 1 to be float, string given C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 258
ERROR - 2024-05-21 19:46:38 --> Severity: Warning --> number_format() expects parameter 1 to be float, string given C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 260
ERROR - 2024-05-21 19:50:52 --> Severity: Warning --> Illegal string offset 'total_pagu' C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 219
ERROR - 2024-05-21 19:50:52 --> Severity: Warning --> number_format() expects parameter 1 to be float, string given C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 219
ERROR - 2024-05-21 19:50:52 --> Severity: Warning --> Illegal string offset 'total_hps' C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 220
ERROR - 2024-05-21 19:50:52 --> Severity: Warning --> number_format() expects parameter 1 to be float, string given C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 220
ERROR - 2024-05-21 19:50:52 --> Severity: Warning --> Illegal string offset 'total_nego' C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 221
ERROR - 2024-05-21 19:50:52 --> Severity: Warning --> number_format() expects parameter 1 to be float, string given C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 221
ERROR - 2024-05-21 19:50:52 --> Severity: Warning --> number_format() expects parameter 1 to be float, string given C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 222
ERROR - 2024-05-21 19:50:52 --> Severity: Warning --> number_format() expects parameter 1 to be float, string given C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 223
ERROR - 2024-05-21 19:50:52 --> Severity: Warning --> number_format() expects parameter 1 to be float, string given C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 225
ERROR - 2024-05-21 19:50:52 --> Severity: Warning --> number_format() expects parameter 1 to be float, string given C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 227
ERROR - 2024-05-21 19:53:24 --> Severity: Notice --> A non well formed numeric value encountered C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 205
ERROR - 2024-05-21 19:56:28 --> Severity: Notice --> A non well formed numeric value encountered C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 187
ERROR - 2024-05-21 19:56:28 --> Severity: Notice --> A non well formed numeric value encountered C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 208
ERROR - 2024-05-21 19:56:28 --> Severity: Notice --> A non well formed numeric value encountered C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 228
ERROR - 2024-05-21 19:57:06 --> Severity: Notice --> A non well formed numeric value encountered C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 187
ERROR - 2024-05-21 19:57:28 --> Severity: Notice --> A non well formed numeric value encountered C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 187
ERROR - 2024-05-21 19:57:28 --> Severity: Notice --> A non well formed numeric value encountered C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 207
ERROR - 2024-05-21 19:57:28 --> Severity: Notice --> A non well formed numeric value encountered C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 227
ERROR - 2024-05-21 19:58:10 --> Severity: Notice --> A non well formed numeric value encountered C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 187
ERROR - 2024-05-21 19:58:10 --> Severity: Notice --> A non well formed numeric value encountered C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 227
ERROR - 2024-05-21 19:59:25 --> Severity: Notice --> Undefined variable: data_terbatas C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 189
ERROR - 2024-05-21 19:59:25 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 189
ERROR - 2024-05-21 20:01:10 --> Severity: Warning --> Illegal string offset 'total_pagu' C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 248
ERROR - 2024-05-21 20:01:10 --> Severity: Warning --> number_format() expects parameter 1 to be float, string given C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 248
ERROR - 2024-05-21 20:01:10 --> Severity: Warning --> Illegal string offset 'total_hps' C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 249
ERROR - 2024-05-21 20:01:10 --> Severity: Warning --> number_format() expects parameter 1 to be float, string given C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 249
ERROR - 2024-05-21 20:01:10 --> Severity: Warning --> Illegal string offset 'total_nego' C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 250
ERROR - 2024-05-21 20:01:10 --> Severity: Warning --> number_format() expects parameter 1 to be float, string given C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 250
ERROR - 2024-05-21 20:01:10 --> Severity: Warning --> number_format() expects parameter 1 to be float, string given C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 251
ERROR - 2024-05-21 20:01:10 --> Severity: Warning --> number_format() expects parameter 1 to be float, string given C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 252
ERROR - 2024-05-21 20:01:10 --> Severity: Warning --> number_format() expects parameter 1 to be float, string given C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 254
ERROR - 2024-05-21 20:01:10 --> Severity: Warning --> number_format() expects parameter 1 to be float, string given C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 256
ERROR - 2024-05-21 20:04:56 --> Severity: Notice --> A non well formed numeric value encountered C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 226
ERROR - 2024-05-21 20:04:56 --> Severity: Notice --> Undefined variable: persentase_selisih C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 281
ERROR - 2024-05-21 20:04:56 --> Severity: Notice --> Undefined variable: persentase_efisiensi C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 283
ERROR - 2024-05-21 20:05:06 --> Severity: Notice --> A non well formed numeric value encountered C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 226
ERROR - 2024-05-21 20:05:11 --> Severity: Notice --> A non well formed numeric value encountered C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 226
ERROR - 2024-05-21 20:05:54 --> Severity: Notice --> A non well formed numeric value encountered C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 187
ERROR - 2024-05-21 20:05:54 --> Severity: Notice --> Undefined variable: persentase_selisih C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 282
ERROR - 2024-05-21 20:05:54 --> Severity: Notice --> Undefined variable: persentase_efisiensi C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 284
ERROR - 2024-05-21 20:06:20 --> Severity: Notice --> Undefined variable: juksung_efisiensi C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 186
ERROR - 2024-05-21 20:06:21 --> Severity: Notice --> Undefined variable: juksung_efisiensi C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 257
