<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2024-02-23 10:01:04 --> Severity: error --> Exception: Too few arguments to function M_Rekanan_terundang::cek_jika_ada_dokumen_pengajuan(), 0 passed in C:\laragon\www\jmto-eproc\application\controllers\validator\Dashboard.php on line 55 and exactly 1 expected C:\laragon\www\jmto-eproc\application\models\M_datapenyedia\M_Rekanan_terundang.php 2069
ERROR - 2024-02-23 10:01:17 --> Severity: error --> Exception: Too few arguments to function M_Rekanan_terundang::cek_jika_ada_dokumen_pengajuan(), 0 passed in C:\laragon\www\jmto-eproc\application\controllers\validator\Dashboard.php on line 55 and exactly 1 expected C:\laragon\www\jmto-eproc\application\models\M_datapenyedia\M_Rekanan_terundang.php 2069
ERROR - 2024-02-23 10:22:21 --> Severity: error --> Exception: Too few arguments to function Daftar_paket::by_id_rup(), 0 passed in C:\laragon\www\jmto-eproc\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 393
ERROR - 2024-02-23 10:22:45 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 2112
ERROR - 2024-02-23 10:22:46 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 2113
ERROR - 2024-02-23 10:22:46 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 2112
ERROR - 2024-02-23 10:22:46 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 2113
ERROR - 2024-02-23 10:22:51 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 2112
ERROR - 2024-02-23 10:22:51 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 2113
ERROR - 2024-02-23 10:22:54 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 2112
ERROR - 2024-02-23 10:22:54 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 2113
ERROR - 2024-02-23 10:23:08 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 2112
ERROR - 2024-02-23 10:23:08 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 2113
ERROR - 2024-02-23 10:23:12 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 2112
ERROR - 2024-02-23 10:23:12 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 2113
ERROR - 2024-02-23 10:23:50 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 2112
ERROR - 2024-02-23 10:23:50 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 2113
ERROR - 2024-02-23 10:23:53 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 2112
ERROR - 2024-02-23 10:23:53 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 2113
ERROR - 2024-02-23 10:25:17 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 2112
ERROR - 2024-02-23 10:25:17 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 2113
ERROR - 2024-02-23 10:25:20 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 2112
ERROR - 2024-02-23 10:25:20 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 2113
ERROR - 2024-02-23 10:26:12 --> Severity: error --> Exception: Too few arguments to function Daftar_paket::by_id_rup(), 0 passed in C:\laragon\www\jmto-eproc\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 393
ERROR - 2024-02-23 10:53:11 --> Severity: error --> Exception: Too few arguments to function Daftar_paket::by_id_rup(), 0 passed in C:\laragon\www\jmto-eproc\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 393
ERROR - 2024-02-23 11:35:48 --> Query error: Unknown column 'sts_kirim_hasil_evaluasi' in 'where clause' - Invalid query: SELECT *
FROM `tbl_panitia`
WHERE `id_rup` = '224'
AND `sts_kirim_hasil_evaluasi` IS NULL
ERROR - 2024-02-23 13:16:49 --> Severity: error --> Exception: Too few arguments to function Daftar_paket::by_id_rup(), 0 passed in C:\laragon\www\jmto-eproc\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 393
ERROR - 2024-02-23 13:18:35 --> Severity: error --> Exception: Too few arguments to function Daftar_paket::by_id_rup(), 0 passed in C:\laragon\www\jmto-eproc\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 393
ERROR - 2024-02-23 13:19:02 --> Severity: error --> Exception: Too few arguments to function Daftar_paket::by_id_rup(), 0 passed in C:\laragon\www\jmto-eproc\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 393
ERROR - 2024-02-23 13:19:23 --> Severity: error --> Exception: Too few arguments to function Daftar_paket::by_id_rup(), 0 passed in C:\laragon\www\jmto-eproc\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 393
