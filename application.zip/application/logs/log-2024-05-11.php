<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2024-05-11 14:37:42 --> Severity: Notice --> Undefined property: stdClass::$total_hasil_negosiasi C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 241
ERROR - 2024-05-11 14:37:42 --> Severity: Notice --> Undefined property: stdClass::$total_hasil_negosiasi C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 241
ERROR - 2024-05-11 14:37:42 --> Severity: Notice --> Undefined property: stdClass::$total_hasil_negosiasi C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 241
ERROR - 2024-05-11 14:37:42 --> Severity: Notice --> Undefined property: stdClass::$total_hasil_negosiasi C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 241
ERROR - 2024-05-11 14:37:42 --> Severity: Notice --> Undefined property: stdClass::$total_hasil_negosiasi C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 241
ERROR - 2024-05-11 14:37:42 --> Severity: Notice --> Undefined property: stdClass::$total_hasil_negosiasi C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 241
ERROR - 2024-05-11 14:37:42 --> Severity: Notice --> Undefined property: stdClass::$total_hasil_negosiasi C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 241
ERROR - 2024-05-11 14:37:42 --> Severity: Notice --> Undefined property: stdClass::$total_hasil_negosiasi C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 241
ERROR - 2024-05-11 14:37:42 --> Severity: Notice --> Undefined property: stdClass::$total_hasil_negosiasi C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 241
ERROR - 2024-05-11 14:37:42 --> Severity: Notice --> Undefined property: stdClass::$total_hasil_negosiasi C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 241
ERROR - 2024-05-11 14:37:50 --> Severity: Notice --> Undefined property: stdClass::$total_hasil_negosiasi C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 241
ERROR - 2024-05-11 14:37:50 --> Severity: Notice --> Undefined property: stdClass::$total_hasil_negosiasi C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 241
ERROR - 2024-05-11 14:37:50 --> Severity: Notice --> Undefined property: stdClass::$total_hasil_negosiasi C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 241
ERROR - 2024-05-11 14:37:50 --> Severity: Notice --> Undefined property: stdClass::$total_hasil_negosiasi C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 241
ERROR - 2024-05-11 14:37:50 --> Severity: Notice --> Undefined property: stdClass::$total_hasil_negosiasi C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 241
ERROR - 2024-05-11 14:37:50 --> Severity: Notice --> Undefined property: stdClass::$total_hasil_negosiasi C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 241
ERROR - 2024-05-11 14:37:50 --> Severity: Notice --> Undefined property: stdClass::$total_hasil_negosiasi C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 241
ERROR - 2024-05-11 14:37:50 --> Severity: Notice --> Undefined property: stdClass::$total_hasil_negosiasi C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 241
ERROR - 2024-05-11 14:37:50 --> Severity: Notice --> Undefined property: stdClass::$total_hasil_negosiasi C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 241
ERROR - 2024-05-11 14:37:50 --> Severity: Notice --> Undefined property: stdClass::$total_hasil_negosiasi C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 241
ERROR - 2024-05-11 14:48:12 --> Query error: Unknown column 'tbl_vendor_mengikuti_paket.id_pemenang' in 'where clause' - Invalid query: SELECT *
FROM `tbl_vendor_mengikuti_paket`
LEFT JOIN `tbl_rup` ON `tbl_rup`.`id_rup` = `tbl_vendor_mengikuti_paket`.`id_rup`
WHERE `tbl_vendor_mengikuti_paket`.`id_pemenang` = '130'
ERROR - 2024-05-11 14:48:29 --> Severity: Notice --> Trying to get property 'total_hasil_negosiasi' of non-object C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 242
ERROR - 2024-05-11 14:48:29 --> Severity: Notice --> Trying to get property 'total_hasil_negosiasi' of non-object C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 242
ERROR - 2024-05-11 14:48:30 --> Severity: Notice --> Trying to get property 'total_hasil_negosiasi' of non-object C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 242
ERROR - 2024-05-11 14:48:30 --> Severity: Notice --> Trying to get property 'total_hasil_negosiasi' of non-object C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 242
ERROR - 2024-05-11 14:48:30 --> Severity: Notice --> Trying to get property 'total_hasil_negosiasi' of non-object C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 242
ERROR - 2024-05-11 14:48:30 --> Severity: Notice --> Trying to get property 'total_hasil_negosiasi' of non-object C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 242
ERROR - 2024-05-11 14:49:20 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 242
ERROR - 2024-05-11 14:49:20 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 242
ERROR - 2024-05-11 14:49:20 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 242
ERROR - 2024-05-11 14:49:20 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 242
ERROR - 2024-05-11 14:49:20 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 242
ERROR - 2024-05-11 14:49:20 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 242
ERROR - 2024-05-11 14:50:03 --> Severity: Notice --> Trying to get property 'total_hasil_negosiasi' of non-object C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 242
ERROR - 2024-05-11 14:50:03 --> Severity: Notice --> Trying to get property 'total_hasil_negosiasi' of non-object C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 242
ERROR - 2024-05-11 14:50:03 --> Severity: Notice --> Trying to get property 'total_hasil_negosiasi' of non-object C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 242
ERROR - 2024-05-11 14:50:03 --> Severity: Notice --> Trying to get property 'total_hasil_negosiasi' of non-object C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 242
ERROR - 2024-05-11 14:50:03 --> Severity: Notice --> Trying to get property 'total_hasil_negosiasi' of non-object C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 242
ERROR - 2024-05-11 14:50:03 --> Severity: Notice --> Trying to get property 'total_hasil_negosiasi' of non-object C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 242
ERROR - 2024-05-11 14:50:43 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 242
ERROR - 2024-05-11 14:50:43 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 242
ERROR - 2024-05-11 14:50:43 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 242
ERROR - 2024-05-11 14:50:43 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 242
ERROR - 2024-05-11 14:50:43 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 242
ERROR - 2024-05-11 14:50:43 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 242
ERROR - 2024-05-11 14:53:36 --> Severity: error --> Exception: Call to undefined method M_laporan::get_pemenang() C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 235
ERROR - 2024-05-11 14:53:45 --> Severity: Notice --> Undefined variable: get_pemenang C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 241
ERROR - 2024-05-11 14:53:45 --> Severity: Notice --> Trying to get property 'total_hasil_negosiasi' of non-object C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 241
ERROR - 2024-05-11 14:53:45 --> Severity: Notice --> Undefined variable: get_pemenang C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 241
ERROR - 2024-05-11 14:53:45 --> Severity: Notice --> Trying to get property 'total_hasil_negosiasi' of non-object C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 241
ERROR - 2024-05-11 14:53:45 --> Severity: Notice --> Undefined variable: get_pemenang C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 241
ERROR - 2024-05-11 14:53:45 --> Severity: Notice --> Trying to get property 'total_hasil_negosiasi' of non-object C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 241
ERROR - 2024-05-11 14:53:45 --> Severity: Notice --> Undefined variable: get_pemenang C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 241
ERROR - 2024-05-11 14:53:45 --> Severity: Notice --> Trying to get property 'total_hasil_negosiasi' of non-object C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 241
ERROR - 2024-05-11 14:53:45 --> Severity: Notice --> Undefined variable: get_pemenang C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 241
ERROR - 2024-05-11 14:53:45 --> Severity: Notice --> Trying to get property 'total_hasil_negosiasi' of non-object C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 241
ERROR - 2024-05-11 14:53:45 --> Severity: Notice --> Undefined variable: get_pemenang C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 241
ERROR - 2024-05-11 14:53:45 --> Severity: Notice --> Trying to get property 'total_hasil_negosiasi' of non-object C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 241
ERROR - 2024-05-11 14:53:45 --> Severity: Notice --> Undefined variable: get_pemenang C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 241
ERROR - 2024-05-11 14:53:45 --> Severity: Notice --> Trying to get property 'total_hasil_negosiasi' of non-object C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 241
ERROR - 2024-05-11 14:53:45 --> Severity: Notice --> Undefined variable: get_pemenang C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 241
ERROR - 2024-05-11 14:53:45 --> Severity: Notice --> Trying to get property 'total_hasil_negosiasi' of non-object C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 241
ERROR - 2024-05-11 14:53:45 --> Severity: Notice --> Undefined variable: get_pemenang C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 241
ERROR - 2024-05-11 14:53:45 --> Severity: Notice --> Trying to get property 'total_hasil_negosiasi' of non-object C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 241
ERROR - 2024-05-11 14:53:45 --> Severity: Notice --> Undefined variable: get_pemenang C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 241
ERROR - 2024-05-11 14:53:45 --> Severity: Notice --> Trying to get property 'total_hasil_negosiasi' of non-object C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 241
ERROR - 2024-05-11 14:58:40 --> Severity: Notice --> Trying to get property 'total_hasil_negosiasi' of non-object C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 242
ERROR - 2024-05-11 14:58:40 --> Severity: Notice --> Trying to get property 'total_hasil_negosiasi' of non-object C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 242
ERROR - 2024-05-11 14:58:40 --> Severity: Notice --> Trying to get property 'total_hasil_negosiasi' of non-object C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 242
ERROR - 2024-05-11 14:58:40 --> Severity: Notice --> Trying to get property 'total_hasil_negosiasi' of non-object C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 242
ERROR - 2024-05-11 14:59:36 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_laporan\M_laporan.php 106
ERROR - 2024-05-11 14:59:36 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_laporan\M_laporan.php 106
ERROR - 2024-05-11 14:59:36 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_laporan\M_laporan.php 106
ERROR - 2024-05-11 14:59:36 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_laporan\M_laporan.php 106
ERROR - 2024-05-11 14:59:36 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_laporan\M_laporan.php 106
ERROR - 2024-05-11 14:59:36 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_laporan\M_laporan.php 106
ERROR - 2024-05-11 14:59:36 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_laporan\M_laporan.php 106
ERROR - 2024-05-11 14:59:36 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_laporan\M_laporan.php 106
ERROR - 2024-05-11 14:59:36 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_laporan\M_laporan.php 106
ERROR - 2024-05-11 14:59:36 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_laporan\M_laporan.php 106
ERROR - 2024-05-11 14:59:36 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_laporan\M_laporan.php 106
ERROR - 2024-05-11 14:59:36 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_laporan\M_laporan.php 106
ERROR - 2024-05-11 14:59:36 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_laporan\M_laporan.php 106
ERROR - 2024-05-11 14:59:36 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_laporan\M_laporan.php 106
ERROR - 2024-05-11 14:59:36 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_laporan\M_laporan.php 106
ERROR - 2024-05-11 14:59:36 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_laporan\M_laporan.php 106
ERROR - 2024-05-11 14:59:36 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_laporan\M_laporan.php 106
ERROR - 2024-05-11 14:59:36 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_laporan\M_laporan.php 106
ERROR - 2024-05-11 14:59:36 --> Severity: Notice --> Undefined index: length C:\laragon\www\jmto-eproc\application\models\M_laporan\M_laporan.php 135
ERROR - 2024-05-11 14:59:36 --> Severity: Notice --> Undefined index: length C:\laragon\www\jmto-eproc\application\models\M_laporan\M_laporan.php 136
ERROR - 2024-05-11 14:59:36 --> Severity: Notice --> Undefined index: start C:\laragon\www\jmto-eproc\application\models\M_laporan\M_laporan.php 136
ERROR - 2024-05-11 14:59:36 --> Severity: Notice --> Undefined index: start C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 233
ERROR - 2024-05-11 15:00:19 --> Severity: Notice --> Trying to get property 'total_hasil_negosiasi' of non-object C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 242
ERROR - 2024-05-11 15:00:19 --> Severity: Notice --> Trying to get property 'total_hasil_negosiasi' of non-object C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 242
ERROR - 2024-05-11 15:00:19 --> Severity: Notice --> Trying to get property 'total_hasil_negosiasi' of non-object C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 242
ERROR - 2024-05-11 15:00:19 --> Severity: Notice --> Trying to get property 'total_hasil_negosiasi' of non-object C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 242
ERROR - 2024-05-11 15:00:53 --> Severity: Notice --> Trying to get property 'total_hasil_negosiasi' of non-object C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 242
ERROR - 2024-05-11 15:00:53 --> Severity: Notice --> Trying to get property 'total_hasil_negosiasi' of non-object C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 242
ERROR - 2024-05-11 15:00:53 --> Severity: Notice --> Trying to get property 'total_hasil_negosiasi' of non-object C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 242
ERROR - 2024-05-11 15:00:53 --> Severity: Notice --> Trying to get property 'total_hasil_negosiasi' of non-object C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 242
ERROR - 2024-05-11 15:00:56 --> Severity: Notice --> Trying to get property 'total_hasil_negosiasi' of non-object C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 242
ERROR - 2024-05-11 15:00:56 --> Severity: Notice --> Trying to get property 'total_hasil_negosiasi' of non-object C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 242
ERROR - 2024-05-11 15:00:56 --> Severity: Notice --> Trying to get property 'total_hasil_negosiasi' of non-object C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 242
ERROR - 2024-05-11 15:00:56 --> Severity: Notice --> Trying to get property 'total_hasil_negosiasi' of non-object C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 242
ERROR - 2024-05-11 15:00:56 --> Severity: Notice --> Trying to get property 'total_hasil_negosiasi' of non-object C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 242
ERROR - 2024-05-11 15:00:56 --> Severity: Notice --> Trying to get property 'total_hasil_negosiasi' of non-object C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 242
ERROR - 2024-05-11 15:00:56 --> Severity: Notice --> Trying to get property 'total_hasil_negosiasi' of non-object C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 242
ERROR - 2024-05-11 15:00:57 --> Severity: Notice --> Trying to get property 'total_hasil_negosiasi' of non-object C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 242
ERROR - 2024-05-11 15:00:57 --> Severity: Notice --> Trying to get property 'total_hasil_negosiasi' of non-object C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 242
ERROR - 2024-05-11 15:00:57 --> Severity: Notice --> Trying to get property 'total_hasil_negosiasi' of non-object C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 242
ERROR - 2024-05-11 15:01:06 --> Severity: Notice --> Trying to get property 'total_hasil_negosiasi' of non-object C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 242
ERROR - 2024-05-11 15:01:06 --> Severity: Notice --> Trying to get property 'total_hasil_negosiasi' of non-object C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 242
ERROR - 2024-05-11 15:01:06 --> Severity: Notice --> Trying to get property 'total_hasil_negosiasi' of non-object C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 242
ERROR - 2024-05-11 15:01:06 --> Severity: Notice --> Trying to get property 'total_hasil_negosiasi' of non-object C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 242
ERROR - 2024-05-11 15:01:06 --> Severity: Notice --> Trying to get property 'total_hasil_negosiasi' of non-object C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 242
ERROR - 2024-05-11 15:01:06 --> Severity: Notice --> Trying to get property 'total_hasil_negosiasi' of non-object C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 242
ERROR - 2024-05-11 15:01:06 --> Severity: Notice --> Trying to get property 'total_hasil_negosiasi' of non-object C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 242
ERROR - 2024-05-11 15:01:06 --> Severity: Notice --> Trying to get property 'total_hasil_negosiasi' of non-object C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 242
ERROR - 2024-05-11 15:01:06 --> Severity: Notice --> Trying to get property 'total_hasil_negosiasi' of non-object C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 242
ERROR - 2024-05-11 15:01:06 --> Severity: Notice --> Trying to get property 'total_hasil_negosiasi' of non-object C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 242
ERROR - 2024-05-11 15:01:39 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 242
ERROR - 2024-05-11 15:01:39 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 242
ERROR - 2024-05-11 15:01:39 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 242
ERROR - 2024-05-11 15:01:39 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 242
ERROR - 2024-05-11 15:01:57 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 242
ERROR - 2024-05-11 15:01:57 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 242
ERROR - 2024-05-11 15:01:57 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 242
ERROR - 2024-05-11 15:01:57 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 242
ERROR - 2024-05-11 15:02:08 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 242
ERROR - 2024-05-11 15:02:08 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 242
ERROR - 2024-05-11 15:02:08 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 242
ERROR - 2024-05-11 15:02:08 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 242
ERROR - 2024-05-11 15:02:39 --> Severity: error --> Exception: Too few arguments to function M_laporan::get_pemenang(), 0 passed in C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php on line 235 and exactly 2 expected C:\laragon\www\jmto-eproc\application\models\M_laporan\M_laporan.php 157
ERROR - 2024-05-11 15:02:43 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_laporan\M_laporan.php 106
ERROR - 2024-05-11 15:02:43 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_laporan\M_laporan.php 106
ERROR - 2024-05-11 15:02:43 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_laporan\M_laporan.php 106
ERROR - 2024-05-11 15:02:43 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_laporan\M_laporan.php 106
ERROR - 2024-05-11 15:02:43 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_laporan\M_laporan.php 106
ERROR - 2024-05-11 15:02:43 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_laporan\M_laporan.php 106
ERROR - 2024-05-11 15:02:43 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_laporan\M_laporan.php 106
ERROR - 2024-05-11 15:02:43 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_laporan\M_laporan.php 106
ERROR - 2024-05-11 15:02:43 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_laporan\M_laporan.php 106
ERROR - 2024-05-11 15:02:43 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_laporan\M_laporan.php 106
ERROR - 2024-05-11 15:02:43 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_laporan\M_laporan.php 106
ERROR - 2024-05-11 15:02:43 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_laporan\M_laporan.php 106
ERROR - 2024-05-11 15:02:43 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_laporan\M_laporan.php 106
ERROR - 2024-05-11 15:02:43 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_laporan\M_laporan.php 106
ERROR - 2024-05-11 15:02:43 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_laporan\M_laporan.php 106
ERROR - 2024-05-11 15:02:43 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_laporan\M_laporan.php 106
ERROR - 2024-05-11 15:02:43 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_laporan\M_laporan.php 106
ERROR - 2024-05-11 15:02:43 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_laporan\M_laporan.php 106
ERROR - 2024-05-11 15:02:43 --> Severity: Notice --> Undefined index: length C:\laragon\www\jmto-eproc\application\models\M_laporan\M_laporan.php 135
ERROR - 2024-05-11 15:02:43 --> Severity: Notice --> Undefined index: length C:\laragon\www\jmto-eproc\application\models\M_laporan\M_laporan.php 136
ERROR - 2024-05-11 15:02:43 --> Severity: Notice --> Undefined index: start C:\laragon\www\jmto-eproc\application\models\M_laporan\M_laporan.php 136
ERROR - 2024-05-11 15:02:43 --> Severity: Notice --> Undefined index: start C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 233
ERROR - 2024-05-11 15:02:43 --> Severity: error --> Exception: Too few arguments to function M_laporan::get_pemenang(), 0 passed in C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php on line 235 and exactly 2 expected C:\laragon\www\jmto-eproc\application\models\M_laporan\M_laporan.php 157
ERROR - 2024-05-11 15:02:43 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\laragon\www\jmto-eproc\system\core\Exceptions.php:272) C:\laragon\www\jmto-eproc\system\core\Common.php 571
ERROR - 2024-05-11 15:02:55 --> Severity: Notice --> Undefined index: total_hasil_negosiasi C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 243
ERROR - 2024-05-11 15:02:55 --> Severity: Notice --> Undefined index: total_hasil_negosiasi C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 243
ERROR - 2024-05-11 15:02:55 --> Severity: Notice --> Undefined index: total_hasil_negosiasi C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 243
ERROR - 2024-05-11 15:02:55 --> Severity: Notice --> Undefined index: total_hasil_negosiasi C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 243
ERROR - 2024-05-11 15:02:56 --> Severity: Notice --> Undefined index: total_hasil_negosiasi C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 243
ERROR - 2024-05-11 15:02:56 --> Severity: Notice --> Undefined index: total_hasil_negosiasi C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 243
ERROR - 2024-05-11 15:02:56 --> Severity: Notice --> Undefined index: total_hasil_negosiasi C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 243
ERROR - 2024-05-11 15:02:56 --> Severity: Notice --> Undefined index: total_hasil_negosiasi C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 243
ERROR - 2024-05-11 15:02:56 --> Severity: Notice --> Undefined index: total_hasil_negosiasi C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 243
ERROR - 2024-05-11 15:02:56 --> Severity: Notice --> Undefined index: total_hasil_negosiasi C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 243
ERROR - 2024-05-11 15:02:59 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_laporan\M_laporan.php 106
ERROR - 2024-05-11 15:02:59 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_laporan\M_laporan.php 106
ERROR - 2024-05-11 15:02:59 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_laporan\M_laporan.php 106
ERROR - 2024-05-11 15:02:59 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_laporan\M_laporan.php 106
ERROR - 2024-05-11 15:02:59 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_laporan\M_laporan.php 106
ERROR - 2024-05-11 15:02:59 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_laporan\M_laporan.php 106
ERROR - 2024-05-11 15:02:59 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_laporan\M_laporan.php 106
ERROR - 2024-05-11 15:02:59 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_laporan\M_laporan.php 106
ERROR - 2024-05-11 15:02:59 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_laporan\M_laporan.php 106
ERROR - 2024-05-11 15:02:59 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_laporan\M_laporan.php 106
ERROR - 2024-05-11 15:02:59 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_laporan\M_laporan.php 106
ERROR - 2024-05-11 15:02:59 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_laporan\M_laporan.php 106
ERROR - 2024-05-11 15:02:59 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_laporan\M_laporan.php 106
ERROR - 2024-05-11 15:02:59 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_laporan\M_laporan.php 106
ERROR - 2024-05-11 15:02:59 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_laporan\M_laporan.php 106
ERROR - 2024-05-11 15:02:59 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_laporan\M_laporan.php 106
ERROR - 2024-05-11 15:02:59 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_laporan\M_laporan.php 106
ERROR - 2024-05-11 15:02:59 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_laporan\M_laporan.php 106
ERROR - 2024-05-11 15:02:59 --> Severity: Notice --> Undefined index: length C:\laragon\www\jmto-eproc\application\models\M_laporan\M_laporan.php 135
ERROR - 2024-05-11 15:02:59 --> Severity: Notice --> Undefined index: length C:\laragon\www\jmto-eproc\application\models\M_laporan\M_laporan.php 136
ERROR - 2024-05-11 15:02:59 --> Severity: Notice --> Undefined index: start C:\laragon\www\jmto-eproc\application\models\M_laporan\M_laporan.php 136
ERROR - 2024-05-11 15:02:59 --> Severity: Notice --> Undefined index: start C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 233
ERROR - 2024-05-11 15:02:59 --> Severity: Notice --> Undefined index: total_hasil_negosiasi C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 243
ERROR - 2024-05-11 15:02:59 --> Severity: Notice --> Undefined index: total_hasil_negosiasi C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 243
ERROR - 2024-05-11 15:02:59 --> Severity: Notice --> Undefined index: total_hasil_negosiasi C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 243
ERROR - 2024-05-11 15:02:59 --> Severity: Notice --> Undefined index: total_hasil_negosiasi C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 243
ERROR - 2024-05-11 15:02:59 --> Severity: Notice --> Undefined index: total_hasil_negosiasi C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 243
ERROR - 2024-05-11 15:02:59 --> Severity: Notice --> Undefined index: total_hasil_negosiasi C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 243
ERROR - 2024-05-11 15:02:59 --> Severity: Notice --> Undefined index: total_hasil_negosiasi C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 243
ERROR - 2024-05-11 15:02:59 --> Severity: Notice --> Undefined index: total_hasil_negosiasi C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 243
ERROR - 2024-05-11 15:02:59 --> Severity: Notice --> Undefined index: total_hasil_negosiasi C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 243
ERROR - 2024-05-11 15:02:59 --> Severity: Notice --> Undefined index: total_hasil_negosiasi C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 243
ERROR - 2024-05-11 15:02:59 --> Severity: Notice --> Undefined index: total_hasil_negosiasi C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 243
ERROR - 2024-05-11 15:02:59 --> Severity: Notice --> Undefined index: total_hasil_negosiasi C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 243
ERROR - 2024-05-11 15:02:59 --> Severity: Notice --> Undefined index: total_hasil_negosiasi C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 243
ERROR - 2024-05-11 15:02:59 --> Severity: Notice --> Undefined index: total_hasil_negosiasi C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 243
ERROR - 2024-05-11 15:02:59 --> Severity: Notice --> Undefined index: total_hasil_negosiasi C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 243
ERROR - 2024-05-11 15:02:59 --> Severity: Notice --> Undefined index: total_hasil_negosiasi C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 243
ERROR - 2024-05-11 15:02:59 --> Severity: Notice --> Undefined index: total_hasil_negosiasi C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 243
ERROR - 2024-05-11 15:02:59 --> Severity: Notice --> Undefined index: draw C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 254
ERROR - 2024-05-11 15:02:59 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_laporan\M_laporan.php 106
ERROR - 2024-05-11 15:02:59 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_laporan\M_laporan.php 106
ERROR - 2024-05-11 15:02:59 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_laporan\M_laporan.php 106
ERROR - 2024-05-11 15:02:59 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_laporan\M_laporan.php 106
ERROR - 2024-05-11 15:02:59 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_laporan\M_laporan.php 106
ERROR - 2024-05-11 15:02:59 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_laporan\M_laporan.php 106
ERROR - 2024-05-11 15:02:59 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_laporan\M_laporan.php 106
ERROR - 2024-05-11 15:02:59 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_laporan\M_laporan.php 106
ERROR - 2024-05-11 15:02:59 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_laporan\M_laporan.php 106
ERROR - 2024-05-11 15:02:59 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_laporan\M_laporan.php 106
ERROR - 2024-05-11 15:02:59 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_laporan\M_laporan.php 106
ERROR - 2024-05-11 15:02:59 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_laporan\M_laporan.php 106
ERROR - 2024-05-11 15:02:59 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_laporan\M_laporan.php 106
ERROR - 2024-05-11 15:02:59 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_laporan\M_laporan.php 106
ERROR - 2024-05-11 15:02:59 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_laporan\M_laporan.php 106
ERROR - 2024-05-11 15:02:59 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_laporan\M_laporan.php 106
ERROR - 2024-05-11 15:02:59 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_laporan\M_laporan.php 106
ERROR - 2024-05-11 15:02:59 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_laporan\M_laporan.php 106
ERROR - 2024-05-11 15:03:29 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 242
ERROR - 2024-05-11 15:03:29 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 242
ERROR - 2024-05-11 15:03:29 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 242
ERROR - 2024-05-11 15:03:30 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 242
ERROR - 2024-05-11 15:30:25 --> Severity: Notice --> A non well formed numeric value encountered C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 265
ERROR - 2024-05-11 15:30:25 --> Severity: Notice --> A non well formed numeric value encountered C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 266
ERROR - 2024-05-11 15:30:25 --> Severity: Notice --> A non well formed numeric value encountered C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 265
ERROR - 2024-05-11 15:30:25 --> Severity: Notice --> A non well formed numeric value encountered C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 266
ERROR - 2024-05-11 15:30:25 --> Severity: Notice --> A non well formed numeric value encountered C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 265
ERROR - 2024-05-11 15:30:25 --> Severity: Notice --> A non well formed numeric value encountered C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 266
ERROR - 2024-05-11 15:30:25 --> Severity: Notice --> A non well formed numeric value encountered C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 265
ERROR - 2024-05-11 15:30:25 --> Severity: Notice --> A non well formed numeric value encountered C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 266
ERROR - 2024-05-11 15:30:25 --> Severity: Notice --> A non well formed numeric value encountered C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 265
ERROR - 2024-05-11 15:30:25 --> Severity: Notice --> A non well formed numeric value encountered C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 266
ERROR - 2024-05-11 15:30:25 --> Severity: Notice --> A non well formed numeric value encountered C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 265
ERROR - 2024-05-11 15:30:25 --> Severity: Notice --> A non well formed numeric value encountered C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 266
ERROR - 2024-05-11 15:30:25 --> Severity: Notice --> A non well formed numeric value encountered C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 265
ERROR - 2024-05-11 15:30:25 --> Severity: Notice --> A non well formed numeric value encountered C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 266
ERROR - 2024-05-11 15:30:25 --> Severity: Notice --> A non well formed numeric value encountered C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 265
ERROR - 2024-05-11 15:30:25 --> Severity: Notice --> A non well formed numeric value encountered C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 266
ERROR - 2024-05-11 15:30:25 --> Severity: Notice --> A non well formed numeric value encountered C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 265
ERROR - 2024-05-11 15:30:25 --> Severity: Notice --> A non well formed numeric value encountered C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 266
ERROR - 2024-05-11 15:30:25 --> Severity: Notice --> A non well formed numeric value encountered C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 265
ERROR - 2024-05-11 15:30:25 --> Severity: Notice --> A non well formed numeric value encountered C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 266
ERROR - 2024-05-11 15:30:31 --> Severity: Notice --> A non well formed numeric value encountered C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 265
ERROR - 2024-05-11 15:30:31 --> Severity: Notice --> A non well formed numeric value encountered C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 266
ERROR - 2024-05-11 15:30:31 --> Severity: Notice --> A non well formed numeric value encountered C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 265
ERROR - 2024-05-11 15:30:31 --> Severity: Notice --> A non well formed numeric value encountered C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 266
ERROR - 2024-05-11 15:30:31 --> Severity: Notice --> A non well formed numeric value encountered C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 265
ERROR - 2024-05-11 15:30:31 --> Severity: Notice --> A non well formed numeric value encountered C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 266
ERROR - 2024-05-11 15:30:31 --> Severity: Notice --> A non well formed numeric value encountered C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 265
ERROR - 2024-05-11 15:30:31 --> Severity: Notice --> A non well formed numeric value encountered C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 266
ERROR - 2024-05-11 15:30:31 --> Severity: Notice --> A non well formed numeric value encountered C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 265
ERROR - 2024-05-11 15:30:31 --> Severity: Notice --> A non well formed numeric value encountered C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 266
ERROR - 2024-05-11 15:30:31 --> Severity: Notice --> A non well formed numeric value encountered C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 265
ERROR - 2024-05-11 15:30:31 --> Severity: Notice --> A non well formed numeric value encountered C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 266
ERROR - 2024-05-11 15:30:31 --> Severity: Notice --> A non well formed numeric value encountered C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 265
ERROR - 2024-05-11 15:30:31 --> Severity: Notice --> A non well formed numeric value encountered C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 266
ERROR - 2024-05-11 15:30:31 --> Severity: Notice --> A non well formed numeric value encountered C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 265
ERROR - 2024-05-11 15:30:31 --> Severity: Notice --> A non well formed numeric value encountered C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 266
ERROR - 2024-05-11 15:30:31 --> Severity: Notice --> A non well formed numeric value encountered C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 265
ERROR - 2024-05-11 15:30:31 --> Severity: Notice --> A non well formed numeric value encountered C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 266
ERROR - 2024-05-11 15:30:31 --> Severity: Notice --> A non well formed numeric value encountered C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 265
ERROR - 2024-05-11 15:30:31 --> Severity: Notice --> A non well formed numeric value encountered C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 266
ERROR - 2024-05-11 18:36:05 --> Severity: Warning --> number_format() expects parameter 1 to be float, array given C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 388
ERROR - 2024-05-11 18:36:05 --> Severity: Warning --> number_format() expects parameter 1 to be float, array given C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 389
ERROR - 2024-05-11 18:36:05 --> Severity: Warning --> number_format() expects parameter 1 to be float, array given C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 390
ERROR - 2024-05-11 18:36:05 --> Severity: Warning --> number_format() expects parameter 1 to be float, array given C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 391
ERROR - 2024-05-11 18:36:05 --> Severity: Warning --> number_format() expects parameter 1 to be float, array given C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 392
ERROR - 2024-05-11 18:36:05 --> Severity: Warning --> number_format() expects parameter 1 to be float, array given C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 393
ERROR - 2024-05-11 18:36:05 --> Severity: Warning --> number_format() expects parameter 1 to be float, array given C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 394
ERROR - 2024-05-11 18:36:05 --> Severity: Warning --> number_format() expects parameter 1 to be float, array given C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 395
ERROR - 2024-05-11 18:36:05 --> Severity: Warning --> number_format() expects parameter 1 to be float, array given C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 396
ERROR - 2024-05-11 18:36:05 --> Severity: Warning --> number_format() expects parameter 1 to be float, array given C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 397
ERROR - 2024-05-11 18:36:05 --> Severity: Warning --> number_format() expects parameter 1 to be float, array given C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 398
ERROR - 2024-05-11 18:36:05 --> Severity: Warning --> number_format() expects parameter 1 to be float, array given C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 399
ERROR - 2024-05-11 18:36:05 --> Severity: Warning --> number_format() expects parameter 1 to be float, array given C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 400
ERROR - 2024-05-11 20:16:16 --> Severity: error --> Exception: Call to undefined method M_laporan::sum_pemenang_cs() C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 417
ERROR - 2024-05-11 20:16:22 --> Severity: error --> Exception: Call to undefined method M_laporan::sum_pemenang_cs() C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 417
ERROR - 2024-05-11 20:16:57 --> Severity: error --> Exception: Call to undefined method M_laporan::get_pemenang() C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 341
ERROR - 2024-05-11 20:16:57 --> Severity: error --> Exception: Call to undefined method M_laporan::get_pemenang() C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 239
ERROR - 2024-05-11 20:16:57 --> Severity: error --> Exception: Call to undefined method M_laporan::get_pemenang() C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 290
ERROR - 2024-05-11 20:17:03 --> Severity: error --> Exception: Call to undefined method M_laporan::get_pemenang() C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 239
ERROR - 2024-05-11 20:17:03 --> Severity: error --> Exception: Call to undefined method M_laporan::get_pemenang() C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 290
ERROR - 2024-05-11 20:17:03 --> Severity: error --> Exception: Call to undefined method M_laporan::get_pemenang() C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 341
ERROR - 2024-05-11 20:19:07 --> Severity: Notice --> Undefined variable: tahun C:\laragon\www\jmto-eproc\application\models\M_laporan\M_laporan.php 357
ERROR - 2024-05-11 20:19:07 --> Severity: Notice --> Undefined variable: tahun C:\laragon\www\jmto-eproc\application\models\M_laporan\M_laporan.php 398
ERROR - 2024-05-11 20:19:07 --> Severity: Notice --> Undefined variable: tahun C:\laragon\www\jmto-eproc\application\models\M_laporan\M_laporan.php 439
ERROR - 2024-05-11 20:19:07 --> Severity: Notice --> Undefined variable: tahun C:\laragon\www\jmto-eproc\application\models\M_laporan\M_laporan.php 479
ERROR - 2024-05-11 20:19:07 --> Severity: Notice --> Undefined variable: tahun C:\laragon\www\jmto-eproc\application\models\M_laporan\M_laporan.php 519
ERROR - 2024-05-11 20:19:08 --> Severity: Notice --> Undefined variable: tahun C:\laragon\www\jmto-eproc\application\models\M_laporan\M_laporan.php 559
ERROR - 2024-05-11 20:19:08 --> Severity: Notice --> Undefined variable: tahun C:\laragon\www\jmto-eproc\application\models\M_laporan\M_laporan.php 599
ERROR - 2024-05-11 20:19:08 --> Severity: Notice --> Undefined variable: tahun C:\laragon\www\jmto-eproc\application\models\M_laporan\M_laporan.php 639
ERROR - 2024-05-11 20:19:08 --> Severity: Notice --> Undefined variable: tahun C:\laragon\www\jmto-eproc\application\models\M_laporan\M_laporan.php 679
ERROR - 2024-05-11 20:19:08 --> Severity: Notice --> Undefined variable: tahun C:\laragon\www\jmto-eproc\application\models\M_laporan\M_laporan.php 719
ERROR - 2024-05-11 20:19:08 --> Severity: Notice --> Undefined variable: tahun C:\laragon\www\jmto-eproc\application\models\M_laporan\M_laporan.php 759
ERROR - 2024-05-11 20:19:08 --> Severity: Notice --> Undefined variable: tahun C:\laragon\www\jmto-eproc\application\models\M_laporan\M_laporan.php 800
ERROR - 2024-05-11 20:19:08 --> Severity: Notice --> Undefined variable: tahun C:\laragon\www\jmto-eproc\application\models\M_laporan\M_laporan.php 840
ERROR - 2024-05-11 20:19:11 --> Severity: Notice --> Undefined variable: tahun C:\laragon\www\jmto-eproc\application\models\M_laporan\M_laporan.php 357
ERROR - 2024-05-11 20:19:11 --> Severity: Notice --> Undefined variable: tahun C:\laragon\www\jmto-eproc\application\models\M_laporan\M_laporan.php 398
ERROR - 2024-05-11 20:19:11 --> Severity: Notice --> Undefined variable: tahun C:\laragon\www\jmto-eproc\application\models\M_laporan\M_laporan.php 439
ERROR - 2024-05-11 20:19:11 --> Severity: Notice --> Undefined variable: tahun C:\laragon\www\jmto-eproc\application\models\M_laporan\M_laporan.php 479
ERROR - 2024-05-11 20:19:11 --> Severity: Notice --> Undefined variable: tahun C:\laragon\www\jmto-eproc\application\models\M_laporan\M_laporan.php 519
ERROR - 2024-05-11 20:19:11 --> Severity: Notice --> Undefined variable: tahun C:\laragon\www\jmto-eproc\application\models\M_laporan\M_laporan.php 559
ERROR - 2024-05-11 20:19:11 --> Severity: Notice --> Undefined variable: tahun C:\laragon\www\jmto-eproc\application\models\M_laporan\M_laporan.php 599
ERROR - 2024-05-11 20:19:11 --> Severity: Notice --> Undefined variable: tahun C:\laragon\www\jmto-eproc\application\models\M_laporan\M_laporan.php 639
ERROR - 2024-05-11 20:19:11 --> Severity: Notice --> Undefined variable: tahun C:\laragon\www\jmto-eproc\application\models\M_laporan\M_laporan.php 679
ERROR - 2024-05-11 20:19:11 --> Severity: Notice --> Undefined variable: tahun C:\laragon\www\jmto-eproc\application\models\M_laporan\M_laporan.php 719
ERROR - 2024-05-11 20:19:11 --> Severity: Notice --> Undefined variable: tahun C:\laragon\www\jmto-eproc\application\models\M_laporan\M_laporan.php 759
ERROR - 2024-05-11 20:19:11 --> Severity: Notice --> Undefined variable: tahun C:\laragon\www\jmto-eproc\application\models\M_laporan\M_laporan.php 800
ERROR - 2024-05-11 20:19:11 --> Severity: Notice --> Undefined variable: tahun C:\laragon\www\jmto-eproc\application\models\M_laporan\M_laporan.php 840
ERROR - 2024-05-11 20:19:13 --> Severity: Notice --> Undefined variable: tahun C:\laragon\www\jmto-eproc\application\models\M_laporan\M_laporan.php 357
ERROR - 2024-05-11 20:19:13 --> Severity: Notice --> Undefined variable: tahun C:\laragon\www\jmto-eproc\application\models\M_laporan\M_laporan.php 398
ERROR - 2024-05-11 20:19:13 --> Severity: Notice --> Undefined variable: tahun C:\laragon\www\jmto-eproc\application\models\M_laporan\M_laporan.php 439
ERROR - 2024-05-11 20:19:13 --> Severity: Notice --> Undefined variable: tahun C:\laragon\www\jmto-eproc\application\models\M_laporan\M_laporan.php 479
ERROR - 2024-05-11 20:19:13 --> Severity: Notice --> Undefined variable: tahun C:\laragon\www\jmto-eproc\application\models\M_laporan\M_laporan.php 519
ERROR - 2024-05-11 20:19:13 --> Severity: Notice --> Undefined variable: tahun C:\laragon\www\jmto-eproc\application\models\M_laporan\M_laporan.php 559
ERROR - 2024-05-11 20:19:13 --> Severity: Notice --> Undefined variable: tahun C:\laragon\www\jmto-eproc\application\models\M_laporan\M_laporan.php 599
ERROR - 2024-05-11 20:19:13 --> Severity: Notice --> Undefined variable: tahun C:\laragon\www\jmto-eproc\application\models\M_laporan\M_laporan.php 639
ERROR - 2024-05-11 20:19:13 --> Severity: Notice --> Undefined variable: tahun C:\laragon\www\jmto-eproc\application\models\M_laporan\M_laporan.php 679
ERROR - 2024-05-11 20:19:13 --> Severity: Notice --> Undefined variable: tahun C:\laragon\www\jmto-eproc\application\models\M_laporan\M_laporan.php 719
ERROR - 2024-05-11 20:19:13 --> Severity: Notice --> Undefined variable: tahun C:\laragon\www\jmto-eproc\application\models\M_laporan\M_laporan.php 759
ERROR - 2024-05-11 20:19:13 --> Severity: Notice --> Undefined variable: tahun C:\laragon\www\jmto-eproc\application\models\M_laporan\M_laporan.php 800
ERROR - 2024-05-11 20:19:13 --> Severity: Notice --> Undefined variable: tahun C:\laragon\www\jmto-eproc\application\models\M_laporan\M_laporan.php 840
ERROR - 2024-05-11 20:35:10 --> Severity: error --> Exception: Call to undefined method M_laporan::sum_keseluruhan_hps_cs() C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 504
ERROR - 2024-05-11 20:35:24 --> Severity: error --> Exception: Call to undefined method M_laporan::sum_keseluruhan_hps_cs() C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 504
ERROR - 2024-05-11 20:43:29 --> Severity: error --> Exception: Unsupported operand types C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 534
ERROR - 2024-05-11 20:43:40 --> Severity: error --> Exception: Unsupported operand types C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 534
ERROR - 2024-05-11 21:52:45 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): A connection attempt failed because the connected party did not properly respond after a period of time, or established connection failed because connected host has failed to respond.
 C:\laragon\www\jmto-eproc\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2024-05-11 21:52:45 --> Unable to connect to the database
