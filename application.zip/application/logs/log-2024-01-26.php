<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2024-01-26 16:52:39 --> Severity: Notice --> Undefined variable: total_barang_semua_paket C:\laragon\www\jmto-eproc\application\views\administrator\laporan\ajax_total.php 43
ERROR - 2024-01-26 16:52:39 --> Severity: Notice --> Undefined variable: total_pemborongan_semua_paket C:\laragon\www\jmto-eproc\application\views\administrator\laporan\ajax_total.php 43
ERROR - 2024-01-26 16:52:39 --> Severity: Notice --> Undefined variable: total_konsultansi_semua_paket C:\laragon\www\jmto-eproc\application\views\administrator\laporan\ajax_total.php 43
ERROR - 2024-01-26 16:52:39 --> Severity: Notice --> Undefined variable: total_lain_semua_paket C:\laragon\www\jmto-eproc\application\views\administrator\laporan\ajax_total.php 43
ERROR - 2024-01-26 16:52:39 --> Severity: Notice --> Undefined variable: total_barang_semua_paket C:\laragon\www\jmto-eproc\application\views\administrator\laporan\ajax_total.php 66
ERROR - 2024-01-26 16:52:39 --> Severity: Notice --> Undefined variable: total_pemborongan_semua_paket C:\laragon\www\jmto-eproc\application\views\administrator\laporan\ajax_total.php 66
ERROR - 2024-01-26 16:52:39 --> Severity: Notice --> Undefined variable: total_konsultansi_semua_paket C:\laragon\www\jmto-eproc\application\views\administrator\laporan\ajax_total.php 66
ERROR - 2024-01-26 16:52:39 --> Severity: Notice --> Undefined variable: total_lain_semua_paket C:\laragon\www\jmto-eproc\application\views\administrator\laporan\ajax_total.php 66
ERROR - 2024-01-26 16:52:39 --> Severity: Notice --> Undefined variable: total_barang_semua_paket C:\laragon\www\jmto-eproc\application\views\administrator\laporan\ajax_total.php 88
ERROR - 2024-01-26 16:52:39 --> Severity: Notice --> Undefined variable: total_pemborongan_semua_paket C:\laragon\www\jmto-eproc\application\views\administrator\laporan\ajax_total.php 88
ERROR - 2024-01-26 16:52:39 --> Severity: Notice --> Undefined variable: total_konsultansi_semua_paket C:\laragon\www\jmto-eproc\application\views\administrator\laporan\ajax_total.php 88
ERROR - 2024-01-26 16:52:39 --> Severity: Notice --> Undefined variable: total_lain_semua_paket C:\laragon\www\jmto-eproc\application\views\administrator\laporan\ajax_total.php 88
ERROR - 2024-01-26 16:52:39 --> Severity: Notice --> Undefined variable: total_barang_semua_paket C:\laragon\www\jmto-eproc\application\views\administrator\laporan\ajax_total.php 111
ERROR - 2024-01-26 16:52:39 --> Severity: Notice --> Undefined variable: total_pemborongan_semua_paket C:\laragon\www\jmto-eproc\application\views\administrator\laporan\ajax_total.php 111
ERROR - 2024-01-26 16:52:39 --> Severity: Notice --> Undefined variable: total_konsultansi_semua_paket C:\laragon\www\jmto-eproc\application\views\administrator\laporan\ajax_total.php 111
ERROR - 2024-01-26 16:52:39 --> Severity: Notice --> Undefined variable: total_lain_semua_paket C:\laragon\www\jmto-eproc\application\views\administrator\laporan\ajax_total.php 111
