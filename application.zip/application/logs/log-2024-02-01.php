<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2024-02-01 00:05:54 --> Severity: Notice --> Undefined variable: peserta_tender_pq_penawaran C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1285
ERROR - 2024-02-01 00:05:54 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1285
ERROR - 2024-02-01 00:05:55 --> Severity: Notice --> Undefined variable: peserta_tender_pq_penawaran C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1285
ERROR - 2024-02-01 00:05:55 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1285
ERROR - 2024-02-01 00:05:55 --> Severity: Notice --> Undefined variable: peserta_tender_pq_penawaran C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1285
ERROR - 2024-02-01 00:05:55 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1285
ERROR - 2024-02-01 00:05:56 --> Severity: Notice --> Undefined variable: peserta_tender_pq_penawaran C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1285
ERROR - 2024-02-01 00:05:56 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1285
ERROR - 2024-02-01 00:06:06 --> Severity: Notice --> Undefined variable: peserta_tender_pq_penawaran C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1285
ERROR - 2024-02-01 00:06:06 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1285
ERROR - 2024-02-01 00:06:07 --> Severity: Notice --> Undefined variable: peserta_tender_pq_penawaran C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1285
ERROR - 2024-02-01 00:06:07 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1285
ERROR - 2024-02-01 00:06:08 --> Severity: Notice --> Undefined variable: peserta_tender_pq_penawaran C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1285
ERROR - 2024-02-01 00:06:08 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1285
ERROR - 2024-02-01 00:06:09 --> Severity: Notice --> Undefined variable: peserta_tender_pq_penawaran C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1285
ERROR - 2024-02-01 00:06:09 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1285
