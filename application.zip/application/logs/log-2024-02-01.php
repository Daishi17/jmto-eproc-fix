<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2024-02-01 14:55:20 --> Severity: Notice --> Undefined variable: peserta_tender_pq_penawaran C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1285
ERROR - 2024-02-01 14:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1285
ERROR - 2024-02-01 14:55:24 --> Severity: Notice --> Undefined variable: peserta_tender_pq_penawaran C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1285
ERROR - 2024-02-01 14:55:24 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1285
ERROR - 2024-02-01 14:55:29 --> Severity: Notice --> Undefined variable: peserta_tender_pq_penawaran C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1285
ERROR - 2024-02-01 14:55:29 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1285
ERROR - 2024-02-01 14:55:36 --> Severity: Notice --> Undefined variable: peserta_tender_pq_penawaran C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1285
ERROR - 2024-02-01 14:55:36 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1285
ERROR - 2024-02-01 15:04:21 --> Query error: MySQL server has gone away - Invalid query: SELECT *
FROM `tbl_rup`
WHERE `tbl_rup`.`id_rup` = '220'
ERROR - 2024-02-01 15:04:22 --> Query error: MySQL server has gone away - Invalid query: SELECT *
FROM `tbl_vendor_mengikuti_paket`
LEFT JOIN `tbl_vendor` ON `tbl_vendor_mengikuti_paket`.`id_vendor` = `tbl_vendor`.`id_vendor`
WHERE `tbl_vendor_mengikuti_paket`.`id_vendor_mengikuti_paket` = '137'
ERROR - 2024-02-01 15:14:57 --> Query error: MySQL server has gone away - Invalid query: SELECT *
FROM `tbl_vendor_mengikuti_paket`
LEFT JOIN `tbl_rup` ON `tbl_vendor_mengikuti_paket`.`id_rup` = `tbl_rup`.`id_rup`
LEFT JOIN `tbl_vendor` ON `tbl_vendor_mengikuti_paket`.`id_vendor` = `tbl_vendor`.`id_vendor`
WHERE `tbl_vendor_mengikuti_paket`.`id_rup` = '220'
AND `tbl_vendor_mengikuti_paket`.`ev_kualifikasi_akhir` > 60
ORDER BY `tbl_rup`.`id_rup` DESC
 LIMIT 10
ERROR - 2024-02-01 15:14:57 --> Query error: MySQL server has gone away - Invalid query: SELECT *
FROM `tbl_vendor_mengikuti_paket`
LEFT JOIN `tbl_rup` ON `tbl_vendor_mengikuti_paket`.`id_rup` = `tbl_rup`.`id_rup`
LEFT JOIN `tbl_vendor` ON `tbl_vendor_mengikuti_paket`.`id_vendor` = `tbl_vendor`.`id_vendor`
WHERE `tbl_vendor_mengikuti_paket`.`id_rup` = '220'
AND `tbl_vendor_mengikuti_paket`.`ev_kualifikasi_akhir` > 60
ORDER BY `tbl_rup`.`id_rup` DESC
 LIMIT 10
ERROR - 2024-02-01 15:14:57 --> Query error: MySQL server has gone away - Invalid query: SELECT *
FROM `tbl_vendor_mengikuti_paket`
LEFT JOIN `tbl_rup` ON `tbl_vendor_mengikuti_paket`.`id_rup` = `tbl_rup`.`id_rup`
LEFT JOIN `tbl_vendor` ON `tbl_vendor_mengikuti_paket`.`id_vendor` = `tbl_vendor`.`id_vendor`
WHERE `tbl_vendor_mengikuti_paket`.`id_rup` = '220'
AND `tbl_vendor_mengikuti_paket`.`ev_kualifikasi_akhir` > 60
ORDER BY `tbl_rup`.`id_rup` DESC
 LIMIT 10
ERROR - 2024-02-01 15:15:03 --> Query error: MySQL server has gone away - Invalid query: SELECT *
FROM `tbl_rup`
WHERE `tbl_rup`.`id_rup` = '220'
ERROR - 2024-02-01 15:17:36 --> Severity: Notice --> Undefined variable: peserta_tender_pq_penawaran C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1285
ERROR - 2024-02-01 15:17:36 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1285
ERROR - 2024-02-01 15:17:44 --> Severity: Notice --> Undefined variable: peserta_tender_pq_penawaran C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1285
ERROR - 2024-02-01 15:17:44 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1285
ERROR - 2024-02-01 15:17:51 --> Severity: Notice --> Undefined variable: peserta_tender_pq_penawaran C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1285
ERROR - 2024-02-01 15:17:51 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1285
ERROR - 2024-02-01 15:17:59 --> Severity: Notice --> Undefined variable: peserta_tender_pq_penawaran C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1285
ERROR - 2024-02-01 15:17:59 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1285
ERROR - 2024-02-01 15:17:59 --> Query error: MySQL server has gone away - Invalid query: SELECT *
FROM `tbl_vendor_mengikuti_paket`
LEFT JOIN `tbl_vendor` ON `tbl_vendor_mengikuti_paket`.`id_vendor` = `tbl_vendor`.`id_vendor`
WHERE `tbl_vendor_mengikuti_paket`.`id_rup` = '220'
AND `tbl_vendor_mengikuti_paket`.`sts_mengikuti_paket` = 1
ORDER BY `tbl_vendor_mengikuti_paket`.`id_rup` DESC
 LIMIT 10
ERROR - 2024-02-01 15:17:59 --> Query error: MySQL server has gone away - Invalid query: SELECT *
FROM `tbl_ba_teknis_detail`
WHERE `id_rup` = '220'
ERROR - 2024-02-01 15:17:59 --> Query error: MySQL server has gone away - Invalid query: SELECT *
FROM `tbl_vendor_mengikuti_paket`
LEFT JOIN `tbl_rup` ON `tbl_vendor_mengikuti_paket`.`id_rup` = `tbl_rup`.`id_rup`
LEFT JOIN `tbl_vendor` ON `tbl_vendor_mengikuti_paket`.`id_vendor` = `tbl_vendor`.`id_vendor`
WHERE `tbl_vendor_mengikuti_paket`.`id_rup` = '220'
AND `tbl_vendor_mengikuti_paket`.`ev_keuangan` > 60
AND `tbl_vendor_mengikuti_paket`.`ev_teknis` > 60
ORDER BY `tbl_rup`.`id_rup` DESC
 LIMIT 10
ERROR - 2024-02-01 15:18:15 --> Query error: MySQL server has gone away - Invalid query: SELECT *
FROM `tbl_vendor_mengikuti_paket`
LEFT JOIN `tbl_rup` ON `tbl_vendor_mengikuti_paket`.`id_rup` = `tbl_rup`.`id_rup`
LEFT JOIN `tbl_vendor` ON `tbl_vendor_mengikuti_paket`.`id_vendor` = `tbl_vendor`.`id_vendor`
WHERE `tbl_vendor_mengikuti_paket`.`id_rup` = '220'
AND `tbl_vendor_mengikuti_paket`.`ev_kualifikasi_akhir` > 60
AND `tbl_vendor_mengikuti_paket`.`file1_administrasi` IS NOT NULL
ORDER BY `tbl_rup`.`id_rup` DESC
 LIMIT 10
ERROR - 2024-02-01 15:18:28 --> Severity: Notice --> Undefined variable: peserta_tender_pq_penawaran C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1285
ERROR - 2024-02-01 15:18:28 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1285
ERROR - 2024-02-01 15:18:44 --> Severity: Notice --> Undefined variable: peserta_tender_pq_penawaran C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1285
ERROR - 2024-02-01 15:18:44 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1285
ERROR - 2024-02-01 15:18:50 --> Severity: Notice --> Undefined variable: peserta_tender_pq_penawaran C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1285
ERROR - 2024-02-01 15:18:50 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1285
ERROR - 2024-02-01 15:18:50 --> Query error: MySQL server has gone away - Invalid query: SELECT *
FROM `tbl_rup`
LEFT JOIN `tbl_departemen` ON `tbl_rup`.`id_departemen` = `tbl_departemen`.`id_departemen`
LEFT JOIN `tbl_jadwal_tender` ON `tbl_rup`.`id_jadwal_tender` = `tbl_jadwal_tender`.`id_jadwal_tender`
LEFT JOIN `tbl_section` ON `tbl_rup`.`id_section` = `tbl_section`.`id_section`
LEFT JOIN `tbl_rkap` ON `tbl_rup`.`id_rkap` = `tbl_rkap`.`id_rkap`
LEFT JOIN `tbl_provinsi` ON `tbl_rup`.`id_provinsi` = `tbl_provinsi`.`id_provinsi`
LEFT JOIN `tbl_kabupaten` ON `tbl_rup`.`id_kabupaten` = `tbl_kabupaten`.`id_kabupaten`
LEFT JOIN `tbl_jenis_pengadaan` ON `tbl_rup`.`id_jenis_pengadaan` = `tbl_jenis_pengadaan`.`id_jenis_pengadaan`
LEFT JOIN `tbl_metode_pengadaan` ON `tbl_rup`.`id_metode_pengadaan` = `tbl_metode_pengadaan`.`id_metode_pengadaan`
LEFT JOIN `tbl_jenis_anggaran` ON `tbl_rup`.`id_jenis_anggaran` = `tbl_jenis_anggaran`.`id_jenis_anggaran`
LEFT JOIN `mst_ruas` ON `tbl_rup`.`id_ruas` = `mst_ruas`.`id_ruas`
WHERE `id_url_rup` = '9ae6f9eed2d5426393173dc43136c3b7'
ERROR - 2024-02-01 15:18:50 --> Query error: MySQL server has gone away - Invalid query: SELECT *
FROM `tbl_ba_teknis_detail`
WHERE `id_rup` = '220'
ERROR - 2024-02-01 15:19:31 --> Severity: Notice --> Undefined variable: peserta_tender_pq_penawaran C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1285
ERROR - 2024-02-01 15:19:31 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1285
ERROR - 2024-02-01 15:19:35 --> Severity: Notice --> Undefined variable: peserta_tender_pq_penawaran C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1285
ERROR - 2024-02-01 15:19:35 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1285
ERROR - 2024-02-01 15:19:41 --> Severity: Notice --> Undefined variable: peserta_tender_pq_penawaran C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1285
ERROR - 2024-02-01 15:19:41 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1285
ERROR - 2024-02-01 15:19:51 --> Severity: Notice --> Undefined variable: peserta_tender_pq_penawaran C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1285
ERROR - 2024-02-01 15:19:51 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1285
ERROR - 2024-02-01 15:19:52 --> Query error: MySQL server has gone away - Invalid query: SELECT *
FROM `tbl_vendor_mengikuti_paket`
LEFT JOIN `tbl_vendor` ON `tbl_vendor_mengikuti_paket`.`id_vendor` = `tbl_vendor`.`id_vendor`
WHERE `tbl_vendor_mengikuti_paket`.`id_rup` = '220'
AND `tbl_vendor_mengikuti_paket`.`sts_mengikuti_paket` = 1
ORDER BY `tbl_vendor_mengikuti_paket`.`id_rup` DESC
 LIMIT 10
ERROR - 2024-02-01 15:20:09 --> Severity: Notice --> Undefined variable: peserta_tender_pq_penawaran C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1285
ERROR - 2024-02-01 15:20:09 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1285
ERROR - 2024-02-01 15:20:18 --> Severity: Notice --> Undefined variable: peserta_tender_pq_penawaran C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1285
ERROR - 2024-02-01 15:20:18 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1285
ERROR - 2024-02-01 15:20:20 --> Severity: Notice --> Undefined variable: peserta_tender_pq_penawaran C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1285
ERROR - 2024-02-01 15:20:20 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1285
ERROR - 2024-02-01 15:20:31 --> Severity: Notice --> Undefined variable: peserta_tender_pq_penawaran C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1285
ERROR - 2024-02-01 15:20:31 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1285
ERROR - 2024-02-01 15:20:32 --> Query error: MySQL server has gone away - Invalid query: SELECT *
FROM `tbl_vendor_mengikuti_paket`
LEFT JOIN `tbl_rup` ON `tbl_vendor_mengikuti_paket`.`id_rup` = `tbl_rup`.`id_rup`
LEFT JOIN `tbl_vendor` ON `tbl_vendor_mengikuti_paket`.`id_vendor` = `tbl_vendor`.`id_vendor`
WHERE `tbl_vendor_mengikuti_paket`.`id_rup` = '220'
AND `tbl_vendor_mengikuti_paket`.`ev_keuangan` > 60
AND `tbl_vendor_mengikuti_paket`.`ev_teknis` > 60
ORDER BY `tbl_rup`.`id_rup` DESC
 LIMIT 10
ERROR - 2024-02-01 15:20:32 --> Query error: MySQL server has gone away - Invalid query: SELECT *
FROM `tbl_vendor_mengikuti_paket`
LEFT JOIN `tbl_rup` ON `tbl_vendor_mengikuti_paket`.`id_rup` = `tbl_rup`.`id_rup`
LEFT JOIN `tbl_vendor` ON `tbl_vendor_mengikuti_paket`.`id_vendor` = `tbl_vendor`.`id_vendor`
WHERE `tbl_vendor_mengikuti_paket`.`id_rup` = '220'
AND `tbl_vendor_mengikuti_paket`.`ev_keuangan` > 60
AND `tbl_vendor_mengikuti_paket`.`ev_teknis` > 60
ORDER BY `tbl_rup`.`id_rup` DESC
 LIMIT 10
ERROR - 2024-02-01 15:20:32 --> Query error: MySQL server has gone away - Invalid query: SELECT *
FROM `tbl_vendor_mengikuti_paket`
LEFT JOIN `tbl_vendor` ON `tbl_vendor_mengikuti_paket`.`id_vendor` = `tbl_vendor`.`id_vendor`
WHERE `tbl_vendor_mengikuti_paket`.`id_rup` = '220'
AND `tbl_vendor_mengikuti_paket`.`sts_mengikuti_paket` = 1
ORDER BY `tbl_vendor_mengikuti_paket`.`id_rup` DESC
 LIMIT 10
ERROR - 2024-02-01 15:20:59 --> Severity: Notice --> Undefined variable: peserta_tender_pq_penawaran C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1285
ERROR - 2024-02-01 15:20:59 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1285
ERROR - 2024-02-01 15:21:04 --> Severity: Notice --> Undefined variable: peserta_tender_pq_penawaran C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1285
ERROR - 2024-02-01 15:21:04 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1285
ERROR - 2024-02-01 15:21:09 --> Severity: Notice --> Undefined variable: peserta_tender_pq_penawaran C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1285
ERROR - 2024-02-01 15:21:09 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1285
ERROR - 2024-02-01 15:21:11 --> Severity: Notice --> Undefined variable: peserta_tender_pq_penawaran C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1285
ERROR - 2024-02-01 15:21:11 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1285
ERROR - 2024-02-01 15:23:06 --> Severity: Notice --> Undefined variable: peserta_tender_pq_penawaran C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1285
ERROR - 2024-02-01 15:23:06 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1285
ERROR - 2024-02-01 15:23:11 --> Severity: Notice --> Undefined variable: peserta_tender_pq_penawaran C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1285
ERROR - 2024-02-01 15:23:11 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1285
ERROR - 2024-02-01 15:23:13 --> Severity: Notice --> Undefined variable: peserta_tender_pq_penawaran C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1285
ERROR - 2024-02-01 15:23:13 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1285
ERROR - 2024-02-01 15:23:19 --> Severity: Notice --> Undefined variable: peserta_tender_pq_penawaran C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1285
ERROR - 2024-02-01 15:23:19 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1285
