<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2024-05-13 00:06:29 --> Severity: Notice --> Undefined index: hasil_angka C:\laragon\www\jmto-eproc\application\views\administrator\penilaian_kinerja\buat_penilaian.php 156
ERROR - 2024-05-13 00:13:53 --> Severity: Notice --> Undefined variable: get_pelaksanaan_manager C:\laragon\www\jmto-eproc\application\views\administrator\penilaian_kinerja\buat_penilaian.php 294
ERROR - 2024-05-13 00:13:53 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\administrator\penilaian_kinerja\buat_penilaian.php 294
ERROR - 2024-05-13 00:13:53 --> Severity: Notice --> Undefined variable: get_pelaksanaan_manager C:\laragon\www\jmto-eproc\application\views\administrator\penilaian_kinerja\buat_penilaian.php 298
ERROR - 2024-05-13 00:13:53 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\administrator\penilaian_kinerja\buat_penilaian.php 298
ERROR - 2024-05-13 00:13:53 --> Severity: Notice --> Undefined variable: get_pelaksanaan_manager C:\laragon\www\jmto-eproc\application\views\administrator\penilaian_kinerja\buat_penilaian.php 302
ERROR - 2024-05-13 00:13:53 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\administrator\penilaian_kinerja\buat_penilaian.php 302
ERROR - 2024-05-13 00:13:53 --> Severity: Notice --> Undefined variable: get_pelaksanaan_manager C:\laragon\www\jmto-eproc\application\views\administrator\penilaian_kinerja\buat_penilaian.php 306
ERROR - 2024-05-13 00:13:53 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\administrator\penilaian_kinerja\buat_penilaian.php 306
ERROR - 2024-05-13 00:13:53 --> Severity: Notice --> Undefined variable: get_pelaksanaan_manager C:\laragon\www\jmto-eproc\application\views\administrator\penilaian_kinerja\buat_penilaian.php 310
ERROR - 2024-05-13 00:13:53 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\administrator\penilaian_kinerja\buat_penilaian.php 310
ERROR - 2024-05-13 00:13:53 --> Severity: Notice --> Undefined variable: get_pelaksanaan_manager C:\laragon\www\jmto-eproc\application\views\administrator\penilaian_kinerja\buat_penilaian.php 333
ERROR - 2024-05-13 00:13:53 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\administrator\penilaian_kinerja\buat_penilaian.php 333
ERROR - 2024-05-13 00:13:53 --> Severity: Notice --> Undefined variable: get_pelaksanaan_manager C:\laragon\www\jmto-eproc\application\views\administrator\penilaian_kinerja\buat_penilaian.php 334
ERROR - 2024-05-13 00:13:53 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\administrator\penilaian_kinerja\buat_penilaian.php 334
ERROR - 2024-05-13 00:13:53 --> Severity: Notice --> Undefined variable: get_pelaksanaan_manager C:\laragon\www\jmto-eproc\application\views\administrator\penilaian_kinerja\buat_penilaian.php 335
ERROR - 2024-05-13 00:13:53 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\administrator\penilaian_kinerja\buat_penilaian.php 335
ERROR - 2024-05-13 00:13:53 --> Severity: Notice --> Undefined variable: get_pelaksanaan_manager C:\laragon\www\jmto-eproc\application\views\administrator\penilaian_kinerja\buat_penilaian.php 340
ERROR - 2024-05-13 00:13:53 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\administrator\penilaian_kinerja\buat_penilaian.php 340
ERROR - 2024-05-13 00:13:53 --> Severity: Notice --> Undefined variable: get_pelaksanaan_manager C:\laragon\www\jmto-eproc\application\views\administrator\penilaian_kinerja\buat_penilaian.php 341
ERROR - 2024-05-13 00:13:53 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\administrator\penilaian_kinerja\buat_penilaian.php 341
ERROR - 2024-05-13 00:13:53 --> Severity: Notice --> Undefined variable: get_pelaksanaan_manager C:\laragon\www\jmto-eproc\application\views\administrator\penilaian_kinerja\buat_penilaian.php 342
ERROR - 2024-05-13 00:13:53 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\administrator\penilaian_kinerja\buat_penilaian.php 342
ERROR - 2024-05-13 00:13:53 --> Severity: Notice --> Undefined variable: get_pelaksanaan_manager C:\laragon\www\jmto-eproc\application\views\administrator\penilaian_kinerja\buat_penilaian.php 347
ERROR - 2024-05-13 00:13:53 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\administrator\penilaian_kinerja\buat_penilaian.php 347
ERROR - 2024-05-13 00:13:53 --> Severity: Notice --> Undefined variable: get_pelaksanaan_manager C:\laragon\www\jmto-eproc\application\views\administrator\penilaian_kinerja\buat_penilaian.php 348
ERROR - 2024-05-13 00:13:53 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\administrator\penilaian_kinerja\buat_penilaian.php 348
ERROR - 2024-05-13 00:13:53 --> Severity: Notice --> Undefined variable: get_pelaksanaan_manager C:\laragon\www\jmto-eproc\application\views\administrator\penilaian_kinerja\buat_penilaian.php 349
ERROR - 2024-05-13 00:13:53 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\administrator\penilaian_kinerja\buat_penilaian.php 349
ERROR - 2024-05-13 00:13:53 --> Severity: Notice --> Undefined variable: get_pelaksanaan_manager C:\laragon\www\jmto-eproc\application\views\administrator\penilaian_kinerja\buat_penilaian.php 354
ERROR - 2024-05-13 00:13:53 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\administrator\penilaian_kinerja\buat_penilaian.php 354
ERROR - 2024-05-13 00:13:53 --> Severity: Notice --> Undefined variable: get_pelaksanaan_manager C:\laragon\www\jmto-eproc\application\views\administrator\penilaian_kinerja\buat_penilaian.php 355
ERROR - 2024-05-13 00:13:53 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\administrator\penilaian_kinerja\buat_penilaian.php 355
ERROR - 2024-05-13 00:13:53 --> Severity: Notice --> Undefined variable: get_pelaksanaan_manager C:\laragon\www\jmto-eproc\application\views\administrator\penilaian_kinerja\buat_penilaian.php 356
ERROR - 2024-05-13 00:13:53 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\administrator\penilaian_kinerja\buat_penilaian.php 356
ERROR - 2024-05-13 00:13:53 --> Severity: Notice --> Undefined variable: get_pelaksanaan_manager C:\laragon\www\jmto-eproc\application\views\administrator\penilaian_kinerja\buat_penilaian.php 361
ERROR - 2024-05-13 00:13:53 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\administrator\penilaian_kinerja\buat_penilaian.php 361
ERROR - 2024-05-13 00:13:53 --> Severity: Notice --> Undefined variable: get_pelaksanaan_manager C:\laragon\www\jmto-eproc\application\views\administrator\penilaian_kinerja\buat_penilaian.php 362
ERROR - 2024-05-13 00:13:53 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\administrator\penilaian_kinerja\buat_penilaian.php 362
ERROR - 2024-05-13 00:13:53 --> Severity: Notice --> Undefined variable: get_pelaksanaan_manager C:\laragon\www\jmto-eproc\application\views\administrator\penilaian_kinerja\buat_penilaian.php 363
ERROR - 2024-05-13 00:13:53 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\administrator\penilaian_kinerja\buat_penilaian.php 363
ERROR - 2024-05-13 00:13:53 --> Severity: Notice --> Undefined variable: get_pelaksanaan_manager C:\laragon\www\jmto-eproc\application\views\administrator\penilaian_kinerja\buat_penilaian.php 369
ERROR - 2024-05-13 00:13:53 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\administrator\penilaian_kinerja\buat_penilaian.php 369
ERROR - 2024-05-13 00:13:53 --> Severity: Notice --> Undefined variable: get_pelaksanaan_manager C:\laragon\www\jmto-eproc\application\views\administrator\penilaian_kinerja\buat_penilaian.php 370
ERROR - 2024-05-13 00:13:53 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\administrator\penilaian_kinerja\buat_penilaian.php 370
ERROR - 2024-05-13 00:13:53 --> Severity: Notice --> Undefined variable: get_pelaksanaan_manager C:\laragon\www\jmto-eproc\application\views\administrator\penilaian_kinerja\buat_penilaian.php 372
ERROR - 2024-05-13 00:13:53 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\administrator\penilaian_kinerja\buat_penilaian.php 372
ERROR - 2024-05-13 00:13:53 --> Severity: Notice --> Undefined variable: get_pelaksanaan_manager C:\laragon\www\jmto-eproc\application\views\administrator\penilaian_kinerja\buat_penilaian.php 379
ERROR - 2024-05-13 00:13:53 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\administrator\penilaian_kinerja\buat_penilaian.php 379
ERROR - 2024-05-13 00:13:53 --> Severity: Notice --> Undefined variable: get_pelaksanaan_manager C:\laragon\www\jmto-eproc\application\views\administrator\penilaian_kinerja\buat_penilaian.php 386
ERROR - 2024-05-13 00:13:53 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\administrator\penilaian_kinerja\buat_penilaian.php 386
ERROR - 2024-05-13 09:39:06 --> 404 Page Not Found: Auth/lupa_password
ERROR - 2024-05-13 13:04:17 --> Severity: Warning --> mysqli::real_connect(): php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\laragon\www\jmto-eproc\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2024-05-13 13:04:17 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\laragon\www\jmto-eproc\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2024-05-13 13:04:17 --> Unable to connect to the database
ERROR - 2024-05-13 23:57:17 --> Severity: error --> Exception: Call to undefined method M_laporan_kinerja::insert_total_pelaksanaan() C:\laragon\www\jmto-eproc\application\controllers\administrator\Penilaian_kinerja.php 413
ERROR - 2024-05-13 18:34:52 --> Severity: error --> Exception: syntax error, unexpected ',' C:\laragon\www\jmto-eproc\application\controllers\administrator\Penilaian_kinerja.php 828
