<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2024-05-12 07:30:56 --> 404 Page Not Found: administrator/Laporan_pengadaan_vendor/index
ERROR - 2024-05-12 07:31:05 --> 404 Page Not Found: administrator/Laporan_pengadaan_vendor/index
ERROR - 2024-05-12 07:31:06 --> 404 Page Not Found: administrator/Laporan_pengadaan_vendor/index
ERROR - 2024-05-12 14:31:17 --> Severity: Notice --> Undefined variable: get_departemen C:\laragon\www\jmto-eproc\application\views\administrator\laporan\laporan_efisiensi.php 338
ERROR - 2024-05-12 14:31:17 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\jmto-eproc\application\views\administrator\laporan\laporan_efisiensi.php 338
ERROR - 2024-05-12 14:31:21 --> Severity: Notice --> Undefined variable: get_departemen C:\laragon\www\jmto-eproc\application\views\administrator\laporan\laporan_efisiensi.php 338
ERROR - 2024-05-12 14:31:21 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\jmto-eproc\application\views\administrator\laporan\laporan_efisiensi.php 338
ERROR - 2024-05-12 14:31:48 --> Severity: Notice --> Undefined variable: get_departemen C:\laragon\www\jmto-eproc\application\views\administrator\laporan\laporan_efisiensi.php 338
ERROR - 2024-05-12 14:31:48 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\jmto-eproc\application\views\administrator\laporan\laporan_efisiensi.php 338
ERROR - 2024-05-12 14:40:25 --> Severity: error --> Exception: Call to undefined method M_laporan_vendor::gettable() C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_pengadaan_vendor.php 28
ERROR - 2024-05-12 14:40:32 --> Severity: error --> Exception: Call to undefined method M_laporan_vendor::gettable() C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_pengadaan_vendor.php 28
ERROR - 2024-05-12 14:43:25 --> Severity: Notice --> Undefined index: nama_usaha C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_pengadaan_vendor.php 52
ERROR - 2024-05-12 14:43:25 --> Severity: Notice --> Undefined index: nama_usaha C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_pengadaan_vendor.php 52
ERROR - 2024-05-12 14:43:25 --> Severity: Notice --> Undefined index: nama_usaha C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_pengadaan_vendor.php 52
ERROR - 2024-05-12 14:43:25 --> Severity: Notice --> Undefined index: nama_usaha C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_pengadaan_vendor.php 52
ERROR - 2024-05-12 14:44:45 --> Severity: error --> Exception: [] operator not supported for strings C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_pengadaan_vendor.php 58
ERROR - 2024-05-12 14:45:37 --> Severity: error --> Exception: [] operator not supported for strings C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_pengadaan_vendor.php 58
ERROR - 2024-05-12 14:45:43 --> Severity: error --> Exception: [] operator not supported for strings C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_pengadaan_vendor.php 58
ERROR - 2024-05-12 14:50:38 --> Query error: Unknown column 'tbl_rup.sts_pengumuman_terakhir' in 'where clause' - Invalid query: SELECT *
FROM `tbl_rup`
LEFT JOIN `tbl_vendor_mengikuti_paket` ON `tbl_rup`.`id_rup` = `tbl_vendor_mengikuti_paket`.`id_rup`
LEFT JOIN `tbl_vendor` ON `tbl_vendor`.`id_vendor` = `tbl_vendor_mengikuti_paket`.`id_vendor`
WHERE `tbl_rup`.`id_rup` = '215'
AND `tbl_vendor_mengikuti_paket`.`id_vendor` = '130'
AND `sts_deal_negosiasi` = 'deal'
AND `tbl_rup`.`sts_pengumuman_terakhir` = 1
ERROR - 2024-05-12 14:50:44 --> Query error: Unknown column 'tbl_rup.sts_pengumuman_terakhir' in 'where clause' - Invalid query: SELECT *
FROM `tbl_rup`
LEFT JOIN `tbl_vendor_mengikuti_paket` ON `tbl_rup`.`id_rup` = `tbl_vendor_mengikuti_paket`.`id_rup`
LEFT JOIN `tbl_vendor` ON `tbl_vendor`.`id_vendor` = `tbl_vendor_mengikuti_paket`.`id_vendor`
WHERE `tbl_rup`.`id_rup` = '215'
AND `tbl_vendor_mengikuti_paket`.`id_vendor` = '130'
AND `sts_deal_negosiasi` = 'deal'
AND `tbl_rup`.`sts_pengumuman_terakhir` = 1
ERROR - 2024-05-12 15:04:10 --> Severity: Warning --> Division by zero C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 173
ERROR - 2024-05-12 15:04:10 --> Severity: Warning --> Division by zero C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 188
ERROR - 2024-05-12 15:04:10 --> Severity: Warning --> Division by zero C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 191
ERROR - 2024-05-12 15:04:10 --> Severity: Warning --> Division by zero C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 193
ERROR - 2024-05-12 15:04:42 --> Severity: Warning --> Division by zero C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 173
ERROR - 2024-05-12 15:04:42 --> Severity: Warning --> Division by zero C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 188
ERROR - 2024-05-12 15:04:42 --> Severity: Warning --> Division by zero C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 191
ERROR - 2024-05-12 15:04:42 --> Severity: Warning --> Division by zero C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 193
ERROR - 2024-05-12 15:19:19 --> Severity: Notice --> Undefined variable: get_departemen C:\laragon\www\jmto-eproc\application\views\administrator\laporan\laporan_tkdn.php 338
ERROR - 2024-05-12 15:19:19 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\jmto-eproc\application\views\administrator\laporan\laporan_tkdn.php 338
ERROR - 2024-05-12 15:19:23 --> Severity: Notice --> Undefined variable: get_departemen C:\laragon\www\jmto-eproc\application\views\administrator\laporan\laporan_tkdn.php 338
ERROR - 2024-05-12 15:19:23 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\jmto-eproc\application\views\administrator\laporan\laporan_tkdn.php 338
ERROR - 2024-05-12 15:19:28 --> Severity: Notice --> Undefined variable: get_departemen C:\laragon\www\jmto-eproc\application\views\administrator\laporan\laporan_tkdn.php 338
ERROR - 2024-05-12 15:19:28 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\jmto-eproc\application\views\administrator\laporan\laporan_tkdn.php 338
ERROR - 2024-05-12 15:21:13 --> Severity: Notice --> Undefined variable: get_departemen C:\laragon\www\jmto-eproc\application\views\administrator\laporan\laporan_tkdn.php 338
ERROR - 2024-05-12 15:21:13 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\jmto-eproc\application\views\administrator\laporan\laporan_tkdn.php 338
ERROR - 2024-05-12 15:45:54 --> Severity: Notice --> Undefined property: Laporan_tkdn::$M_laporan_vendor C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_tkdn.php 27
ERROR - 2024-05-12 15:45:54 --> Severity: error --> Exception: Call to a member function gettable() on null C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_tkdn.php 27
ERROR - 2024-05-12 15:46:01 --> Severity: Notice --> Undefined property: Laporan_tkdn::$M_laporan_vendor C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_tkdn.php 27
ERROR - 2024-05-12 15:46:01 --> Severity: error --> Exception: Call to a member function gettable() on null C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_tkdn.php 27
ERROR - 2024-05-12 15:46:40 --> Severity: error --> Exception: Call to undefined method M_laporan_tkdn::get_pemenang() C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_tkdn.php 34
ERROR - 2024-05-12 16:47:05 --> Severity: Notice --> Trying to access array offset on value of type int C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_tkdn.php 73
ERROR - 2024-05-12 16:47:05 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_tkdn.php 73
ERROR - 2024-05-12 16:47:05 --> Severity: Notice --> Trying to access array offset on value of type int C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_tkdn.php 73
ERROR - 2024-05-12 16:47:05 --> Severity: Notice --> Trying to access array offset on value of type int C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_tkdn.php 73
ERROR - 2024-05-12 16:47:05 --> Severity: Notice --> Trying to access array offset on value of type int C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_tkdn.php 73
ERROR - 2024-05-12 16:47:05 --> Severity: Notice --> Trying to access array offset on value of type int C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_tkdn.php 73
ERROR - 2024-05-12 16:47:05 --> Severity: Notice --> Trying to access array offset on value of type int C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_tkdn.php 73
ERROR - 2024-05-12 16:50:43 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): A connection attempt failed because the connected party did not properly respond after a period of time, or established connection failed because connected host has failed to respond.
 C:\laragon\www\jmto-eproc\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2024-05-12 16:50:43 --> Unable to connect to the database
ERROR - 2024-05-12 16:50:53 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): A connection attempt failed because the connected party did not properly respond after a period of time, or established connection failed because connected host has failed to respond.
 C:\laragon\www\jmto-eproc\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2024-05-12 16:50:53 --> Unable to connect to the database
ERROR - 2024-05-12 16:50:58 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): A connection attempt failed because the connected party did not properly respond after a period of time, or established connection failed because connected host has failed to respond.
 C:\laragon\www\jmto-eproc\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2024-05-12 16:50:58 --> Unable to connect to the database
ERROR - 2024-05-12 16:51:07 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): A connection attempt failed because the connected party did not properly respond after a period of time, or established connection failed because connected host has failed to respond.
 C:\laragon\www\jmto-eproc\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2024-05-12 16:51:07 --> Unable to connect to the database
ERROR - 2024-05-12 16:51:20 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): A connection attempt failed because the connected party did not properly respond after a period of time, or established connection failed because connected host has failed to respond.
 C:\laragon\www\jmto-eproc\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2024-05-12 16:51:20 --> Unable to connect to the database
ERROR - 2024-05-12 16:51:38 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): A connection attempt failed because the connected party did not properly respond after a period of time, or established connection failed because connected host has failed to respond.
 C:\laragon\www\jmto-eproc\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2024-05-12 16:51:38 --> Unable to connect to the database
ERROR - 2024-05-12 16:51:51 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): A connection attempt failed because the connected party did not properly respond after a period of time, or established connection failed because connected host has failed to respond.
 C:\laragon\www\jmto-eproc\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2024-05-12 16:51:51 --> Unable to connect to the database
ERROR - 2024-05-12 16:53:13 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): A connection attempt failed because the connected party did not properly respond after a period of time, or established connection failed because connected host has failed to respond.
 C:\laragon\www\jmto-eproc\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2024-05-12 16:53:13 --> Unable to connect to the database
ERROR - 2024-05-12 16:54:20 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): A connection attempt failed because the connected party did not properly respond after a period of time, or established connection failed because connected host has failed to respond.
 C:\laragon\www\jmto-eproc\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2024-05-12 16:54:20 --> Unable to connect to the database
ERROR - 2024-05-12 16:54:38 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): A connection attempt failed because the connected party did not properly respond after a period of time, or established connection failed because connected host has failed to respond.
 C:\laragon\www\jmto-eproc\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2024-05-12 16:54:38 --> Unable to connect to the database
ERROR - 2024-05-12 16:55:30 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): A connection attempt failed because the connected party did not properly respond after a period of time, or established connection failed because connected host has failed to respond.
 C:\laragon\www\jmto-eproc\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2024-05-12 16:55:30 --> Unable to connect to the database
ERROR - 2024-05-12 16:55:34 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): A connection attempt failed because the connected party did not properly respond after a period of time, or established connection failed because connected host has failed to respond.
 C:\laragon\www\jmto-eproc\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2024-05-12 16:55:34 --> Unable to connect to the database
ERROR - 2024-05-12 16:55:44 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): A connection attempt failed because the connected party did not properly respond after a period of time, or established connection failed because connected host has failed to respond.
 C:\laragon\www\jmto-eproc\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2024-05-12 16:55:44 --> Unable to connect to the database
ERROR - 2024-05-12 17:50:38 --> Severity: Notice --> Trying to access array offset on value of type int C:\laragon\www\jmto-eproc\system\database\DB_driver.php 1412
ERROR - 2024-05-12 17:50:38 --> Severity: Notice --> Trying to access array offset on value of type int C:\laragon\www\jmto-eproc\system\database\DB_driver.php 1412
ERROR - 2024-05-12 17:50:38 --> Query error: SELECT command denied to user 'u1064384_eprocjmto'@'119.235.210.50' for table `tbl_rup`.`sts_pengumuman_rup_terakhir` - Invalid query: SELECT *
FROM `tbl_rup`
LEFT JOIN `tbl_departemen` ON `tbl_rup`.`id_departemen` = `tbl_departemen`.`id_departemen`
LEFT JOIN `tbl_section` ON `tbl_rup`.`id_section` = `tbl_section`.`id_section`
LEFT JOIN `tbl_rkap` ON `tbl_rup`.`id_rkap` = `tbl_rkap`.`id_rkap`
LEFT JOIN `tbl_provinsi` ON `tbl_rup`.`id_provinsi` = `tbl_provinsi`.`id_provinsi`
LEFT JOIN `tbl_kabupaten` ON `tbl_rup`.`id_kabupaten` = `tbl_kabupaten`.`id_kabupaten`
LEFT JOIN `tbl_jenis_pengadaan` ON `tbl_rup`.`id_jenis_pengadaan` = `tbl_jenis_pengadaan`.`id_jenis_pengadaan`
LEFT JOIN `tbl_metode_pengadaan` ON `tbl_rup`.`id_metode_pengadaan` = `tbl_metode_pengadaan`.`id_metode_pengadaan`
LEFT JOIN `tbl_jenis_anggaran` ON `tbl_rup`.`id_jenis_anggaran` = `tbl_jenis_anggaran`.`id_jenis_anggaran`
LEFT JOIN `mst_ruas` ON `tbl_rup`.`id_ruas` = `mst_ruas`.`id_ruas`
JOIN `tbl_rup`.`sts_pengumuman_rup_terakhir` USING (`1`)
ORDER BY `tbl_rup`.`id_rup` ASC
 LIMIT 10
ERROR - 2024-05-12 17:50:54 --> Severity: Notice --> Trying to access array offset on value of type int C:\laragon\www\jmto-eproc\system\database\DB_driver.php 1412
ERROR - 2024-05-12 17:50:54 --> Severity: Notice --> Trying to access array offset on value of type int C:\laragon\www\jmto-eproc\system\database\DB_driver.php 1412
ERROR - 2024-05-12 17:50:54 --> Query error: SELECT command denied to user 'u1064384_eprocjmto'@'119.235.210.50' for table `tbl_rup`.`sts_pengumuman_rup_trakhir` - Invalid query: SELECT *
FROM `tbl_rup`
LEFT JOIN `tbl_departemen` ON `tbl_rup`.`id_departemen` = `tbl_departemen`.`id_departemen`
LEFT JOIN `tbl_section` ON `tbl_rup`.`id_section` = `tbl_section`.`id_section`
LEFT JOIN `tbl_rkap` ON `tbl_rup`.`id_rkap` = `tbl_rkap`.`id_rkap`
LEFT JOIN `tbl_provinsi` ON `tbl_rup`.`id_provinsi` = `tbl_provinsi`.`id_provinsi`
LEFT JOIN `tbl_kabupaten` ON `tbl_rup`.`id_kabupaten` = `tbl_kabupaten`.`id_kabupaten`
LEFT JOIN `tbl_jenis_pengadaan` ON `tbl_rup`.`id_jenis_pengadaan` = `tbl_jenis_pengadaan`.`id_jenis_pengadaan`
LEFT JOIN `tbl_metode_pengadaan` ON `tbl_rup`.`id_metode_pengadaan` = `tbl_metode_pengadaan`.`id_metode_pengadaan`
LEFT JOIN `tbl_jenis_anggaran` ON `tbl_rup`.`id_jenis_anggaran` = `tbl_jenis_anggaran`.`id_jenis_anggaran`
LEFT JOIN `mst_ruas` ON `tbl_rup`.`id_ruas` = `mst_ruas`.`id_ruas`
JOIN `tbl_rup`.`sts_pengumuman_rup_trakhir` USING (`1`)
ORDER BY `tbl_rup`.`id_rup` ASC
 LIMIT 10
ERROR - 2024-05-12 18:47:12 --> Severity: error --> Exception: syntax error, unexpected '}', expecting end of file C:\laragon\www\jmto-eproc\application\views\administrator\penilaian_kinerja\buat_penilaian.php 142
ERROR - 2024-05-12 20:21:12 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\administrator\penilaian_kinerja\buat_penilaian.php 64
ERROR - 2024-05-12 20:22:28 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\administrator\penilaian_kinerja\buat_penilaian.php 64
ERROR - 2024-05-12 20:22:28 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\administrator\penilaian_kinerja\buat_penilaian.php 68
ERROR - 2024-05-12 20:22:35 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\administrator\penilaian_kinerja\buat_penilaian.php 64
ERROR - 2024-05-12 20:22:35 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\administrator\penilaian_kinerja\buat_penilaian.php 68
ERROR - 2024-05-12 20:23:51 --> Severity: Notice --> Undefined property: Penilaian_kinerja::$M_laporan_kinerja C:\laragon\www\jmto-eproc\application\controllers\administrator\Penilaian_kinerja.php 54
ERROR - 2024-05-12 20:23:51 --> Severity: error --> Exception: Call to a member function get_row_rup() on null C:\laragon\www\jmto-eproc\application\controllers\administrator\Penilaian_kinerja.php 54
ERROR - 2024-05-12 20:24:06 --> Severity: error --> Exception: Unable to locate the model you have specified: M_laporan_kinerja C:\laragon\www\jmto-eproc\system\core\Loader.php 349
ERROR - 2024-05-12 20:24:14 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\administrator\penilaian_kinerja\buat_penilaian.php 64
ERROR - 2024-05-12 20:24:14 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\administrator\penilaian_kinerja\buat_penilaian.php 68
ERROR - 2024-05-12 20:26:23 --> Severity: Notice --> Undefined index: nama_unit_kerja C:\laragon\www\jmto-eproc\application\views\administrator\penilaian_kinerja\buat_penilaian.php 72
ERROR - 2024-05-12 23:54:39 --> Severity: error --> Exception: Call to undefined method M_laporan_kinerja::update_data() C:\laragon\www\jmto-eproc\application\controllers\administrator\Penilaian_kinerja.php 133
