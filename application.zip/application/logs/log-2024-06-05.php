<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2024-06-05 14:38:09 --> Severity: Notice --> Undefined property: stdClass::$role_panitia C:\laragon\www\jmto-eproc\application\controllers\administrator\Sirup_buat_paket.php 262
ERROR - 2024-06-05 14:38:09 --> Severity: Notice --> Undefined property: stdClass::$role_panitia C:\laragon\www\jmto-eproc\application\controllers\administrator\Sirup_buat_paket.php 264
ERROR - 2024-06-05 14:38:09 --> Severity: Notice --> Undefined property: stdClass::$id_url_panitia C:\laragon\www\jmto-eproc\application\controllers\administrator\Sirup_buat_paket.php 270
ERROR - 2024-06-05 14:38:27 --> Severity: Notice --> Undefined property: stdClass::$id_url_panitia C:\laragon\www\jmto-eproc\application\controllers\administrator\Sirup_buat_paket.php 270
ERROR - 2024-06-05 14:38:36 --> Severity: Notice --> Undefined property: stdClass::$id_url_panitia C:\laragon\www\jmto-eproc\application\controllers\administrator\Sirup_buat_paket.php 270
ERROR - 2024-06-05 14:51:48 --> Query error: Unknown column 'nama_program_rup' in 'where clause' - Invalid query: SELECT *
FROM `tbl_rup`
LEFT JOIN `tbl_departemen` ON `tbl_rup`.`id_departemen` = `tbl_departemen`.`id_departemen`
LEFT JOIN `tbl_section` ON `tbl_rup`.`id_section` = `tbl_section`.`id_section`
LEFT JOIN `tbl_rkap` ON `tbl_rup`.`id_rkap` = `tbl_rkap`.`id_rkap`
LEFT JOIN `tbl_provinsi` ON `tbl_rup`.`id_provinsi` = `tbl_provinsi`.`id_provinsi`
LEFT JOIN `tbl_kabupaten` ON `tbl_rup`.`id_kabupaten` = `tbl_kabupaten`.`id_kabupaten`
LEFT JOIN `tbl_jenis_pengadaan` ON `tbl_rup`.`id_jenis_pengadaan` = `tbl_jenis_pengadaan`.`id_jenis_pengadaan`
LEFT JOIN `tbl_metode_pengadaan` ON `tbl_rup`.`id_metode_pengadaan` = `tbl_metode_pengadaan`.`id_metode_pengadaan`
LEFT JOIN `tbl_jenis_anggaran` ON `tbl_rup`.`id_jenis_anggaran` = `tbl_jenis_anggaran`.`id_jenis_anggaran`
LEFT JOIN `mst_ruas` ON `tbl_rup`.`id_ruas` = `mst_ruas`.`id_ruas`
WHERE   (
`kode_urut_rup` LIKE '%a%' ESCAPE '!'
OR  `kode_rup` LIKE '%a%' ESCAPE '!'
OR  `tahun_rup` LIKE '%a%' ESCAPE '!'
OR  `nama_program_rup` LIKE '%a%' ESCAPE '!'
OR  `kode_departemen` LIKE '%a%' ESCAPE '!'
OR  `total_pagu_rup` LIKE '%a%' ESCAPE '!'
OR  `id_rup` LIKE '%a%' ESCAPE '!'
OR  `id_rup` LIKE '%a%' ESCAPE '!'
OR  `id_rup` LIKE '%a%' ESCAPE '!'
 )
ORDER BY `tbl_rup`.`kode_urut_rup` DESC
 LIMIT 10
ERROR - 2024-06-05 14:51:49 --> Query error: Unknown column 'nama_program_rup' in 'where clause' - Invalid query: SELECT *
FROM `tbl_rup`
LEFT JOIN `tbl_departemen` ON `tbl_rup`.`id_departemen` = `tbl_departemen`.`id_departemen`
LEFT JOIN `tbl_section` ON `tbl_rup`.`id_section` = `tbl_section`.`id_section`
LEFT JOIN `tbl_rkap` ON `tbl_rup`.`id_rkap` = `tbl_rkap`.`id_rkap`
LEFT JOIN `tbl_provinsi` ON `tbl_rup`.`id_provinsi` = `tbl_provinsi`.`id_provinsi`
LEFT JOIN `tbl_kabupaten` ON `tbl_rup`.`id_kabupaten` = `tbl_kabupaten`.`id_kabupaten`
LEFT JOIN `tbl_jenis_pengadaan` ON `tbl_rup`.`id_jenis_pengadaan` = `tbl_jenis_pengadaan`.`id_jenis_pengadaan`
LEFT JOIN `tbl_metode_pengadaan` ON `tbl_rup`.`id_metode_pengadaan` = `tbl_metode_pengadaan`.`id_metode_pengadaan`
LEFT JOIN `tbl_jenis_anggaran` ON `tbl_rup`.`id_jenis_anggaran` = `tbl_jenis_anggaran`.`id_jenis_anggaran`
LEFT JOIN `mst_ruas` ON `tbl_rup`.`id_ruas` = `mst_ruas`.`id_ruas`
WHERE   (
`kode_urut_rup` LIKE '%asd%' ESCAPE '!'
OR  `kode_rup` LIKE '%asd%' ESCAPE '!'
OR  `tahun_rup` LIKE '%asd%' ESCAPE '!'
OR  `nama_program_rup` LIKE '%asd%' ESCAPE '!'
OR  `kode_departemen` LIKE '%asd%' ESCAPE '!'
OR  `total_pagu_rup` LIKE '%asd%' ESCAPE '!'
OR  `id_rup` LIKE '%asd%' ESCAPE '!'
OR  `id_rup` LIKE '%asd%' ESCAPE '!'
OR  `id_rup` LIKE '%asd%' ESCAPE '!'
 )
ORDER BY `tbl_rup`.`kode_urut_rup` DESC
 LIMIT 10
ERROR - 2024-06-05 14:52:50 --> Query error: Unknown column 'nama_program_rup' in 'where clause' - Invalid query: SELECT *
FROM `tbl_rup`
LEFT JOIN `tbl_departemen` ON `tbl_rup`.`id_departemen` = `tbl_departemen`.`id_departemen`
LEFT JOIN `tbl_section` ON `tbl_rup`.`id_section` = `tbl_section`.`id_section`
LEFT JOIN `tbl_rkap` ON `tbl_rup`.`id_rkap` = `tbl_rkap`.`id_rkap`
LEFT JOIN `tbl_provinsi` ON `tbl_rup`.`id_provinsi` = `tbl_provinsi`.`id_provinsi`
LEFT JOIN `tbl_kabupaten` ON `tbl_rup`.`id_kabupaten` = `tbl_kabupaten`.`id_kabupaten`
LEFT JOIN `tbl_jenis_pengadaan` ON `tbl_rup`.`id_jenis_pengadaan` = `tbl_jenis_pengadaan`.`id_jenis_pengadaan`
LEFT JOIN `tbl_metode_pengadaan` ON `tbl_rup`.`id_metode_pengadaan` = `tbl_metode_pengadaan`.`id_metode_pengadaan`
LEFT JOIN `tbl_jenis_anggaran` ON `tbl_rup`.`id_jenis_anggaran` = `tbl_jenis_anggaran`.`id_jenis_anggaran`
LEFT JOIN `mst_ruas` ON `tbl_rup`.`id_ruas` = `mst_ruas`.`id_ruas`
WHERE   (
`kode_urut_rup` LIKE '%a%' ESCAPE '!'
OR  `kode_rup` LIKE '%a%' ESCAPE '!'
OR  `tahun_rup` LIKE '%a%' ESCAPE '!'
OR  `nama_program_rup` LIKE '%a%' ESCAPE '!'
OR  `kode_departemen` LIKE '%a%' ESCAPE '!'
OR  `total_pagu_rup` LIKE '%a%' ESCAPE '!'
OR  `id_rup` LIKE '%a%' ESCAPE '!'
OR  `id_rup` LIKE '%a%' ESCAPE '!'
OR  `id_rup` LIKE '%a%' ESCAPE '!'
 )
ORDER BY `tbl_rup`.`kode_urut_rup` DESC
 LIMIT 10
ERROR - 2024-06-05 14:52:51 --> Query error: Unknown column 'nama_program_rup' in 'where clause' - Invalid query: SELECT *
FROM `tbl_rup`
LEFT JOIN `tbl_departemen` ON `tbl_rup`.`id_departemen` = `tbl_departemen`.`id_departemen`
LEFT JOIN `tbl_section` ON `tbl_rup`.`id_section` = `tbl_section`.`id_section`
LEFT JOIN `tbl_rkap` ON `tbl_rup`.`id_rkap` = `tbl_rkap`.`id_rkap`
LEFT JOIN `tbl_provinsi` ON `tbl_rup`.`id_provinsi` = `tbl_provinsi`.`id_provinsi`
LEFT JOIN `tbl_kabupaten` ON `tbl_rup`.`id_kabupaten` = `tbl_kabupaten`.`id_kabupaten`
LEFT JOIN `tbl_jenis_pengadaan` ON `tbl_rup`.`id_jenis_pengadaan` = `tbl_jenis_pengadaan`.`id_jenis_pengadaan`
LEFT JOIN `tbl_metode_pengadaan` ON `tbl_rup`.`id_metode_pengadaan` = `tbl_metode_pengadaan`.`id_metode_pengadaan`
LEFT JOIN `tbl_jenis_anggaran` ON `tbl_rup`.`id_jenis_anggaran` = `tbl_jenis_anggaran`.`id_jenis_anggaran`
LEFT JOIN `mst_ruas` ON `tbl_rup`.`id_ruas` = `mst_ruas`.`id_ruas`
WHERE   (
`kode_urut_rup` LIKE '%asd%' ESCAPE '!'
OR  `kode_rup` LIKE '%asd%' ESCAPE '!'
OR  `tahun_rup` LIKE '%asd%' ESCAPE '!'
OR  `nama_program_rup` LIKE '%asd%' ESCAPE '!'
OR  `kode_departemen` LIKE '%asd%' ESCAPE '!'
OR  `total_pagu_rup` LIKE '%asd%' ESCAPE '!'
OR  `id_rup` LIKE '%asd%' ESCAPE '!'
OR  `id_rup` LIKE '%asd%' ESCAPE '!'
OR  `id_rup` LIKE '%asd%' ESCAPE '!'
 )
ORDER BY `tbl_rup`.`kode_urut_rup` DESC
 LIMIT 10
ERROR - 2024-06-05 14:56:55 --> Severity: error --> Exception: Too few arguments to function Daftar_paket::by_id_rup(), 0 passed in C:\laragon\www\jmto-eproc\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 388
ERROR - 2024-06-05 14:58:15 --> Severity: error --> Exception: Too few arguments to function Daftar_paket::by_id_rup(), 0 passed in C:\laragon\www\jmto-eproc\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 388
ERROR - 2024-06-05 14:59:30 --> Severity: error --> Exception: Too few arguments to function Daftar_paket::by_id_rup(), 0 passed in C:\laragon\www\jmto-eproc\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 388
ERROR - 2024-06-05 15:01:36 --> Severity: error --> Exception: Too few arguments to function Daftar_paket::by_id_rup(), 0 passed in C:\laragon\www\jmto-eproc\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 388
ERROR - 2024-06-05 15:17:15 --> Severity: error --> Exception: Too few arguments to function Daftar_paket::by_id_rup(), 0 passed in C:\laragon\www\jmto-eproc\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 388
ERROR - 2024-06-05 15:28:23 --> Query error: Unknown column 'tbl_panitia.id_manajemen_user' in 'where clause' - Invalid query: SELECT *
FROM `tbl_rup`
LEFT JOIN `tbl_tim_teknis` ON `tbl_rup`.`id_rup` = `tbl_tim_teknis`.`id_rup`
WHERE `tbl_panitia`.`id_manajemen_user` = '37'
AND `tbl_tim_teknis`.`id_manajemen_user` = '37'
AND `tbl_rup`.`id_metode_pengadaan` = 1
AND `tbl_rup`.`status_paket_diumumkan` = 1
GROUP BY `tbl_rup`.`id_rup`
ERROR - 2024-06-05 15:29:13 --> Severity: error --> Exception: Too few arguments to function Daftar_paket::by_id_rup(), 0 passed in C:\laragon\www\jmto-eproc\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 388
ERROR - 2024-06-05 15:33:38 --> Severity: error --> Exception: Too few arguments to function Daftar_paket::by_id_rup(), 0 passed in C:\laragon\www\jmto-eproc\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 388
ERROR - 2024-06-05 15:34:58 --> Severity: error --> Exception: Too few arguments to function Daftar_paket::by_id_rup(), 0 passed in C:\laragon\www\jmto-eproc\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 388
ERROR - 2024-06-05 15:35:08 --> Severity: error --> Exception: Too few arguments to function Daftar_paket::by_id_rup(), 0 passed in C:\laragon\www\jmto-eproc\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 388
ERROR - 2024-06-05 15:35:31 --> Severity: Notice --> Trying to get property 'nip' of non-object C:\laragon\www\jmto-eproc\application\libraries\Role_login.php 21
ERROR - 2024-06-05 16:02:26 --> Severity: error --> Exception: Unable to locate the model you have specified: M_laporan_realisasi C:\laragon\www\jmto-eproc\system\core\Loader.php 349
ERROR - 2024-06-05 16:03:02 --> Severity: error --> Exception: Unable to locate the model you have specified: M_laporan_realisasi C:\laragon\www\jmto-eproc\system\core\Loader.php 349
ERROR - 2024-06-05 16:08:56 --> Severity: error --> Exception: Too few arguments to function Laporan_realisasi_rup::get_data_rekapitulasi_rup(), 0 passed in C:\laragon\www\jmto-eproc\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_realisasi_rup.php 34
ERROR - 2024-06-05 16:08:56 --> Severity: error --> Exception: Too few arguments to function Laporan_realisasi_rup::get_data_rekapitulasi_rup(), 0 passed in C:\laragon\www\jmto-eproc\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_realisasi_rup.php 34
ERROR - 2024-06-05 16:08:56 --> Severity: error --> Exception: Too few arguments to function Laporan_realisasi_rup::get_data_rekapitulasi_rup(), 0 passed in C:\laragon\www\jmto-eproc\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_realisasi_rup.php 34
ERROR - 2024-06-05 16:08:56 --> Severity: error --> Exception: Too few arguments to function Laporan_realisasi_rup::get_data_rekapitulasi_rup(), 0 passed in C:\laragon\www\jmto-eproc\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_realisasi_rup.php 34
ERROR - 2024-06-05 16:08:56 --> Severity: error --> Exception: Too few arguments to function Laporan_realisasi_rup::get_data_rekapitulasi_rup(), 0 passed in C:\laragon\www\jmto-eproc\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_realisasi_rup.php 34
ERROR - 2024-06-05 16:08:56 --> Severity: error --> Exception: Too few arguments to function Laporan_realisasi_rup::get_data_rekapitulasi_rup(), 0 passed in C:\laragon\www\jmto-eproc\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_realisasi_rup.php 34
ERROR - 2024-06-05 16:08:56 --> Severity: error --> Exception: Too few arguments to function Laporan_realisasi_rup::get_data_rekapitulasi_rup(), 0 passed in C:\laragon\www\jmto-eproc\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_realisasi_rup.php 34
ERROR - 2024-06-05 16:08:56 --> Severity: error --> Exception: Too few arguments to function Laporan_realisasi_rup::get_data_rekapitulasi_rup(), 0 passed in C:\laragon\www\jmto-eproc\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_realisasi_rup.php 34
ERROR - 2024-06-05 16:08:56 --> Severity: error --> Exception: Too few arguments to function Laporan_realisasi_rup::get_data_rekapitulasi_rup(), 0 passed in C:\laragon\www\jmto-eproc\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_realisasi_rup.php 34
ERROR - 2024-06-05 16:08:56 --> Severity: error --> Exception: Too few arguments to function Laporan_realisasi_rup::get_data_rekapitulasi_rup(), 0 passed in C:\laragon\www\jmto-eproc\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_realisasi_rup.php 34
ERROR - 2024-06-05 16:08:56 --> Severity: error --> Exception: Too few arguments to function Laporan_realisasi_rup::get_data_rekapitulasi_rup(), 0 passed in C:\laragon\www\jmto-eproc\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_realisasi_rup.php 34
ERROR - 2024-06-05 16:08:56 --> Severity: error --> Exception: Too few arguments to function Laporan_realisasi_rup::get_data_rekapitulasi_rup(), 0 passed in C:\laragon\www\jmto-eproc\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_realisasi_rup.php 34
ERROR - 2024-06-05 16:08:56 --> Severity: error --> Exception: Too few arguments to function Laporan_realisasi_rup::get_data_rekapitulasi_rup(), 0 passed in C:\laragon\www\jmto-eproc\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_realisasi_rup.php 34
ERROR - 2024-06-05 16:10:47 --> Query error: Unknown column 'sts_pengumuman_rup_trakhir' in 'where clause' - Invalid query: SELECT *
FROM `tbl_tim_teknis`
WHERE `sts_pengumuman_rup_trakhir` = 1
ERROR - 2024-06-05 16:10:47 --> Query error: Unknown column 'sts_pengumuman_rup_trakhir' in 'where clause' - Invalid query: SELECT *
FROM `tbl_tim_teknis`
WHERE `sts_pengumuman_rup_trakhir` = 1
ERROR - 2024-06-05 16:10:47 --> Query error: Unknown column 'sts_pengumuman_rup_trakhir' in 'where clause' - Invalid query: SELECT *
FROM `tbl_tim_teknis`
WHERE `sts_pengumuman_rup_trakhir` = 1
ERROR - 2024-06-05 16:10:47 --> Query error: Unknown column 'sts_pengumuman_rup_trakhir' in 'where clause' - Invalid query: SELECT *
FROM `tbl_tim_teknis`
WHERE `sts_pengumuman_rup_trakhir` = 1
ERROR - 2024-06-05 16:10:48 --> Query error: Unknown column 'sts_pengumuman_rup_trakhir' in 'where clause' - Invalid query: SELECT *
FROM `tbl_tim_teknis`
WHERE `sts_pengumuman_rup_trakhir` = 1
ERROR - 2024-06-05 16:10:48 --> Query error: Unknown column 'sts_pengumuman_rup_trakhir' in 'where clause' - Invalid query: SELECT *
FROM `tbl_tim_teknis`
WHERE `sts_pengumuman_rup_trakhir` = 1
ERROR - 2024-06-05 16:10:48 --> Query error: Unknown column 'sts_pengumuman_rup_trakhir' in 'where clause' - Invalid query: SELECT *
FROM `tbl_tim_teknis`
WHERE `sts_pengumuman_rup_trakhir` = 1
ERROR - 2024-06-05 16:10:48 --> Query error: Unknown column 'sts_pengumuman_rup_trakhir' in 'where clause' - Invalid query: SELECT *
FROM `tbl_tim_teknis`
WHERE `sts_pengumuman_rup_trakhir` = 1
ERROR - 2024-06-05 16:10:48 --> Query error: Unknown column 'sts_pengumuman_rup_trakhir' in 'where clause' - Invalid query: SELECT *
FROM `tbl_tim_teknis`
WHERE `sts_pengumuman_rup_trakhir` = 1
ERROR - 2024-06-05 16:10:48 --> Query error: Unknown column 'sts_pengumuman_rup_trakhir' in 'where clause' - Invalid query: SELECT *
FROM `tbl_tim_teknis`
WHERE `sts_pengumuman_rup_trakhir` = 1
ERROR - 2024-06-05 16:10:48 --> Query error: Unknown column 'sts_pengumuman_rup_trakhir' in 'where clause' - Invalid query: SELECT *
FROM `tbl_tim_teknis`
WHERE `sts_pengumuman_rup_trakhir` = 1
ERROR - 2024-06-05 16:10:48 --> Query error: Unknown column 'sts_pengumuman_rup_trakhir' in 'where clause' - Invalid query: SELECT *
FROM `tbl_tim_teknis`
WHERE `sts_pengumuman_rup_trakhir` = 1
ERROR - 2024-06-05 16:10:48 --> Query error: Unknown column 'sts_pengumuman_rup_trakhir' in 'where clause' - Invalid query: SELECT *
FROM `tbl_tim_teknis`
WHERE `sts_pengumuman_rup_trakhir` = 1
ERROR - 2024-06-05 16:10:59 --> Query error: Unknown column 'sts_pengumuman_rup_trakhir' in 'where clause' - Invalid query: SELECT *
FROM `tbl_tim_teknis`
WHERE `sts_pengumuman_rup_trakhir` = 1
ERROR - 2024-06-05 16:10:59 --> Query error: Unknown column 'sts_pengumuman_rup_trakhir' in 'where clause' - Invalid query: SELECT *
FROM `tbl_tim_teknis`
WHERE `sts_pengumuman_rup_trakhir` = 1
ERROR - 2024-06-05 16:10:59 --> Query error: Unknown column 'sts_pengumuman_rup_trakhir' in 'where clause' - Invalid query: SELECT *
FROM `tbl_tim_teknis`
WHERE `sts_pengumuman_rup_trakhir` = 1
ERROR - 2024-06-05 16:10:59 --> Query error: Unknown column 'sts_pengumuman_rup_trakhir' in 'where clause' - Invalid query: SELECT *
FROM `tbl_tim_teknis`
WHERE `sts_pengumuman_rup_trakhir` = 1
ERROR - 2024-06-05 16:10:59 --> Query error: Unknown column 'sts_pengumuman_rup_trakhir' in 'where clause' - Invalid query: SELECT *
FROM `tbl_tim_teknis`
WHERE `sts_pengumuman_rup_trakhir` = 1
ERROR - 2024-06-05 16:10:59 --> Query error: Unknown column 'sts_pengumuman_rup_trakhir' in 'where clause' - Invalid query: SELECT *
FROM `tbl_tim_teknis`
WHERE `sts_pengumuman_rup_trakhir` = 1
ERROR - 2024-06-05 16:10:59 --> Query error: Unknown column 'sts_pengumuman_rup_trakhir' in 'where clause' - Invalid query: SELECT *
FROM `tbl_tim_teknis`
WHERE `sts_pengumuman_rup_trakhir` = 1
ERROR - 2024-06-05 16:10:59 --> Query error: Unknown column 'sts_pengumuman_rup_trakhir' in 'where clause' - Invalid query: SELECT *
FROM `tbl_tim_teknis`
WHERE `sts_pengumuman_rup_trakhir` = 1
ERROR - 2024-06-05 16:10:59 --> Query error: Unknown column 'sts_pengumuman_rup_trakhir' in 'where clause' - Invalid query: SELECT *
FROM `tbl_tim_teknis`
WHERE `sts_pengumuman_rup_trakhir` = 1
ERROR - 2024-06-05 16:10:59 --> Query error: Unknown column 'sts_pengumuman_rup_trakhir' in 'where clause' - Invalid query: SELECT *
FROM `tbl_tim_teknis`
WHERE `sts_pengumuman_rup_trakhir` = 1
ERROR - 2024-06-05 16:10:59 --> Query error: Unknown column 'sts_pengumuman_rup_trakhir' in 'where clause' - Invalid query: SELECT *
FROM `tbl_tim_teknis`
WHERE `sts_pengumuman_rup_trakhir` = 1
ERROR - 2024-06-05 16:10:59 --> Query error: Unknown column 'sts_pengumuman_rup_trakhir' in 'where clause' - Invalid query: SELECT *
FROM `tbl_tim_teknis`
WHERE `sts_pengumuman_rup_trakhir` = 1
ERROR - 2024-06-05 16:10:59 --> Query error: Unknown column 'sts_pengumuman_rup_trakhir' in 'where clause' - Invalid query: SELECT *
FROM `tbl_tim_teknis`
WHERE `sts_pengumuman_rup_trakhir` = 1
ERROR - 2024-06-05 16:11:24 --> Query error: Unknown column 'sts_pengumuman_rup_trakhir' in 'where clause' - Invalid query: SELECT *
FROM `tbl_tim_teknis`
WHERE `sts_pengumuman_rup_trakhir` = 1
ERROR - 2024-06-05 16:11:24 --> Query error: Unknown column 'sts_pengumuman_rup_trakhir' in 'where clause' - Invalid query: SELECT *
FROM `tbl_tim_teknis`
WHERE `sts_pengumuman_rup_trakhir` = 1
ERROR - 2024-06-05 16:11:24 --> Query error: Unknown column 'sts_pengumuman_rup_trakhir' in 'where clause' - Invalid query: SELECT *
FROM `tbl_tim_teknis`
WHERE `sts_pengumuman_rup_trakhir` = 1
ERROR - 2024-06-05 16:11:24 --> Query error: Unknown column 'sts_pengumuman_rup_trakhir' in 'where clause' - Invalid query: SELECT *
FROM `tbl_tim_teknis`
WHERE `sts_pengumuman_rup_trakhir` = 1
ERROR - 2024-06-05 16:11:24 --> Query error: Unknown column 'sts_pengumuman_rup_trakhir' in 'where clause' - Invalid query: SELECT *
FROM `tbl_tim_teknis`
WHERE `sts_pengumuman_rup_trakhir` = 1
ERROR - 2024-06-05 16:11:24 --> Query error: Unknown column 'sts_pengumuman_rup_trakhir' in 'where clause' - Invalid query: SELECT *
FROM `tbl_tim_teknis`
WHERE `sts_pengumuman_rup_trakhir` = 1
ERROR - 2024-06-05 16:11:24 --> Query error: Unknown column 'sts_pengumuman_rup_trakhir' in 'where clause' - Invalid query: SELECT *
FROM `tbl_tim_teknis`
WHERE `sts_pengumuman_rup_trakhir` = 1
ERROR - 2024-06-05 16:11:24 --> Query error: Unknown column 'sts_pengumuman_rup_trakhir' in 'where clause' - Invalid query: SELECT *
FROM `tbl_tim_teknis`
WHERE `sts_pengumuman_rup_trakhir` = 1
ERROR - 2024-06-05 16:11:24 --> Query error: Unknown column 'sts_pengumuman_rup_trakhir' in 'where clause' - Invalid query: SELECT *
FROM `tbl_tim_teknis`
WHERE `sts_pengumuman_rup_trakhir` = 1
ERROR - 2024-06-05 16:11:24 --> Query error: Unknown column 'sts_pengumuman_rup_trakhir' in 'where clause' - Invalid query: SELECT *
FROM `tbl_tim_teknis`
WHERE `sts_pengumuman_rup_trakhir` = 1
ERROR - 2024-06-05 16:11:24 --> Query error: Unknown column 'sts_pengumuman_rup_trakhir' in 'where clause' - Invalid query: SELECT *
FROM `tbl_tim_teknis`
WHERE `sts_pengumuman_rup_trakhir` = 1
ERROR - 2024-06-05 16:11:24 --> Query error: Unknown column 'sts_pengumuman_rup_trakhir' in 'where clause' - Invalid query: SELECT *
FROM `tbl_tim_teknis`
WHERE `sts_pengumuman_rup_trakhir` = 1
ERROR - 2024-06-05 16:11:24 --> Query error: Unknown column 'sts_pengumuman_rup_trakhir' in 'where clause' - Invalid query: SELECT *
FROM `tbl_tim_teknis`
WHERE `sts_pengumuman_rup_trakhir` = 1
ERROR - 2024-06-05 16:11:30 --> Query error: Unknown column 'sts_pengumuman_rup_trakhir' in 'where clause' - Invalid query: SELECT *
FROM `tbl_tim_teknis`
WHERE `sts_pengumuman_rup_trakhir` = 1
ERROR - 2024-06-05 16:11:30 --> Query error: Unknown column 'sts_pengumuman_rup_trakhir' in 'where clause' - Invalid query: SELECT *
FROM `tbl_tim_teknis`
WHERE `sts_pengumuman_rup_trakhir` = 1
ERROR - 2024-06-05 16:11:30 --> Query error: Unknown column 'sts_pengumuman_rup_trakhir' in 'where clause' - Invalid query: SELECT *
FROM `tbl_tim_teknis`
WHERE `sts_pengumuman_rup_trakhir` = 1
ERROR - 2024-06-05 16:11:30 --> Query error: Unknown column 'sts_pengumuman_rup_trakhir' in 'where clause' - Invalid query: SELECT *
FROM `tbl_tim_teknis`
WHERE `sts_pengumuman_rup_trakhir` = 1
ERROR - 2024-06-05 16:11:30 --> Query error: Unknown column 'sts_pengumuman_rup_trakhir' in 'where clause' - Invalid query: SELECT *
FROM `tbl_tim_teknis`
WHERE `sts_pengumuman_rup_trakhir` = 1
ERROR - 2024-06-05 16:11:30 --> Query error: Unknown column 'sts_pengumuman_rup_trakhir' in 'where clause' - Invalid query: SELECT *
FROM `tbl_tim_teknis`
WHERE `sts_pengumuman_rup_trakhir` = 1
ERROR - 2024-06-05 16:11:30 --> Query error: Unknown column 'sts_pengumuman_rup_trakhir' in 'where clause' - Invalid query: SELECT *
FROM `tbl_tim_teknis`
WHERE `sts_pengumuman_rup_trakhir` = 1
ERROR - 2024-06-05 16:11:30 --> Query error: Unknown column 'sts_pengumuman_rup_trakhir' in 'where clause' - Invalid query: SELECT *
FROM `tbl_tim_teknis`
WHERE `sts_pengumuman_rup_trakhir` = 1
ERROR - 2024-06-05 16:11:30 --> Query error: Unknown column 'sts_pengumuman_rup_trakhir' in 'where clause' - Invalid query: SELECT *
FROM `tbl_tim_teknis`
WHERE `sts_pengumuman_rup_trakhir` = 1
ERROR - 2024-06-05 16:11:30 --> Query error: Unknown column 'sts_pengumuman_rup_trakhir' in 'where clause' - Invalid query: SELECT *
FROM `tbl_tim_teknis`
WHERE `sts_pengumuman_rup_trakhir` = 1
ERROR - 2024-06-05 16:11:31 --> Query error: Unknown column 'sts_pengumuman_rup_trakhir' in 'where clause' - Invalid query: SELECT *
FROM `tbl_tim_teknis`
WHERE `sts_pengumuman_rup_trakhir` = 1
ERROR - 2024-06-05 16:11:31 --> Query error: Unknown column 'sts_pengumuman_rup_trakhir' in 'where clause' - Invalid query: SELECT *
FROM `tbl_tim_teknis`
WHERE `sts_pengumuman_rup_trakhir` = 1
ERROR - 2024-06-05 16:11:31 --> Query error: Unknown column 'sts_pengumuman_rup_trakhir' in 'where clause' - Invalid query: SELECT *
FROM `tbl_tim_teknis`
WHERE `sts_pengumuman_rup_trakhir` = 1
ERROR - 2024-06-05 16:12:32 --> Severity: error --> Exception: Call to undefined method CI_DB_mysqli_result::count_all_result() C:\laragon\www\jmto-eproc\application\models\M_laporan\M_laporan_realisasi.php 15
ERROR - 2024-06-05 16:12:32 --> Severity: error --> Exception: Call to undefined method CI_DB_mysqli_result::count_all_result() C:\laragon\www\jmto-eproc\application\models\M_laporan\M_laporan_realisasi.php 15
ERROR - 2024-06-05 16:12:32 --> Severity: error --> Exception: Call to undefined method CI_DB_mysqli_result::count_all_result() C:\laragon\www\jmto-eproc\application\models\M_laporan\M_laporan_realisasi.php 15
ERROR - 2024-06-05 16:12:32 --> Severity: error --> Exception: Call to undefined method CI_DB_mysqli_result::count_all_result() C:\laragon\www\jmto-eproc\application\models\M_laporan\M_laporan_realisasi.php 15
ERROR - 2024-06-05 16:12:32 --> Severity: error --> Exception: Call to undefined method CI_DB_mysqli_result::count_all_result() C:\laragon\www\jmto-eproc\application\models\M_laporan\M_laporan_realisasi.php 15
ERROR - 2024-06-05 16:12:32 --> Severity: error --> Exception: Call to undefined method CI_DB_mysqli_result::count_all_result() C:\laragon\www\jmto-eproc\application\models\M_laporan\M_laporan_realisasi.php 15
ERROR - 2024-06-05 16:12:32 --> Severity: error --> Exception: Call to undefined method CI_DB_mysqli_result::count_all_result() C:\laragon\www\jmto-eproc\application\models\M_laporan\M_laporan_realisasi.php 15
ERROR - 2024-06-05 16:12:32 --> Severity: error --> Exception: Call to undefined method CI_DB_mysqli_result::count_all_result() C:\laragon\www\jmto-eproc\application\models\M_laporan\M_laporan_realisasi.php 15
ERROR - 2024-06-05 16:12:32 --> Severity: error --> Exception: Call to undefined method CI_DB_mysqli_result::count_all_result() C:\laragon\www\jmto-eproc\application\models\M_laporan\M_laporan_realisasi.php 15
ERROR - 2024-06-05 16:12:32 --> Severity: error --> Exception: Call to undefined method CI_DB_mysqli_result::count_all_result() C:\laragon\www\jmto-eproc\application\models\M_laporan\M_laporan_realisasi.php 15
ERROR - 2024-06-05 16:12:32 --> Severity: error --> Exception: Call to undefined method CI_DB_mysqli_result::count_all_result() C:\laragon\www\jmto-eproc\application\models\M_laporan\M_laporan_realisasi.php 15
ERROR - 2024-06-05 16:12:32 --> Severity: error --> Exception: Call to undefined method CI_DB_mysqli_result::count_all_result() C:\laragon\www\jmto-eproc\application\models\M_laporan\M_laporan_realisasi.php 15
ERROR - 2024-06-05 16:12:32 --> Severity: error --> Exception: Call to undefined method CI_DB_mysqli_result::count_all_result() C:\laragon\www\jmto-eproc\application\models\M_laporan\M_laporan_realisasi.php 15
ERROR - 2024-06-05 16:20:35 --> Severity: error --> Exception: Call to undefined method CI_DB_mysqli_driver::select_count() C:\laragon\www\jmto-eproc\application\models\M_laporan\M_laporan_realisasi.php 10
