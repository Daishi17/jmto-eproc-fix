<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2024-01-10 13:44:21 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'IN(0, NULL)' at line 5 - Invalid query: SELECT *
FROM `tbl_vendor_mengikuti_paket`
JOIN `tbl_vendor` ON `tbl_vendor_mengikuti_paket`.`id_vendor` = `tbl_vendor`.`id_vendor`
WHERE `tbl_vendor_mengikuti_paket`.`id_rup` = '205'
AND `tbl_vendor_mengikuti_paket`.`nilai_penawaran` != IN(0, NULL)
ERROR - 2024-01-10 13:44:36 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'IN('0', 'NULL')' at line 5 - Invalid query: SELECT *
FROM `tbl_vendor_mengikuti_paket`
JOIN `tbl_vendor` ON `tbl_vendor_mengikuti_paket`.`id_vendor` = `tbl_vendor`.`id_vendor`
WHERE `tbl_vendor_mengikuti_paket`.`id_rup` = '205'
AND `tbl_vendor_mengikuti_paket`.`nilai_penawaran` != IN('0', 'NULL')
ERROR - 2024-01-10 14:26:22 --> Unable to connect to the database
ERROR - 2024-01-10 16:18:26 --> Query error: Unknown column 'sts_ba_pengumuman_hasil_evaluasi_teknis' in 'field list' - Invalid query: UPDATE `tbl_panitia` SET `sts_ba_pengumuman_hasil_evaluasi_teknis` = '1'
WHERE `id_rup` = '205'
AND `id_manajemen_user` = '26'
ERROR - 2024-01-10 16:19:13 --> Query error: Unknown column 'sts_ba_pengumuman_hasil_evaluasi_teknis' in 'field list' - Invalid query: UPDATE `tbl_panitia` SET `sts_ba_pengumuman_hasil_evaluasi_teknis` = '1'
WHERE `id_rup` = '205'
AND `id_manajemen_user` = '26'
ERROR - 2024-01-10 16:19:33 --> Query error: Unknown column 'sts_ba_pengumuman_hasil_evaluasi_teknis' in 'field list' - Invalid query: UPDATE `tbl_panitia` SET `sts_ba_pengumuman_hasil_evaluasi_teknis` = '1'
WHERE `id_rup` = '205'
AND `id_manajemen_user` = '26'
ERROR - 2024-01-10 17:16:35 --> Query error: Unknown column 'sts_ba_penjelasan_kualifikasi' in 'field list' - Invalid query: UPDATE `tbl_panitia` SET `sts_ba_penjelasan_kualifikasi` = '1'
WHERE `id_rup` = '205'
AND `id_manajemen_user` = '26'
ERROR - 2024-01-10 17:16:41 --> Query error: Unknown column 'sts_ba_penjelasan_kualifikasi' in 'field list' - Invalid query: UPDATE `tbl_panitia` SET `sts_ba_penjelasan_kualifikasi` = '1'
WHERE `id_rup` = '205'
AND `id_manajemen_user` = '26'
