<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2024-04-26 10:21:45 --> Severity: error --> Exception: Too few arguments to function Daftar_paket::by_id_rup(), 0 passed in C:\laragon\www\jmto-eproc\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 388
ERROR - 2024-04-26 10:36:59 --> Unable to connect to the database
ERROR - 2024-04-26 12:00:06 --> Unable to connect to the database
ERROR - 2024-04-26 12:00:06 --> Unable to connect to the database
ERROR - 2024-04-26 05:01:59 --> Severity: error --> Exception: syntax error, unexpected '->' (T_OBJECT_OPERATOR) C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_terbatas_pra_1_file.php 751
