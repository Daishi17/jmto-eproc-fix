<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2024-01-28 15:47:52 --> 404 Page Not Found: panitia/info_tender/Informasi_tender_umum_pra_2_file/ba_sampul_I_2
ERROR - 2024-01-28 15:48:22 --> 404 Page Not Found: panitia/info_tender/Informasi_tender_umum_pra_2_file/ba_sampul_I_2
ERROR - 2024-01-28 15:56:18 --> Severity: error --> Exception: Call to undefined method M_panitia::cek_direktur_utama() C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_terbatas_pra_1_file.php 2749
