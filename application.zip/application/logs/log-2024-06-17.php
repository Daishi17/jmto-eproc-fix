<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2024-06-17 01:53:04 --> 404 Page Not Found: administrator/Laporan_realisasi_pengadaan_rup/get_data_realisasi_pengadaan
ERROR - 2024-06-17 01:53:04 --> 404 Page Not Found: administrator/Laporan_realisasi_pengadaan_rup/get_data_realisasi_pengadaan
ERROR - 2024-06-17 01:53:04 --> 404 Page Not Found: administrator/Laporan_realisasi_pengadaan_rup/get_data_realisasi_pengadaan
ERROR - 2024-06-17 01:53:04 --> 404 Page Not Found: administrator/Laporan_realisasi_pengadaan_rup/get_data_realisasi_pengadaan
ERROR - 2024-06-17 01:53:04 --> 404 Page Not Found: administrator/Laporan_realisasi_pengadaan_rup/get_data_realisasi_pengadaan
ERROR - 2024-06-17 01:53:04 --> 404 Page Not Found: administrator/Laporan_realisasi_pengadaan_rup/get_data_realisasi_pengadaan
ERROR - 2024-06-17 01:53:04 --> 404 Page Not Found: administrator/Laporan_realisasi_pengadaan_rup/get_data_realisasi_pengadaan
ERROR - 2024-06-17 01:53:04 --> 404 Page Not Found: administrator/Laporan_realisasi_pengadaan_rup/get_data_realisasi_pengadaan
ERROR - 2024-06-17 01:53:04 --> 404 Page Not Found: administrator/Laporan_realisasi_pengadaan_rup/get_data_realisasi_pengadaan
ERROR - 2024-06-17 01:53:04 --> 404 Page Not Found: administrator/Laporan_realisasi_pengadaan_rup/get_data_realisasi_pengadaan
ERROR - 2024-06-17 01:53:04 --> 404 Page Not Found: administrator/Laporan_realisasi_pengadaan_rup/get_data_realisasi_pengadaan
ERROR - 2024-06-17 01:53:04 --> 404 Page Not Found: administrator/Laporan_realisasi_pengadaan_rup/get_data_realisasi_pengadaan
ERROR - 2024-06-17 01:53:04 --> 404 Page Not Found: administrator/Laporan_realisasi_pengadaan_rup/get_data_realisasi_pengadaan
ERROR - 2024-06-17 01:53:05 --> 404 Page Not Found: administrator/Laporan_realisasi_pengadaan_rup/get_data_realisasi_pengadaan
ERROR - 2024-06-17 01:53:05 --> 404 Page Not Found: administrator/Laporan_realisasi_pengadaan_rup/get_data_realisasi_pengadaan
ERROR - 2024-06-17 01:53:05 --> 404 Page Not Found: administrator/Laporan_realisasi_pengadaan_rup/get_data_realisasi_pengadaan
ERROR - 2024-06-17 01:53:05 --> 404 Page Not Found: administrator/Laporan_realisasi_pengadaan_rup/get_data_realisasi_pengadaan
ERROR - 2024-06-17 01:53:05 --> 404 Page Not Found: administrator/Laporan_realisasi_pengadaan_rup/get_data_realisasi_pengadaan
ERROR - 2024-06-17 01:53:05 --> 404 Page Not Found: administrator/Laporan_realisasi_pengadaan_rup/get_data_realisasi_pengadaan
ERROR - 2024-06-17 01:53:05 --> 404 Page Not Found: administrator/Laporan_realisasi_pengadaan_rup/get_data_realisasi_pengadaan
ERROR - 2024-06-17 01:53:05 --> 404 Page Not Found: administrator/Laporan_realisasi_pengadaan_rup/get_data_realisasi_pengadaan
ERROR - 2024-06-17 01:53:05 --> 404 Page Not Found: administrator/Laporan_realisasi_pengadaan_rup/get_data_realisasi_pengadaan
ERROR - 2024-06-17 01:53:05 --> 404 Page Not Found: administrator/Laporan_realisasi_pengadaan_rup/get_data_realisasi_pengadaan
ERROR - 2024-06-17 01:53:05 --> 404 Page Not Found: administrator/Laporan_realisasi_pengadaan_rup/get_data_realisasi_pengadaan
ERROR - 2024-06-17 01:53:05 --> 404 Page Not Found: administrator/Laporan_realisasi_pengadaan_rup/get_data_realisasi_pengadaan
ERROR - 2024-06-17 01:53:05 --> 404 Page Not Found: administrator/Laporan_realisasi_pengadaan_rup/get_data_realisasi_pengadaan
ERROR - 2024-06-17 01:54:52 --> 404 Page Not Found: administrator/Laporan_realisasi_pengadaan_rup/get_data_jml_paket
ERROR - 2024-06-17 01:54:52 --> 404 Page Not Found: administrator/Laporan_realisasi_pengadaan_rup/get_data_jml_paket
ERROR - 2024-06-17 01:54:52 --> 404 Page Not Found: administrator/Laporan_realisasi_pengadaan_rup/get_data_jml_paket
ERROR - 2024-06-17 01:54:52 --> 404 Page Not Found: administrator/Laporan_realisasi_pengadaan_rup/get_data_jml_paket
ERROR - 2024-06-17 01:54:52 --> 404 Page Not Found: administrator/Laporan_realisasi_pengadaan_rup/get_data_jml_paket
ERROR - 2024-06-17 01:54:52 --> 404 Page Not Found: administrator/Laporan_realisasi_pengadaan_rup/get_data_jml_paket
ERROR - 2024-06-17 01:54:52 --> 404 Page Not Found: administrator/Laporan_realisasi_pengadaan_rup/get_data_jml_paket
ERROR - 2024-06-17 01:54:52 --> 404 Page Not Found: administrator/Laporan_realisasi_pengadaan_rup/get_data_jml_paket
ERROR - 2024-06-17 01:54:52 --> 404 Page Not Found: administrator/Laporan_realisasi_pengadaan_rup/get_data_jml_paket
ERROR - 2024-06-17 01:54:52 --> 404 Page Not Found: administrator/Laporan_realisasi_pengadaan_rup/get_data_jml_paket
ERROR - 2024-06-17 01:54:52 --> 404 Page Not Found: administrator/Laporan_realisasi_pengadaan_rup/get_data_jml_paket
ERROR - 2024-06-17 01:54:53 --> 404 Page Not Found: administrator/Laporan_realisasi_pengadaan_rup/get_data_jml_paket
ERROR - 2024-06-17 01:54:53 --> 404 Page Not Found: administrator/Laporan_realisasi_pengadaan_rup/get_data_jml_paket
ERROR - 2024-06-17 01:55:01 --> 404 Page Not Found: administrator/Laporan_realisasi_pengadaan_rup/get_data_jml_paket
ERROR - 2024-06-17 01:55:01 --> 404 Page Not Found: administrator/Laporan_realisasi_pengadaan_rup/get_data_jml_paket
ERROR - 2024-06-17 01:55:01 --> 404 Page Not Found: administrator/Laporan_realisasi_pengadaan_rup/get_data_jml_paket
ERROR - 2024-06-17 01:55:01 --> 404 Page Not Found: administrator/Laporan_realisasi_pengadaan_rup/get_data_jml_paket
ERROR - 2024-06-17 01:55:01 --> 404 Page Not Found: administrator/Laporan_realisasi_pengadaan_rup/get_data_jml_paket
ERROR - 2024-06-17 01:55:01 --> 404 Page Not Found: administrator/Laporan_realisasi_pengadaan_rup/get_data_jml_paket
ERROR - 2024-06-17 01:55:02 --> 404 Page Not Found: administrator/Laporan_realisasi_pengadaan_rup/get_data_jml_paket
ERROR - 2024-06-17 01:55:02 --> 404 Page Not Found: administrator/Laporan_realisasi_pengadaan_rup/get_data_jml_paket
ERROR - 2024-06-17 01:55:02 --> 404 Page Not Found: administrator/Laporan_realisasi_pengadaan_rup/get_data_jml_paket
ERROR - 2024-06-17 01:55:02 --> 404 Page Not Found: administrator/Laporan_realisasi_pengadaan_rup/get_data_jml_paket
ERROR - 2024-06-17 01:55:02 --> 404 Page Not Found: administrator/Laporan_realisasi_pengadaan_rup/get_data_jml_paket
ERROR - 2024-06-17 01:55:02 --> 404 Page Not Found: administrator/Laporan_realisasi_pengadaan_rup/get_data_jml_paket
ERROR - 2024-06-17 01:55:02 --> 404 Page Not Found: administrator/Laporan_realisasi_pengadaan_rup/get_data_jml_paket
ERROR - 2024-06-17 01:55:02 --> 404 Page Not Found: administrator/Laporan_realisasi_pengadaan_rup/get_data_jml_paket
ERROR - 2024-06-17 01:55:02 --> 404 Page Not Found: administrator/Laporan_realisasi_pengadaan_rup/get_data_jml_paket
ERROR - 2024-06-17 01:55:02 --> 404 Page Not Found: administrator/Laporan_realisasi_pengadaan_rup/get_data_jml_paket
ERROR - 2024-06-17 01:55:02 --> 404 Page Not Found: administrator/Laporan_realisasi_pengadaan_rup/get_data_jml_paket
ERROR - 2024-06-17 01:55:02 --> 404 Page Not Found: administrator/Laporan_realisasi_pengadaan_rup/get_data_jml_paket
ERROR - 2024-06-17 01:55:02 --> 404 Page Not Found: administrator/Laporan_realisasi_pengadaan_rup/get_data_jml_paket
ERROR - 2024-06-17 01:55:02 --> 404 Page Not Found: administrator/Laporan_realisasi_pengadaan_rup/get_data_jml_paket
ERROR - 2024-06-17 01:55:02 --> 404 Page Not Found: administrator/Laporan_realisasi_pengadaan_rup/get_data_jml_paket
ERROR - 2024-06-17 01:55:02 --> 404 Page Not Found: administrator/Laporan_realisasi_pengadaan_rup/get_data_jml_paket
ERROR - 2024-06-17 01:55:02 --> 404 Page Not Found: administrator/Laporan_realisasi_pengadaan_rup/get_data_jml_paket
ERROR - 2024-06-17 01:55:02 --> 404 Page Not Found: administrator/Laporan_realisasi_pengadaan_rup/get_data_jml_paket
ERROR - 2024-06-17 01:55:02 --> 404 Page Not Found: administrator/Laporan_realisasi_pengadaan_rup/get_data_jml_paket
ERROR - 2024-06-17 01:55:02 --> 404 Page Not Found: administrator/Laporan_realisasi_pengadaan_rup/get_data_jml_paket
ERROR - 2024-06-17 09:42:23 --> Severity: Warning --> Division by zero C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_realisasi_rup.php 101
ERROR - 2024-06-17 09:42:23 --> Severity: Warning --> Division by zero C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_realisasi_rup.php 101
ERROR - 2024-06-17 09:42:24 --> Severity: Warning --> Division by zero C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_realisasi_rup.php 101
ERROR - 2024-06-17 09:42:26 --> Severity: Warning --> Division by zero C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_realisasi_rup.php 101
ERROR - 2024-06-17 09:42:26 --> Severity: Warning --> Division by zero C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_realisasi_rup.php 101
ERROR - 2024-06-17 09:42:27 --> Severity: Warning --> Division by zero C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_realisasi_rup.php 101
ERROR - 2024-06-17 09:42:27 --> Severity: Warning --> Division by zero C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_realisasi_rup.php 101
ERROR - 2024-06-17 09:42:28 --> Severity: Warning --> Division by zero C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_realisasi_rup.php 101
ERROR - 2024-06-17 09:42:29 --> Severity: Warning --> Division by zero C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_realisasi_rup.php 101
ERROR - 2024-06-17 09:42:30 --> Severity: Warning --> Division by zero C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_realisasi_rup.php 101
ERROR - 2024-06-17 09:42:31 --> Severity: Warning --> Division by zero C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_realisasi_rup.php 101
ERROR - 2024-06-17 09:42:32 --> Severity: Warning --> Division by zero C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_realisasi_rup.php 101
ERROR - 2024-06-17 09:42:59 --> Severity: Warning --> Division by zero C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_realisasi_rup.php 101
ERROR - 2024-06-17 09:43:00 --> Severity: Warning --> Division by zero C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_realisasi_rup.php 101
ERROR - 2024-06-17 09:43:00 --> Severity: Warning --> Division by zero C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_realisasi_rup.php 101
ERROR - 2024-06-17 09:43:02 --> Severity: Warning --> Division by zero C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_realisasi_rup.php 101
ERROR - 2024-06-17 09:43:03 --> Severity: Warning --> Division by zero C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_realisasi_rup.php 101
ERROR - 2024-06-17 09:43:03 --> Severity: Warning --> Division by zero C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_realisasi_rup.php 101
ERROR - 2024-06-17 09:43:04 --> Severity: Warning --> Division by zero C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_realisasi_rup.php 101
ERROR - 2024-06-17 09:43:05 --> Severity: Warning --> Division by zero C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_realisasi_rup.php 101
ERROR - 2024-06-17 09:43:05 --> Severity: Warning --> Division by zero C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_realisasi_rup.php 101
ERROR - 2024-06-17 09:43:07 --> Severity: Warning --> Division by zero C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_realisasi_rup.php 101
ERROR - 2024-06-17 09:43:08 --> Severity: Warning --> Division by zero C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_realisasi_rup.php 101
ERROR - 2024-06-17 09:43:08 --> Severity: Warning --> Division by zero C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_realisasi_rup.php 101
ERROR - 2024-06-17 09:43:17 --> Severity: Warning --> Division by zero C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_realisasi_rup.php 101
ERROR - 2024-06-17 09:43:18 --> Severity: Warning --> Division by zero C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_realisasi_rup.php 101
ERROR - 2024-06-17 09:43:18 --> Severity: Warning --> Division by zero C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_realisasi_rup.php 101
ERROR - 2024-06-17 09:43:20 --> Severity: Warning --> Division by zero C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_realisasi_rup.php 101
ERROR - 2024-06-17 09:43:20 --> Severity: Warning --> Division by zero C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_realisasi_rup.php 101
ERROR - 2024-06-17 09:43:21 --> Severity: Warning --> Division by zero C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_realisasi_rup.php 101
ERROR - 2024-06-17 09:43:21 --> Severity: Warning --> Division by zero C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_realisasi_rup.php 101
ERROR - 2024-06-17 09:43:22 --> Severity: Warning --> Division by zero C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_realisasi_rup.php 101
ERROR - 2024-06-17 09:43:23 --> Severity: Warning --> Division by zero C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_realisasi_rup.php 101
ERROR - 2024-06-17 09:43:24 --> Severity: Warning --> Division by zero C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_realisasi_rup.php 101
ERROR - 2024-06-17 09:43:25 --> Severity: Warning --> Division by zero C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_realisasi_rup.php 101
ERROR - 2024-06-17 09:43:25 --> Severity: Warning --> Division by zero C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_realisasi_rup.php 101
ERROR - 2024-06-17 09:48:04 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): A connection attempt failed because the connected party did not properly respond after a period of time, or established connection failed because connected host has failed to respond.
 C:\laragon\www\jmto-eproc\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2024-06-17 09:48:04 --> Unable to connect to the database
ERROR - 2024-06-17 09:48:04 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): A connection attempt failed because the connected party did not properly respond after a period of time, or established connection failed because connected host has failed to respond.
 C:\laragon\www\jmto-eproc\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2024-06-17 09:48:04 --> Unable to connect to the database
ERROR - 2024-06-17 02:48:11 --> Unable to connect to the database
