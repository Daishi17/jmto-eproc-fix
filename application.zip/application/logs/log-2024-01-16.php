<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2024-01-16 09:10:59 --> 404 Page Not Found: panitia/info_tender/Informasi_tender_umum_pra_2_file/get_row_vendor_negosiasi
ERROR - 2024-01-16 14:43:53 --> Query error: Not unique table/alias: 'tbl_vendor_syarat_tambahan' - Invalid query: SELECT *
FROM `tbl_vendor_mengikuti_paket`
JOIN `tbl_vendor` ON `tbl_vendor_mengikuti_paket`.`id_vendor` = `tbl_vendor`.`id_vendor`
JOIN `tbl_vendor_syarat_tambahan` ON `tbl_vendor`.`id_vendor` = `tbl_vendor`.`id_vendor`
JOIN `tbl_vendor_syarat_tambahan` ON `tbl_vendor_syarat_tambahan`.`id_rup` = `tbl_vendor`.`id_rup`
WHERE `tbl_vendor_mengikuti_paket`.`id_rup` = '205'
AND `tbl_vendor_mengikuti_paket`.`sts_mengikuti_paket` = 1
AND `tbl_vendor_syarat_tambahan`.`status` != 2
AND `tbl_vendor_syarat_tambahan`.`id_rup` = '205'
ERROR - 2024-01-16 14:44:58 --> Query error: Not unique table/alias: 'tbl_vendor_syarat_tambahan' - Invalid query: SELECT *
FROM `tbl_vendor_mengikuti_paket`
JOIN `tbl_vendor` ON `tbl_vendor_mengikuti_paket`.`id_vendor` = `tbl_vendor`.`id_vendor`
JOIN `tbl_vendor_syarat_tambahan` ON `tbl_vendor`.`id_vendor` = `tbl_vendor_syarat_tambahan`.`id_vendor`
JOIN `tbl_vendor_syarat_tambahan` ON `tbl_vendor_mengikuti_paket`.`id_rup` = `tbl_vendor_syarat_tambahan`.`id_rup`
WHERE `tbl_vendor_mengikuti_paket`.`id_rup` = '205'
AND `tbl_vendor_mengikuti_paket`.`sts_mengikuti_paket` = 1
AND `tbl_vendor_syarat_tambahan`.`status` != 2
AND `tbl_vendor_syarat_tambahan`.`id_rup` = '205'
ERROR - 2024-01-16 14:46:06 --> Query error: Not unique table/alias: 'tbl_vendor_syarat_tambahan' - Invalid query: SELECT *
FROM `tbl_vendor_mengikuti_paket`
JOIN `tbl_vendor` ON `tbl_vendor_mengikuti_paket`.`id_vendor` = `tbl_vendor`.`id_vendor`
JOIN `tbl_vendor_syarat_tambahan` ON `tbl_vendor`.`id_vendor` = `tbl_vendor_syarat_tambahan`.`id_vendor`
JOIN `tbl_vendor_syarat_tambahan` ON `tbl_vendor_mengikuti_paket`.`id_rup` = `tbl_vendor_syarat_tambahan`.`id_rup`
WHERE `tbl_vendor_mengikuti_paket`.`id_rup` = '205'
AND `tbl_vendor_mengikuti_paket`.`sts_mengikuti_paket` = 1
AND `tbl_vendor_syarat_tambahan`.`status` != 2
ERROR - 2024-01-16 15:20:41 --> Query error: Unknown column 'tbl_vendor_mengikuti_paket.id_vendor' in 'on clause' - Invalid query: SELECT *
FROM `tbl_vendor_syarat_tambahan`
JOIN `tbl_vendor` ON `tbl_vendor_mengikuti_paket`.`id_vendor` = `tbl_vendor`.`id_vendor`
WHERE `tbl_vendor_syarat_tambahan`.`id_rup` = '205'
AND `tbl_vendor_syarat_tambahan`.`status` = 2
ERROR - 2024-01-16 15:24:01 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'IN('123')' at line 5 - Invalid query: SELECT *
FROM `tbl_vendor_syarat_tambahan`
JOIN `tbl_vendor` ON `tbl_vendor_syarat_tambahan`.`id_vendor` = `tbl_vendor`.`id_vendor`
WHERE `tbl_vendor_syarat_tambahan`.`id_rup` = '205'
AND `tbl_vendor_syarat_tambahan`.`id_vendor` != IN('123')
ERROR - 2024-01-16 15:28:41 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'IN('123')
GROUP BY `tbl_vendor_syarat_tambahan`.`id_vendor`' at line 5 - Invalid query: SELECT *
FROM `tbl_vendor_syarat_tambahan`
JOIN `tbl_vendor` ON `tbl_vendor_syarat_tambahan`.`id_vendor` = `tbl_vendor`.`id_vendor`
WHERE `tbl_vendor_syarat_tambahan`.`id_rup` = '205'
AND `tbl_vendor_syarat_tambahan`.`id_vendor` != IN('123')
GROUP BY `tbl_vendor_syarat_tambahan`.`id_vendor`
ERROR - 2024-01-16 15:28:48 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'IN('123')' at line 5 - Invalid query: SELECT *
FROM `tbl_vendor_syarat_tambahan`
JOIN `tbl_vendor` ON `tbl_vendor_syarat_tambahan`.`id_vendor` = `tbl_vendor`.`id_vendor`
WHERE `tbl_vendor_syarat_tambahan`.`id_rup` = '205'
AND `tbl_vendor_syarat_tambahan`.`id_vendor` != IN('123')
