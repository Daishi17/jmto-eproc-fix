<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2024-01-02 00:25:08 --> Unable to connect to the database
