<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2024-01-04 11:09:00 --> Severity: error --> Exception: Too few arguments to function Daftar_paket::by_id_rup(), 0 passed in C:\xampp\htdocs\jmto-eproc-fix\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\xampp\htdocs\jmto-eproc-fix\application\controllers\panitia\daftar_paket\Daftar_paket.php 388
ERROR - 2024-01-04 11:11:09 --> Severity: error --> Exception: Too few arguments to function Daftar_paket::by_id_rup(), 0 passed in C:\xampp\htdocs\jmto-eproc-fix\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\xampp\htdocs\jmto-eproc-fix\application\controllers\panitia\daftar_paket\Daftar_paket.php 388
ERROR - 2024-01-04 11:14:37 --> Severity: error --> Exception: Too few arguments to function Daftar_paket::by_id_rup(), 0 passed in C:\xampp\htdocs\jmto-eproc-fix\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\xampp\htdocs\jmto-eproc-fix\application\controllers\panitia\daftar_paket\Daftar_paket.php 388
ERROR - 2024-01-04 14:01:58 --> Query error: MySQL server has gone away - Invalid query: SELECT *
FROM `tbl_rup`
LEFT JOIN `tbl_departemen` ON `tbl_rup`.`id_departemen` = `tbl_departemen`.`id_departemen`
LEFT JOIN `tbl_jadwal_tender` ON `tbl_rup`.`id_jadwal_tender` = `tbl_jadwal_tender`.`id_jadwal_tender`
LEFT JOIN `tbl_section` ON `tbl_rup`.`id_section` = `tbl_section`.`id_section`
LEFT JOIN `tbl_rkap` ON `tbl_rup`.`id_rkap` = `tbl_rkap`.`id_rkap`
LEFT JOIN `tbl_provinsi` ON `tbl_rup`.`id_provinsi` = `tbl_provinsi`.`id_provinsi`
LEFT JOIN `tbl_kabupaten` ON `tbl_rup`.`id_kabupaten` = `tbl_kabupaten`.`id_kabupaten`
LEFT JOIN `tbl_jenis_pengadaan` ON `tbl_rup`.`id_jenis_pengadaan` = `tbl_jenis_pengadaan`.`id_jenis_pengadaan`
LEFT JOIN `tbl_metode_pengadaan` ON `tbl_rup`.`id_metode_pengadaan` = `tbl_metode_pengadaan`.`id_metode_pengadaan`
LEFT JOIN `tbl_jenis_anggaran` ON `tbl_rup`.`id_jenis_anggaran` = `tbl_jenis_anggaran`.`id_jenis_anggaran`
LEFT JOIN `mst_ruas` ON `tbl_rup`.`id_ruas` = `mst_ruas`.`id_ruas`
WHERE `id_url_rup` = '7d2aec7ff9a940e8be2eaeefabac54bf'
ERROR - 2024-01-04 14:02:01 --> Query error: MySQL server has gone away - Invalid query: SELECT *
FROM `tbl_rup`
LEFT JOIN `tbl_departemen` ON `tbl_rup`.`id_departemen` = `tbl_departemen`.`id_departemen`
LEFT JOIN `tbl_jadwal_tender` ON `tbl_rup`.`id_jadwal_tender` = `tbl_jadwal_tender`.`id_jadwal_tender`
LEFT JOIN `tbl_section` ON `tbl_rup`.`id_section` = `tbl_section`.`id_section`
LEFT JOIN `tbl_rkap` ON `tbl_rup`.`id_rkap` = `tbl_rkap`.`id_rkap`
LEFT JOIN `tbl_provinsi` ON `tbl_rup`.`id_provinsi` = `tbl_provinsi`.`id_provinsi`
LEFT JOIN `tbl_kabupaten` ON `tbl_rup`.`id_kabupaten` = `tbl_kabupaten`.`id_kabupaten`
LEFT JOIN `tbl_jenis_pengadaan` ON `tbl_rup`.`id_jenis_pengadaan` = `tbl_jenis_pengadaan`.`id_jenis_pengadaan`
LEFT JOIN `tbl_metode_pengadaan` ON `tbl_rup`.`id_metode_pengadaan` = `tbl_metode_pengadaan`.`id_metode_pengadaan`
LEFT JOIN `tbl_jenis_anggaran` ON `tbl_rup`.`id_jenis_anggaran` = `tbl_jenis_anggaran`.`id_jenis_anggaran`
LEFT JOIN `mst_ruas` ON `tbl_rup`.`id_ruas` = `mst_ruas`.`id_ruas`
WHERE `id_url_rup` = '7d2aec7ff9a940e8be2eaeefabac54bf'
ERROR - 2024-01-04 14:24:33 --> Query error: MySQL server has gone away - Invalid query: SELECT *
FROM `tbl_pegawai`
LEFT JOIN `tbl_manajemen_user` ON `tbl_pegawai`.`id_pegawai` = `tbl_manajemen_user`.`id_pegawai`
WHERE `tbl_manajemen_user`.`username` = 'pantia'
ERROR - 2024-01-04 14:26:42 --> Unable to connect to the database
ERROR - 2024-01-04 14:26:51 --> Unable to connect to the database
ERROR - 2024-01-04 14:30:02 --> Unable to connect to the database
ERROR - 2024-01-04 14:30:18 --> Unable to connect to the database
ERROR - 2024-01-04 14:30:21 --> Unable to connect to the database
ERROR - 2024-01-04 14:30:41 --> Unable to connect to the database
ERROR - 2024-01-04 14:36:27 --> Unable to connect to the database
ERROR - 2024-01-04 14:37:21 --> Unable to connect to the database
ERROR - 2024-01-04 14:38:15 --> Unable to connect to the database
ERROR - 2024-01-04 14:38:27 --> Unable to connect to the database
ERROR - 2024-01-04 14:38:32 --> Unable to connect to the database
ERROR - 2024-01-04 14:38:36 --> Unable to connect to the database
ERROR - 2024-01-04 14:38:50 --> Unable to connect to the database
ERROR - 2024-01-04 14:39:26 --> Query error: MySQL server has gone away - Invalid query: SELECT *
FROM `tbl_pesan`
LEFT JOIN `tbl_vendor` ON `tbl_pesan`.`id_pengirim` = `tbl_vendor`.`id_vendor`
LEFT JOIN `tbl_pegawai` ON `tbl_pesan`.`id_pengirim` = `tbl_pegawai`.`id_pegawai`
WHERE `tbl_pesan`.`id_rup` = '205'
ERROR - 2024-01-04 14:39:42 --> Unable to connect to the database
ERROR - 2024-01-04 14:39:47 --> Unable to connect to the database
ERROR - 2024-01-04 14:40:44 --> Unable to connect to the database
ERROR - 2024-01-04 14:40:51 --> Query error: MySQL server has gone away - Invalid query: SELECT *
FROM `tbl_pesan`
LEFT JOIN `tbl_vendor` ON `tbl_pesan`.`id_pengirim` = `tbl_vendor`.`id_vendor`
LEFT JOIN `tbl_pegawai` ON `tbl_pesan`.`id_pengirim` = `tbl_pegawai`.`id_pegawai`
WHERE `tbl_pesan`.`id_rup` = '205'
ERROR - 2024-01-04 14:40:52 --> Query error: MySQL server has gone away - Invalid query: SELECT *
FROM `tbl_pesan`
LEFT JOIN `tbl_vendor` ON `tbl_pesan`.`id_pengirim` = `tbl_vendor`.`id_vendor`
LEFT JOIN `tbl_pegawai` ON `tbl_pesan`.`id_pengirim` = `tbl_pegawai`.`id_pegawai`
WHERE `tbl_pesan`.`id_rup` = '205'
ERROR - 2024-01-04 14:42:10 --> Unable to connect to the database
ERROR - 2024-01-04 14:42:18 --> Unable to connect to the database
ERROR - 2024-01-04 14:42:41 --> Unable to connect to the database
ERROR - 2024-01-04 14:43:08 --> Unable to connect to the database
ERROR - 2024-01-04 14:43:11 --> Unable to connect to the database
ERROR - 2024-01-04 14:43:55 --> Query error: MySQL server has gone away - Invalid query: SELECT *
FROM `tbl_pesan`
LEFT JOIN `tbl_vendor` ON `tbl_pesan`.`id_pengirim` = `tbl_vendor`.`id_vendor`
LEFT JOIN `tbl_pegawai` ON `tbl_pesan`.`id_pengirim` = `tbl_pegawai`.`id_pegawai`
WHERE `tbl_pesan`.`id_rup` = '205'
ERROR - 2024-01-04 14:44:24 --> Unable to connect to the database
ERROR - 2024-01-04 14:45:04 --> Query error: MySQL server has gone away - Invalid query: SELECT *
FROM `tbl_pesan`
LEFT JOIN `tbl_vendor` ON `tbl_pesan`.`id_pengirim` = `tbl_vendor`.`id_vendor`
LEFT JOIN `tbl_pegawai` ON `tbl_pesan`.`id_pengirim` = `tbl_pegawai`.`id_pegawai`
WHERE `tbl_pesan`.`id_rup` = '205'
ERROR - 2024-01-04 14:45:04 --> Query error: MySQL server has gone away - Invalid query: SELECT *
FROM `tbl_pesan`
LEFT JOIN `tbl_vendor` ON `tbl_pesan`.`id_pengirim` = `tbl_vendor`.`id_vendor`
LEFT JOIN `tbl_pegawai` ON `tbl_pesan`.`id_pengirim` = `tbl_pegawai`.`id_pegawai`
WHERE `tbl_pesan`.`id_rup` = '205'
ERROR - 2024-01-04 14:46:50 --> Query error: MySQL server has gone away - Invalid query: SELECT *
FROM `tbl_pesan`
LEFT JOIN `tbl_vendor` ON `tbl_pesan`.`id_pengirim` = `tbl_vendor`.`id_vendor`
LEFT JOIN `tbl_pegawai` ON `tbl_pesan`.`id_pengirim` = `tbl_pegawai`.`id_pegawai`
WHERE `tbl_pesan`.`id_rup` = '205'
ERROR - 2024-01-04 14:47:48 --> Unable to connect to the database
ERROR - 2024-01-04 14:47:49 --> Unable to connect to the database
ERROR - 2024-01-04 14:48:53 --> Unable to connect to the database
ERROR - 2024-01-04 14:49:03 --> Unable to connect to the database
ERROR - 2024-01-04 14:49:23 --> Unable to connect to the database
ERROR - 2024-01-04 14:49:34 --> Unable to connect to the database
ERROR - 2024-01-04 14:49:50 --> Unable to connect to the database
ERROR - 2024-01-04 14:49:53 --> Unable to connect to the database
ERROR - 2024-01-04 14:50:21 --> Unable to connect to the database
ERROR - 2024-01-04 14:50:51 --> Unable to connect to the database
ERROR - 2024-01-04 14:52:02 --> Unable to connect to the database
ERROR - 2024-01-04 14:52:42 --> Unable to connect to the database
ERROR - 2024-01-04 14:53:44 --> Query error: MySQL server has gone away - Invalid query: SELECT *
FROM `tbl_pesan`
LEFT JOIN `tbl_vendor` ON `tbl_pesan`.`id_pengirim` = `tbl_vendor`.`id_vendor`
LEFT JOIN `tbl_pegawai` ON `tbl_pesan`.`id_pengirim` = `tbl_pegawai`.`id_pegawai`
WHERE `tbl_pesan`.`id_rup` = '205'
ERROR - 2024-01-04 14:53:57 --> Unable to connect to the database
ERROR - 2024-01-04 14:56:49 --> Unable to connect to the database
ERROR - 2024-01-04 14:57:50 --> Query error: MySQL server has gone away - Invalid query: SELECT *
FROM `tbl_pesan`
LEFT JOIN `tbl_vendor` ON `tbl_pesan`.`id_pengirim` = `tbl_vendor`.`id_vendor`
LEFT JOIN `tbl_pegawai` ON `tbl_pesan`.`id_pengirim` = `tbl_pegawai`.`id_pegawai`
WHERE `tbl_pesan`.`id_rup` = '205'
ERROR - 2024-01-04 14:57:51 --> Query error: MySQL server has gone away - Invalid query: SELECT *
FROM `tbl_pesan`
LEFT JOIN `tbl_vendor` ON `tbl_pesan`.`id_pengirim` = `tbl_vendor`.`id_vendor`
LEFT JOIN `tbl_pegawai` ON `tbl_pesan`.`id_pengirim` = `tbl_pegawai`.`id_pegawai`
WHERE `tbl_pesan`.`id_rup` = '205'
ERROR - 2024-01-04 14:57:51 --> Query error: MySQL server has gone away - Invalid query: SELECT *
FROM `tbl_pesan`
LEFT JOIN `tbl_vendor` ON `tbl_pesan`.`id_pengirim` = `tbl_vendor`.`id_vendor`
LEFT JOIN `tbl_pegawai` ON `tbl_pesan`.`id_pengirim` = `tbl_pegawai`.`id_pegawai`
WHERE `tbl_pesan`.`id_rup` = '205'
ERROR - 2024-01-04 14:57:52 --> Query error: MySQL server has gone away - Invalid query: SELECT *
FROM `tbl_pesan`
LEFT JOIN `tbl_vendor` ON `tbl_pesan`.`id_pengirim` = `tbl_vendor`.`id_vendor`
LEFT JOIN `tbl_pegawai` ON `tbl_pesan`.`id_pengirim` = `tbl_pegawai`.`id_pegawai`
WHERE `tbl_pesan`.`id_rup` = '205'
ERROR - 2024-01-04 15:01:08 --> Query error: MySQL server has gone away - Invalid query: SELECT *
FROM `tbl_pesan`
LEFT JOIN `tbl_vendor` ON `tbl_pesan`.`id_pengirim` = `tbl_vendor`.`id_vendor`
LEFT JOIN `tbl_pegawai` ON `tbl_pesan`.`id_pengirim` = `tbl_pegawai`.`id_pegawai`
WHERE `tbl_pesan`.`id_rup` = '205'
ERROR - 2024-01-04 15:01:19 --> Unable to connect to the database
ERROR - 2024-01-04 15:02:01 --> Query error: MySQL server has gone away - Invalid query: SELECT *
FROM `tbl_pesan`
LEFT JOIN `tbl_vendor` ON `tbl_pesan`.`id_pengirim` = `tbl_vendor`.`id_vendor`
LEFT JOIN `tbl_pegawai` ON `tbl_pesan`.`id_pengirim` = `tbl_pegawai`.`id_pegawai`
WHERE `tbl_pesan`.`id_rup` = '205'
ERROR - 2024-01-04 15:02:02 --> Query error: MySQL server has gone away - Invalid query: SELECT *
FROM `tbl_pesan`
LEFT JOIN `tbl_vendor` ON `tbl_pesan`.`id_pengirim` = `tbl_vendor`.`id_vendor`
LEFT JOIN `tbl_pegawai` ON `tbl_pesan`.`id_pengirim` = `tbl_pegawai`.`id_pegawai`
WHERE `tbl_pesan`.`id_rup` = '205'
ERROR - 2024-01-04 15:05:17 --> Unable to connect to the database
ERROR - 2024-01-04 15:07:08 --> Unable to connect to the database
ERROR - 2024-01-04 15:07:20 --> Unable to connect to the database
ERROR - 2024-01-04 15:08:25 --> Unable to connect to the database
