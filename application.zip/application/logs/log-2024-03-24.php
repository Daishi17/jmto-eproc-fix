<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2024-03-24 08:42:34 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user '007jmtoeproc'@'localhost' (using password: YES) C:\laragon\www\jmto-eproc\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2024-03-24 08:42:34 --> Unable to connect to the database
ERROR - 2024-03-24 11:25:52 --> Severity: Warning --> mysqli::real_connect(): php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\laragon\www\jmto-eproc\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2024-03-24 11:25:52 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\laragon\www\jmto-eproc\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2024-03-24 11:25:52 --> Unable to connect to the database
ERROR - 2024-03-24 11:29:11 --> Severity: Warning --> mysqli::real_connect(): (HY000/2006): MySQL server has gone away C:\laragon\www\jmto-eproc\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2024-03-24 11:29:11 --> Unable to connect to the database
ERROR - 2024-03-24 18:45:57 --> 404 Page Not Found: panitia/info_tender/Panitia_terpilih/219
ERROR - 2024-03-24 18:46:20 --> 404 Page Not Found: panitia/info_tender/Panitia_terpilih/get_panitia_ba_1219
ERROR - 2024-03-24 19:23:20 --> 404 Page Not Found: panitia/info_tender/Panitia_terpilih/get_panitia_ba
ERROR - 2024-03-24 19:23:40 --> 404 Page Not Found: panitia/info_tender/Panitia_terpilih/get_panitia_ba
ERROR - 2024-03-24 19:23:50 --> 404 Page Not Found: panitia/info_tender/Panitia_terpilih/get_panitia_ba
ERROR - 2024-03-24 19:23:58 --> 404 Page Not Found: panitia/info_tender/Panitia_terpilih/get_panitia_ba
ERROR - 2024-03-24 20:52:01 --> Severity: error --> Exception: Call to undefined method CI_DB_mysqli_driver::where_not() C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia_terpilih.php 35
ERROR - 2024-03-24 21:04:23 --> Severity: error --> Exception: Call to undefined method M_panitia::get_panitia_ba2() C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 2601
ERROR - 2024-03-24 21:10:15 --> Severity: error --> Exception: Call to a member function get_panitia_ba6() on null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_terbatas_pra_1_file.php 2999
ERROR - 2024-03-24 23:25:23 --> Severity: error --> Exception: Too few arguments to function Daftar_paket::by_id_rup(), 0 passed in C:\laragon\www\jmto-eproc\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 388
