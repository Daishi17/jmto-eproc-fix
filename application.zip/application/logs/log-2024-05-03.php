<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2024-05-03 10:45:40 --> Severity: error --> Exception: Too few arguments to function Daftar_paket::by_id_rup(), 0 passed in C:\laragon\www\jmto-eproc\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 388
ERROR - 2024-05-03 10:48:10 --> Severity: error --> Exception: Too few arguments to function Daftar_paket::by_id_rup(), 0 passed in C:\laragon\www\jmto-eproc\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 388
ERROR - 2024-05-03 13:46:41 --> Severity: Notice --> Undefined variable: result C:\laragon\www\jmto-eproc\application\controllers\administrator\Sirup_rup.php 359
ERROR - 2024-05-03 13:46:41 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\jmto-eproc\application\controllers\administrator\Sirup_rup.php 359
ERROR - 2024-05-03 13:46:41 --> Severity: Notice --> Undefined variable: result C:\laragon\www\jmto-eproc\application\controllers\administrator\Sirup_rup.php 359
ERROR - 2024-05-03 13:46:41 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\jmto-eproc\application\controllers\administrator\Sirup_rup.php 359
ERROR - 2024-05-03 13:46:48 --> Severity: Notice --> Undefined variable: result C:\laragon\www\jmto-eproc\application\controllers\administrator\Sirup_rup.php 359
ERROR - 2024-05-03 13:46:48 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\jmto-eproc\application\controllers\administrator\Sirup_rup.php 359
ERROR - 2024-05-03 13:46:48 --> Severity: Notice --> Undefined variable: result C:\laragon\www\jmto-eproc\application\controllers\administrator\Sirup_rup.php 359
ERROR - 2024-05-03 13:46:48 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\jmto-eproc\application\controllers\administrator\Sirup_rup.php 359
ERROR - 2024-05-03 13:46:49 --> Severity: Notice --> Undefined variable: result C:\laragon\www\jmto-eproc\application\controllers\administrator\Sirup_rup.php 359
ERROR - 2024-05-03 13:46:49 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\jmto-eproc\application\controllers\administrator\Sirup_rup.php 359
ERROR - 2024-05-03 13:46:49 --> Severity: Notice --> Undefined variable: result C:\laragon\www\jmto-eproc\application\controllers\administrator\Sirup_rup.php 359
ERROR - 2024-05-03 13:46:49 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\jmto-eproc\application\controllers\administrator\Sirup_rup.php 359
ERROR - 2024-05-03 14:38:37 --> Severity: Notice --> Trying to get property 'nip' of non-object C:\laragon\www\jmto-eproc\application\libraries\Role_login.php 21
