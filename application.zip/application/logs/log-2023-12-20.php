<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-12-20 14:21:18 --> Severity: error --> Exception: Too few arguments to function M_panitia::result_vendor_terundang(), 7 passed in C:\xampp\htdocs\jmto-eproc-fix\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php on line 1824 and exactly 8 expected C:\xampp\htdocs\jmto-eproc-fix\application\models\M_panitia\M_panitia.php 528
ERROR - 2023-12-20 14:23:52 --> Severity: error --> Exception: Too few arguments to function M_panitia::result_vendor_terundang(), 7 passed in C:\xampp\htdocs\jmto-eproc-fix\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php on line 1824 and exactly 8 expected C:\xampp\htdocs\jmto-eproc-fix\application\models\M_panitia\M_panitia.php 528
ERROR - 2023-12-20 14:25:37 --> Severity: error --> Exception: Too few arguments to function M_panitia::result_vendor_terundang(), 7 passed in C:\xampp\htdocs\jmto-eproc-fix\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php on line 1824 and exactly 8 expected C:\xampp\htdocs\jmto-eproc-fix\application\models\M_panitia\M_panitia.php 528
ERROR - 2023-12-20 14:26:48 --> Severity: error --> Exception: Too few arguments to function M_panitia::result_vendor_terundang(), 7 passed in C:\xampp\htdocs\jmto-eproc-fix\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php on line 1824 and exactly 8 expected C:\xampp\htdocs\jmto-eproc-fix\application\models\M_panitia\M_panitia.php 528
ERROR - 2023-12-20 14:27:12 --> Severity: error --> Exception: Too few arguments to function M_panitia::result_vendor_terundang(), 7 passed in C:\xampp\htdocs\jmto-eproc-fix\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php on line 1824 and exactly 8 expected C:\xampp\htdocs\jmto-eproc-fix\application\models\M_panitia\M_panitia.php 528
ERROR - 2023-12-20 14:27:35 --> Severity: error --> Exception: Too few arguments to function M_panitia::result_vendor_terundang(), 7 passed in C:\xampp\htdocs\jmto-eproc-fix\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php on line 1824 and exactly 8 expected C:\xampp\htdocs\jmto-eproc-fix\application\models\M_panitia\M_panitia.php 528
ERROR - 2023-12-20 14:28:39 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near ')
GROUP BY `tbl_vendor`.`id_vendor`' at line 4 - Invalid query: SELECT `tbl_vendor`.`id_vendor`, `tbl_vendor_kbli_siup`.`id_kbli`
FROM `tbl_vendor`
LEFT JOIN `tbl_vendor_kbli_siup` ON `tbl_vendor_kbli_siup`.`id_vendor` = `tbl_vendor`.`id_vendor`
WHERE `tbl_vendor_kbli_siup`.`id_kbli` IN()
GROUP BY `tbl_vendor`.`id_vendor`
ERROR - 2023-12-20 14:29:53 --> Severity: error --> Exception: Too few arguments to function M_panitia::result_vendor_terundang(), 7 passed in C:\xampp\htdocs\jmto-eproc-fix\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php on line 1824 and exactly 8 expected C:\xampp\htdocs\jmto-eproc-fix\application\models\M_panitia\M_panitia.php 528
ERROR - 2023-12-20 14:31:17 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near ')
GROUP BY `tbl_vendor`.`id_vendor`' at line 4 - Invalid query: SELECT `tbl_vendor`.`id_vendor`, `tbl_vendor_kbli_siup`.`id_kbli`
FROM `tbl_vendor`
LEFT JOIN `tbl_vendor_kbli_siup` ON `tbl_vendor_kbli_siup`.`id_vendor` = `tbl_vendor`.`id_vendor`
WHERE `tbl_vendor_kbli_siup`.`id_kbli` IN()
GROUP BY `tbl_vendor`.`id_vendor`
ERROR - 2023-12-20 14:32:41 --> Severity: error --> Exception: Too few arguments to function M_panitia::result_vendor_terundang(), 7 passed in C:\xampp\htdocs\jmto-eproc-fix\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php on line 1824 and exactly 8 expected C:\xampp\htdocs\jmto-eproc-fix\application\models\M_panitia\M_panitia.php 528
ERROR - 2023-12-20 14:33:07 --> Severity: error --> Exception: Too few arguments to function M_panitia::result_vendor_terundang(), 7 passed in C:\xampp\htdocs\jmto-eproc-fix\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php on line 1824 and exactly 8 expected C:\xampp\htdocs\jmto-eproc-fix\application\models\M_panitia\M_panitia.php 528
ERROR - 2023-12-20 14:33:54 --> Severity: error --> Exception: Too few arguments to function M_panitia::result_vendor_terundang(), 7 passed in C:\xampp\htdocs\jmto-eproc-fix\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php on line 1824 and exactly 8 expected C:\xampp\htdocs\jmto-eproc-fix\application\models\M_panitia\M_panitia.php 528
ERROR - 2023-12-20 14:35:16 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near ')
GROUP BY `tbl_vendor`.`id_vendor`' at line 4 - Invalid query: SELECT `tbl_vendor`.`id_vendor`, `tbl_vendor_kbli_sbu`.`id_sbu`
FROM `tbl_vendor`
LEFT JOIN `tbl_vendor_kbli_sbu` ON `tbl_vendor_kbli_sbu`.`id_vendor` = `tbl_vendor`.`id_vendor`
WHERE `tbl_vendor_kbli_sbu`.`id_sbu` IN()
GROUP BY `tbl_vendor`.`id_vendor`
ERROR - 2023-12-20 14:35:21 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near ')
GROUP BY `tbl_vendor`.`id_vendor`' at line 4 - Invalid query: SELECT `tbl_vendor`.`id_vendor`, `tbl_vendor_kbli_sbu`.`id_sbu`
FROM `tbl_vendor`
LEFT JOIN `tbl_vendor_kbli_sbu` ON `tbl_vendor_kbli_sbu`.`id_vendor` = `tbl_vendor`.`id_vendor`
WHERE `tbl_vendor_kbli_sbu`.`id_sbu` IN()
GROUP BY `tbl_vendor`.`id_vendor`
ERROR - 2023-12-20 14:35:58 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near ')
GROUP BY `tbl_vendor`.`id_vendor`' at line 4 - Invalid query: SELECT `tbl_vendor`.`id_vendor`, `tbl_vendor_kbli_sbu`.`id_sbu`
FROM `tbl_vendor`
LEFT JOIN `tbl_vendor_kbli_sbu` ON `tbl_vendor_kbli_sbu`.`id_vendor` = `tbl_vendor`.`id_vendor`
WHERE `tbl_vendor_kbli_sbu`.`id_sbu` IN()
GROUP BY `tbl_vendor`.`id_vendor`
ERROR - 2023-12-20 14:36:03 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near ')
GROUP BY `tbl_vendor`.`id_vendor`' at line 4 - Invalid query: SELECT `tbl_vendor`.`id_vendor`, `tbl_vendor_kbli_sbu`.`id_sbu`
FROM `tbl_vendor`
LEFT JOIN `tbl_vendor_kbli_sbu` ON `tbl_vendor_kbli_sbu`.`id_vendor` = `tbl_vendor`.`id_vendor`
WHERE `tbl_vendor_kbli_sbu`.`id_sbu` IN()
GROUP BY `tbl_vendor`.`id_vendor`
ERROR - 2023-12-20 14:36:12 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near ')
GROUP BY `tbl_vendor`.`id_vendor`' at line 4 - Invalid query: SELECT `tbl_vendor`.`id_vendor`, `tbl_vendor_kbli_sbu`.`id_sbu`
FROM `tbl_vendor`
LEFT JOIN `tbl_vendor_kbli_sbu` ON `tbl_vendor_kbli_sbu`.`id_vendor` = `tbl_vendor`.`id_vendor`
WHERE `tbl_vendor_kbli_sbu`.`id_sbu` IN()
GROUP BY `tbl_vendor`.`id_vendor`
ERROR - 2023-12-20 14:36:33 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near ')
GROUP BY `tbl_vendor`.`id_vendor`' at line 4 - Invalid query: SELECT `tbl_vendor`.`id_vendor`, `tbl_vendor_kbli_sbu`.`id_sbu`
FROM `tbl_vendor`
LEFT JOIN `tbl_vendor_kbli_sbu` ON `tbl_vendor_kbli_sbu`.`id_vendor` = `tbl_vendor`.`id_vendor`
WHERE `tbl_vendor_kbli_sbu`.`id_sbu` IN()
GROUP BY `tbl_vendor`.`id_vendor`
ERROR - 2023-12-20 14:37:06 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near ')
GROUP BY `tbl_vendor`.`id_vendor`' at line 4 - Invalid query: SELECT `tbl_vendor`.`id_vendor`, `tbl_vendor_kbli_sbu`.`id_sbu`
FROM `tbl_vendor`
LEFT JOIN `tbl_vendor_kbli_sbu` ON `tbl_vendor_kbli_sbu`.`id_vendor` = `tbl_vendor`.`id_vendor`
WHERE `tbl_vendor_kbli_sbu`.`id_sbu` IN()
GROUP BY `tbl_vendor`.`id_vendor`
ERROR - 2023-12-20 14:37:09 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near ')
GROUP BY `tbl_vendor`.`id_vendor`' at line 4 - Invalid query: SELECT `tbl_vendor`.`id_vendor`, `tbl_vendor_kbli_sbu`.`id_sbu`
FROM `tbl_vendor`
LEFT JOIN `tbl_vendor_kbli_sbu` ON `tbl_vendor_kbli_sbu`.`id_vendor` = `tbl_vendor`.`id_vendor`
WHERE `tbl_vendor_kbli_sbu`.`id_sbu` IN()
GROUP BY `tbl_vendor`.`id_vendor`
ERROR - 2023-12-20 14:37:17 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near ')
GROUP BY `tbl_vendor`.`id_vendor`' at line 4 - Invalid query: SELECT `tbl_vendor`.`id_vendor`, `tbl_vendor_kbli_sbu`.`id_sbu`
FROM `tbl_vendor`
LEFT JOIN `tbl_vendor_kbli_sbu` ON `tbl_vendor_kbli_sbu`.`id_vendor` = `tbl_vendor`.`id_vendor`
WHERE `tbl_vendor_kbli_sbu`.`id_sbu` IN()
GROUP BY `tbl_vendor`.`id_vendor`
ERROR - 2023-12-20 14:38:11 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near ')
GROUP BY `tbl_vendor`.`id_vendor`' at line 4 - Invalid query: SELECT `tbl_vendor`.`id_vendor`, `tbl_vendor_kbli_sbu`.`id_sbu`
FROM `tbl_vendor`
LEFT JOIN `tbl_vendor_kbli_sbu` ON `tbl_vendor_kbli_sbu`.`id_vendor` = `tbl_vendor`.`id_vendor`
WHERE `tbl_vendor_kbli_sbu`.`id_sbu` IN()
GROUP BY `tbl_vendor`.`id_vendor`
ERROR - 2023-12-20 14:38:26 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near ')
GROUP BY `tbl_vendor`.`id_vendor`' at line 4 - Invalid query: SELECT `tbl_vendor`.`id_vendor`, `tbl_vendor_kbli_sbu`.`id_sbu`
FROM `tbl_vendor`
LEFT JOIN `tbl_vendor_kbli_sbu` ON `tbl_vendor_kbli_sbu`.`id_vendor` = `tbl_vendor`.`id_vendor`
WHERE `tbl_vendor_kbli_sbu`.`id_sbu` IN()
GROUP BY `tbl_vendor`.`id_vendor`
ERROR - 2023-12-20 14:39:05 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near ')
GROUP BY `tbl_vendor`.`id_vendor`' at line 4 - Invalid query: SELECT `tbl_vendor`.`id_vendor`, `tbl_vendor_kbli_sbu`.`id_sbu`
FROM `tbl_vendor`
LEFT JOIN `tbl_vendor_kbli_sbu` ON `tbl_vendor_kbli_sbu`.`id_vendor` = `tbl_vendor`.`id_vendor`
WHERE `tbl_vendor_kbli_sbu`.`id_sbu` IN()
GROUP BY `tbl_vendor`.`id_vendor`
ERROR - 2023-12-20 14:39:55 --> Severity: error --> Exception: Too few arguments to function M_panitia::result_vendor_terundang(), 7 passed in C:\xampp\htdocs\jmto-eproc-fix\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php on line 1824 and exactly 8 expected C:\xampp\htdocs\jmto-eproc-fix\application\models\M_panitia\M_panitia.php 528
ERROR - 2023-12-20 14:39:59 --> Severity: error --> Exception: Too few arguments to function M_panitia::result_vendor_terundang(), 7 passed in C:\xampp\htdocs\jmto-eproc-fix\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php on line 1824 and exactly 8 expected C:\xampp\htdocs\jmto-eproc-fix\application\models\M_panitia\M_panitia.php 528
ERROR - 2023-12-20 14:40:56 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near ')
GROUP BY `tbl_vendor`.`id_vendor`' at line 4 - Invalid query: SELECT `tbl_vendor`.`id_vendor`, `tbl_vendor_kbli_sbu`.`id_sbu`
FROM `tbl_vendor`
LEFT JOIN `tbl_vendor_kbli_sbu` ON `tbl_vendor_kbli_sbu`.`id_vendor` = `tbl_vendor`.`id_vendor`
WHERE `tbl_vendor_kbli_sbu`.`id_sbu` IN()
GROUP BY `tbl_vendor`.`id_vendor`
ERROR - 2023-12-20 14:41:02 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near ')
GROUP BY `tbl_vendor`.`id_vendor`' at line 4 - Invalid query: SELECT `tbl_vendor`.`id_vendor`, `tbl_vendor_kbli_sbu`.`id_sbu`
FROM `tbl_vendor`
LEFT JOIN `tbl_vendor_kbli_sbu` ON `tbl_vendor_kbli_sbu`.`id_vendor` = `tbl_vendor`.`id_vendor`
WHERE `tbl_vendor_kbli_sbu`.`id_sbu` IN()
GROUP BY `tbl_vendor`.`id_vendor`
ERROR - 2023-12-20 14:42:40 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near ')
GROUP BY `tbl_vendor`.`id_vendor`' at line 4 - Invalid query: SELECT `tbl_vendor`.`id_vendor`, `tbl_vendor_kbli_sbu`.`id_sbu`
FROM `tbl_vendor`
LEFT JOIN `tbl_vendor_kbli_sbu` ON `tbl_vendor_kbli_sbu`.`id_vendor` = `tbl_vendor`.`id_vendor`
WHERE `tbl_vendor_kbli_sbu`.`id_sbu` IN()
GROUP BY `tbl_vendor`.`id_vendor`
ERROR - 2023-12-20 14:43:25 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near ')
GROUP BY `tbl_vendor`.`id_vendor`' at line 4 - Invalid query: SELECT `tbl_vendor`.`id_vendor`, `tbl_vendor_kbli_sbu`.`id_sbu`
FROM `tbl_vendor`
LEFT JOIN `tbl_vendor_kbli_sbu` ON `tbl_vendor_kbli_sbu`.`id_vendor` = `tbl_vendor`.`id_vendor`
WHERE `tbl_vendor_kbli_sbu`.`id_sbu` IN()
GROUP BY `tbl_vendor`.`id_vendor`
ERROR - 2023-12-20 14:43:30 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near ')
GROUP BY `tbl_vendor`.`id_vendor`' at line 4 - Invalid query: SELECT `tbl_vendor`.`id_vendor`, `tbl_vendor_kbli_sbu`.`id_sbu`
FROM `tbl_vendor`
LEFT JOIN `tbl_vendor_kbli_sbu` ON `tbl_vendor_kbli_sbu`.`id_vendor` = `tbl_vendor`.`id_vendor`
WHERE `tbl_vendor_kbli_sbu`.`id_sbu` IN()
GROUP BY `tbl_vendor`.`id_vendor`
ERROR - 2023-12-20 14:43:55 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near ')
GROUP BY `tbl_vendor`.`id_vendor`' at line 4 - Invalid query: SELECT `tbl_vendor`.`id_vendor`, `tbl_vendor_kbli_sbu`.`id_sbu`
FROM `tbl_vendor`
LEFT JOIN `tbl_vendor_kbli_sbu` ON `tbl_vendor_kbli_sbu`.`id_vendor` = `tbl_vendor`.`id_vendor`
WHERE `tbl_vendor_kbli_sbu`.`id_sbu` IN()
GROUP BY `tbl_vendor`.`id_vendor`
ERROR - 2023-12-20 14:45:15 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near ')
GROUP BY `tbl_vendor`.`id_vendor`' at line 4 - Invalid query: SELECT `tbl_vendor`.`id_vendor`, `tbl_vendor_kbli_sbu`.`id_sbu`
FROM `tbl_vendor`
LEFT JOIN `tbl_vendor_kbli_sbu` ON `tbl_vendor_kbli_sbu`.`id_vendor` = `tbl_vendor`.`id_vendor`
WHERE `tbl_vendor_kbli_sbu`.`id_sbu` IN()
GROUP BY `tbl_vendor`.`id_vendor`
ERROR - 2023-12-20 14:46:04 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near ')
GROUP BY `tbl_vendor`.`id_vendor`' at line 4 - Invalid query: SELECT `tbl_vendor`.`id_vendor`, `tbl_vendor_kbli_sbu`.`id_sbu`
FROM `tbl_vendor`
LEFT JOIN `tbl_vendor_kbli_sbu` ON `tbl_vendor_kbli_sbu`.`id_vendor` = `tbl_vendor`.`id_vendor`
WHERE `tbl_vendor_kbli_sbu`.`id_sbu` IN()
GROUP BY `tbl_vendor`.`id_vendor`
ERROR - 2023-12-20 14:46:42 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near ')
GROUP BY `tbl_vendor`.`id_vendor`' at line 4 - Invalid query: SELECT `tbl_vendor`.`id_vendor`, `tbl_vendor_kbli_sbu`.`id_sbu`
FROM `tbl_vendor`
LEFT JOIN `tbl_vendor_kbli_sbu` ON `tbl_vendor_kbli_sbu`.`id_vendor` = `tbl_vendor`.`id_vendor`
WHERE `tbl_vendor_kbli_sbu`.`id_sbu` IN()
GROUP BY `tbl_vendor`.`id_vendor`
ERROR - 2023-12-20 14:47:07 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near ')
GROUP BY `tbl_vendor`.`id_vendor`' at line 4 - Invalid query: SELECT `tbl_vendor`.`id_vendor`, `tbl_vendor_kbli_siup`.`id_kbli`
FROM `tbl_vendor`
LEFT JOIN `tbl_vendor_kbli_siup` ON `tbl_vendor_kbli_siup`.`id_vendor` = `tbl_vendor`.`id_vendor`
WHERE `tbl_vendor_kbli_siup`.`id_kbli` IN()
GROUP BY `tbl_vendor`.`id_vendor`
ERROR - 2023-12-20 14:47:18 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near ')
GROUP BY `tbl_vendor`.`id_vendor`' at line 4 - Invalid query: SELECT `tbl_vendor`.`id_vendor`, `tbl_vendor_kbli_sbu`.`id_sbu`
FROM `tbl_vendor`
LEFT JOIN `tbl_vendor_kbli_sbu` ON `tbl_vendor_kbli_sbu`.`id_vendor` = `tbl_vendor`.`id_vendor`
WHERE `tbl_vendor_kbli_sbu`.`id_sbu` IN()
GROUP BY `tbl_vendor`.`id_vendor`
ERROR - 2023-12-20 14:49:02 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near ')
GROUP BY `tbl_vendor`.`id_vendor`' at line 4 - Invalid query: SELECT `tbl_vendor`.`id_vendor`, `tbl_vendor_kbli_siup`.`id_kbli`
FROM `tbl_vendor`
LEFT JOIN `tbl_vendor_kbli_siup` ON `tbl_vendor_kbli_siup`.`id_vendor` = `tbl_vendor`.`id_vendor`
WHERE `tbl_vendor_kbli_siup`.`id_kbli` IN()
GROUP BY `tbl_vendor`.`id_vendor`
ERROR - 2023-12-20 14:49:33 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near ')
GROUP BY `tbl_vendor`.`id_vendor`' at line 4 - Invalid query: SELECT `tbl_vendor`.`id_vendor`, `tbl_vendor_kbli_siup`.`id_kbli`
FROM `tbl_vendor`
LEFT JOIN `tbl_vendor_kbli_siup` ON `tbl_vendor_kbli_siup`.`id_vendor` = `tbl_vendor`.`id_vendor`
WHERE `tbl_vendor_kbli_siup`.`id_kbli` IN()
GROUP BY `tbl_vendor`.`id_vendor`
ERROR - 2023-12-20 14:50:01 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near ')
GROUP BY `tbl_vendor`.`id_vendor`' at line 4 - Invalid query: SELECT `tbl_vendor`.`id_vendor`, `tbl_vendor_kbli_siup`.`id_kbli`
FROM `tbl_vendor`
LEFT JOIN `tbl_vendor_kbli_siup` ON `tbl_vendor_kbli_siup`.`id_vendor` = `tbl_vendor`.`id_vendor`
WHERE `tbl_vendor_kbli_siup`.`id_kbli` IN()
GROUP BY `tbl_vendor`.`id_vendor`
ERROR - 2023-12-20 14:53:31 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near ')
GROUP BY `tbl_vendor`.`id_vendor`' at line 4 - Invalid query: SELECT `tbl_vendor`.`id_vendor`, `tbl_vendor_kbli_siup`.`id_kbli`
FROM `tbl_vendor`
LEFT JOIN `tbl_vendor_kbli_siup` ON `tbl_vendor_kbli_siup`.`id_vendor` = `tbl_vendor`.`id_vendor`
WHERE `tbl_vendor_kbli_siup`.`id_kbli` IN()
GROUP BY `tbl_vendor`.`id_vendor`
ERROR - 2023-12-20 14:56:56 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '`NULL`
GROUP BY `tbl_vendor_spt`.`id_vendor`' at line 3 - Invalid query: SELECT *
FROM `tbl_vendor_spt`
WHERE `tbl_vendor_spt`.`tahun_lapor` > `IS` `NULL`
GROUP BY `tbl_vendor_spt`.`id_vendor`
ERROR - 2023-12-20 14:58:05 --> Severity: error --> Exception: Too few arguments to function M_panitia::result_vendor_terundang(), 7 passed in C:\xampp\htdocs\jmto-eproc-fix\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php on line 1824 and exactly 8 expected C:\xampp\htdocs\jmto-eproc-fix\application\models\M_panitia\M_panitia.php 531
ERROR - 2023-12-20 14:58:35 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '`NULL`
GROUP BY `tbl_vendor_spt`.`id_vendor`' at line 3 - Invalid query: SELECT *
FROM `tbl_vendor_spt`
WHERE `tbl_vendor_spt`.`tahun_lapor` > `IS` `NULL`
GROUP BY `tbl_vendor_spt`.`id_vendor`
ERROR - 2023-12-20 14:58:49 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '`NULL`
GROUP BY `tbl_vendor_spt`.`id_vendor`' at line 3 - Invalid query: SELECT *
FROM `tbl_vendor_spt`
WHERE `tbl_vendor_spt`.`tahun_lapor` > `IS` `NULL`
GROUP BY `tbl_vendor_spt`.`id_vendor`
ERROR - 2023-12-20 14:59:28 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '`NULL`
GROUP BY `tbl_vendor_spt`.`id_vendor`' at line 3 - Invalid query: SELECT *
FROM `tbl_vendor_spt`
WHERE `tbl_vendor_spt`.`tahun_lapor` > `IS` `NULL`
GROUP BY `tbl_vendor_spt`.`id_vendor`
ERROR - 2023-12-20 14:59:35 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '`NULL`
GROUP BY `tbl_vendor_spt`.`id_vendor`' at line 3 - Invalid query: SELECT *
FROM `tbl_vendor_spt`
WHERE `tbl_vendor_spt`.`tahun_lapor` > `IS` `NULL`
GROUP BY `tbl_vendor_spt`.`id_vendor`
ERROR - 2023-12-20 15:01:02 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '`NULL`
GROUP BY `tbl_vendor_spt`.`id_vendor`' at line 3 - Invalid query: SELECT *
FROM `tbl_vendor_spt`
WHERE `tbl_vendor_spt`.`tahun_lapor` > `IS` `NULL`
GROUP BY `tbl_vendor_spt`.`id_vendor`
ERROR - 2023-12-20 15:01:25 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '`NULL`
GROUP BY `tbl_vendor_spt`.`id_vendor`' at line 3 - Invalid query: SELECT *
FROM `tbl_vendor_spt`
WHERE `tbl_vendor_spt`.`tahun_lapor` > `IS` `NULL`
GROUP BY `tbl_vendor_spt`.`id_vendor`
ERROR - 2023-12-20 15:02:14 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '`NULL`
GROUP BY `tbl_vendor_spt`.`id_vendor`' at line 3 - Invalid query: SELECT *
FROM `tbl_vendor_spt`
WHERE `tbl_vendor_spt`.`tahun_lapor` > `IS` `NULL`
GROUP BY `tbl_vendor_spt`.`id_vendor`
ERROR - 2023-12-20 17:31:52 --> Severity: Notice --> Undefined variable: jadwal_aanwijzing_pq C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\index.php 907
ERROR - 2023-12-20 17:31:52 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\index.php 907
ERROR - 2023-12-20 17:31:52 --> Severity: Notice --> Undefined variable: jadwal_aanwijzing_pq C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\index.php 908
ERROR - 2023-12-20 17:31:52 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\index.php 908
ERROR - 2023-12-20 17:31:52 --> Severity: Notice --> Undefined variable: jadwal_aanwijzing_pq C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\index.php 910
ERROR - 2023-12-20 17:31:52 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\index.php 910
ERROR - 2023-12-20 17:31:52 --> Severity: Notice --> Undefined variable: jadwal_aanwijzing_pq C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\index.php 911
ERROR - 2023-12-20 17:31:52 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\index.php 911
ERROR - 2023-12-20 17:31:52 --> Severity: Notice --> Undefined variable: jadwal_aanwijzing_pq C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\index.php 911
ERROR - 2023-12-20 17:31:52 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\index.php 911
ERROR - 2023-12-20 17:31:52 --> Severity: Notice --> Undefined variable: jadwal_aanwijzing C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\index.php 989
ERROR - 2023-12-20 17:31:52 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\index.php 989
ERROR - 2023-12-20 17:31:52 --> Severity: Notice --> Undefined variable: jadwal_aanwijzing C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\index.php 990
ERROR - 2023-12-20 17:31:52 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\index.php 990
ERROR - 2023-12-20 17:31:52 --> Severity: Notice --> Undefined variable: jadwal_aanwijzing C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\index.php 992
ERROR - 2023-12-20 17:31:52 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\index.php 992
ERROR - 2023-12-20 17:31:52 --> Severity: Notice --> Undefined variable: jadwal_aanwijzing C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\index.php 993
ERROR - 2023-12-20 17:31:52 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\index.php 993
ERROR - 2023-12-20 17:31:52 --> Severity: Notice --> Undefined variable: jadwal_aanwijzing C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\index.php 993
ERROR - 2023-12-20 17:31:52 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\index.php 993
ERROR - 2023-12-20 17:31:53 --> Severity: Notice --> Undefined variable: jadwal_aanwijzing_pq C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\index.php 907
ERROR - 2023-12-20 17:31:53 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\index.php 907
ERROR - 2023-12-20 17:31:53 --> Severity: Notice --> Undefined variable: jadwal_aanwijzing_pq C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\index.php 908
ERROR - 2023-12-20 17:31:53 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\index.php 908
ERROR - 2023-12-20 17:31:53 --> Severity: Notice --> Undefined variable: jadwal_aanwijzing_pq C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\index.php 910
ERROR - 2023-12-20 17:31:53 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\index.php 910
ERROR - 2023-12-20 17:31:53 --> Severity: Notice --> Undefined variable: jadwal_aanwijzing_pq C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\index.php 911
ERROR - 2023-12-20 17:31:53 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\index.php 911
ERROR - 2023-12-20 17:31:53 --> Severity: Notice --> Undefined variable: jadwal_aanwijzing_pq C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\index.php 911
ERROR - 2023-12-20 17:31:53 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\index.php 911
ERROR - 2023-12-20 17:31:53 --> Severity: Notice --> Undefined variable: jadwal_aanwijzing C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\index.php 989
ERROR - 2023-12-20 17:31:53 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\index.php 989
ERROR - 2023-12-20 17:31:53 --> Severity: Notice --> Undefined variable: jadwal_aanwijzing C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\index.php 990
ERROR - 2023-12-20 17:31:53 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\index.php 990
ERROR - 2023-12-20 17:31:53 --> Severity: Notice --> Undefined variable: jadwal_aanwijzing C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\index.php 992
ERROR - 2023-12-20 17:31:53 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\index.php 992
ERROR - 2023-12-20 17:31:53 --> Severity: Notice --> Undefined variable: jadwal_aanwijzing C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\index.php 993
ERROR - 2023-12-20 17:31:53 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\index.php 993
ERROR - 2023-12-20 17:31:53 --> Severity: Notice --> Undefined variable: jadwal_aanwijzing C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\index.php 993
ERROR - 2023-12-20 17:31:53 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\index.php 993
ERROR - 2023-12-20 17:31:54 --> Severity: Notice --> Undefined variable: jadwal_aanwijzing_pq C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\index.php 907
ERROR - 2023-12-20 17:31:54 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\index.php 907
ERROR - 2023-12-20 17:31:54 --> Severity: Notice --> Undefined variable: jadwal_aanwijzing_pq C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\index.php 908
ERROR - 2023-12-20 17:31:54 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\index.php 908
ERROR - 2023-12-20 17:31:54 --> Severity: Notice --> Undefined variable: jadwal_aanwijzing_pq C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\index.php 910
ERROR - 2023-12-20 17:31:54 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\index.php 910
ERROR - 2023-12-20 17:31:54 --> Severity: Notice --> Undefined variable: jadwal_aanwijzing_pq C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\index.php 911
ERROR - 2023-12-20 17:31:54 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\index.php 911
ERROR - 2023-12-20 17:31:54 --> Severity: Notice --> Undefined variable: jadwal_aanwijzing_pq C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\index.php 911
ERROR - 2023-12-20 17:31:54 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\index.php 911
ERROR - 2023-12-20 17:31:54 --> Severity: Notice --> Undefined variable: jadwal_aanwijzing C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\index.php 989
ERROR - 2023-12-20 17:31:54 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\index.php 989
ERROR - 2023-12-20 17:31:54 --> Severity: Notice --> Undefined variable: jadwal_aanwijzing C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\index.php 990
ERROR - 2023-12-20 17:31:54 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\index.php 990
ERROR - 2023-12-20 17:31:54 --> Severity: Notice --> Undefined variable: jadwal_aanwijzing C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\index.php 992
ERROR - 2023-12-20 17:31:54 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\index.php 992
ERROR - 2023-12-20 17:31:54 --> Severity: Notice --> Undefined variable: jadwal_aanwijzing C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\index.php 993
ERROR - 2023-12-20 17:31:54 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\index.php 993
ERROR - 2023-12-20 17:31:54 --> Severity: Notice --> Undefined variable: jadwal_aanwijzing C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\index.php 993
ERROR - 2023-12-20 17:31:54 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\index.php 993
ERROR - 2023-12-20 17:31:54 --> Severity: Notice --> Undefined variable: jadwal_aanwijzing_pq C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\index.php 907
ERROR - 2023-12-20 17:31:54 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\index.php 907
ERROR - 2023-12-20 17:31:54 --> Severity: Notice --> Undefined variable: jadwal_aanwijzing_pq C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\index.php 908
ERROR - 2023-12-20 17:31:54 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\index.php 908
ERROR - 2023-12-20 17:31:54 --> Severity: Notice --> Undefined variable: jadwal_aanwijzing_pq C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\index.php 910
ERROR - 2023-12-20 17:31:54 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\index.php 910
ERROR - 2023-12-20 17:31:54 --> Severity: Notice --> Undefined variable: jadwal_aanwijzing_pq C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\index.php 911
ERROR - 2023-12-20 17:31:54 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\index.php 911
ERROR - 2023-12-20 17:31:54 --> Severity: Notice --> Undefined variable: jadwal_aanwijzing_pq C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\index.php 911
ERROR - 2023-12-20 17:31:54 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\index.php 911
ERROR - 2023-12-20 17:31:54 --> Severity: Notice --> Undefined variable: jadwal_aanwijzing C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\index.php 989
ERROR - 2023-12-20 17:31:54 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\index.php 989
ERROR - 2023-12-20 17:31:54 --> Severity: Notice --> Undefined variable: jadwal_aanwijzing C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\index.php 990
ERROR - 2023-12-20 17:31:54 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\index.php 990
ERROR - 2023-12-20 17:31:54 --> Severity: Notice --> Undefined variable: jadwal_aanwijzing C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\index.php 992
ERROR - 2023-12-20 17:31:54 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\index.php 992
ERROR - 2023-12-20 17:31:54 --> Severity: Notice --> Undefined variable: jadwal_aanwijzing C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\index.php 993
ERROR - 2023-12-20 17:31:54 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\index.php 993
ERROR - 2023-12-20 17:31:54 --> Severity: Notice --> Undefined variable: jadwal_aanwijzing C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\index.php 993
ERROR - 2023-12-20 17:31:54 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\index.php 993
ERROR - 2023-12-20 17:31:58 --> Severity: error --> Exception: Too few arguments to function M_panitia::result_vendor_terundang(), 7 passed in C:\xampp\htdocs\jmto-eproc-fix\application\controllers\panitia\info_tender\Informasi_tender_penunjukan_langsung.php on line 1323 and exactly 8 expected C:\xampp\htdocs\jmto-eproc-fix\application\models\M_panitia\M_panitia.php 531
ERROR - 2023-12-20 17:50:31 --> Severity: Notice --> Undefined variable: jadwal_aanwijzing_pq C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\index.php 907
ERROR - 2023-12-20 17:50:31 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\index.php 907
ERROR - 2023-12-20 17:50:31 --> Severity: Notice --> Undefined variable: jadwal_aanwijzing_pq C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\index.php 908
ERROR - 2023-12-20 17:50:31 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\index.php 908
ERROR - 2023-12-20 17:50:31 --> Severity: Notice --> Undefined variable: jadwal_aanwijzing_pq C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\index.php 910
ERROR - 2023-12-20 17:50:31 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\index.php 910
ERROR - 2023-12-20 17:50:31 --> Severity: Notice --> Undefined variable: jadwal_aanwijzing_pq C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\index.php 911
ERROR - 2023-12-20 17:50:31 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\index.php 911
ERROR - 2023-12-20 17:50:31 --> Severity: Notice --> Undefined variable: jadwal_aanwijzing_pq C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\index.php 911
ERROR - 2023-12-20 17:50:31 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\index.php 911
ERROR - 2023-12-20 17:50:31 --> Severity: Notice --> Undefined variable: jadwal_aanwijzing C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\index.php 989
ERROR - 2023-12-20 17:50:31 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\index.php 989
ERROR - 2023-12-20 17:50:31 --> Severity: Notice --> Undefined variable: jadwal_aanwijzing C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\index.php 990
ERROR - 2023-12-20 17:50:31 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\index.php 990
ERROR - 2023-12-20 17:50:31 --> Severity: Notice --> Undefined variable: jadwal_aanwijzing C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\index.php 992
ERROR - 2023-12-20 17:50:31 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\index.php 992
ERROR - 2023-12-20 17:50:31 --> Severity: Notice --> Undefined variable: jadwal_aanwijzing C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\index.php 993
ERROR - 2023-12-20 17:50:31 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\index.php 993
ERROR - 2023-12-20 17:50:31 --> Severity: Notice --> Undefined variable: jadwal_aanwijzing C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\index.php 993
ERROR - 2023-12-20 17:50:31 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\index.php 993
ERROR - 2023-12-20 17:50:32 --> Severity: Notice --> Undefined variable: jadwal_aanwijzing_pq C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\index.php 907
ERROR - 2023-12-20 17:50:32 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\index.php 907
ERROR - 2023-12-20 17:50:32 --> Severity: Notice --> Undefined variable: jadwal_aanwijzing_pq C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\index.php 908
ERROR - 2023-12-20 17:50:32 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\index.php 908
ERROR - 2023-12-20 17:50:32 --> Severity: Notice --> Undefined variable: jadwal_aanwijzing_pq C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\index.php 910
ERROR - 2023-12-20 17:50:32 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\index.php 910
ERROR - 2023-12-20 17:50:32 --> Severity: Notice --> Undefined variable: jadwal_aanwijzing_pq C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\index.php 911
ERROR - 2023-12-20 17:50:32 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\index.php 911
ERROR - 2023-12-20 17:50:32 --> Severity: Notice --> Undefined variable: jadwal_aanwijzing_pq C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\index.php 911
ERROR - 2023-12-20 17:50:32 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\index.php 911
ERROR - 2023-12-20 17:50:32 --> Severity: Notice --> Undefined variable: jadwal_aanwijzing C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\index.php 989
ERROR - 2023-12-20 17:50:32 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\index.php 989
ERROR - 2023-12-20 17:50:32 --> Severity: Notice --> Undefined variable: jadwal_aanwijzing C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\index.php 990
ERROR - 2023-12-20 17:50:32 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\index.php 990
ERROR - 2023-12-20 17:50:32 --> Severity: Notice --> Undefined variable: jadwal_aanwijzing C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\index.php 992
ERROR - 2023-12-20 17:50:32 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\index.php 992
ERROR - 2023-12-20 17:50:32 --> Severity: Notice --> Undefined variable: jadwal_aanwijzing C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\index.php 993
ERROR - 2023-12-20 17:50:32 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\index.php 993
ERROR - 2023-12-20 17:50:32 --> Severity: Notice --> Undefined variable: jadwal_aanwijzing C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\index.php 993
ERROR - 2023-12-20 17:50:32 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\index.php 993
ERROR - 2023-12-20 17:50:32 --> Severity: Notice --> Undefined variable: jadwal_aanwijzing_pq C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\index.php 907
ERROR - 2023-12-20 17:50:32 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\index.php 907
ERROR - 2023-12-20 17:50:32 --> Severity: Notice --> Undefined variable: jadwal_aanwijzing_pq C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\index.php 908
ERROR - 2023-12-20 17:50:32 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\index.php 908
ERROR - 2023-12-20 17:50:32 --> Severity: Notice --> Undefined variable: jadwal_aanwijzing_pq C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\index.php 910
ERROR - 2023-12-20 17:50:32 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\index.php 910
ERROR - 2023-12-20 17:50:32 --> Severity: Notice --> Undefined variable: jadwal_aanwijzing_pq C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\index.php 911
ERROR - 2023-12-20 17:50:32 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\index.php 911
ERROR - 2023-12-20 17:50:32 --> Severity: Notice --> Undefined variable: jadwal_aanwijzing_pq C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\index.php 911
ERROR - 2023-12-20 17:50:32 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\index.php 911
ERROR - 2023-12-20 17:50:32 --> Severity: Notice --> Undefined variable: jadwal_aanwijzing C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\index.php 989
ERROR - 2023-12-20 17:50:32 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\index.php 989
ERROR - 2023-12-20 17:50:32 --> Severity: Notice --> Undefined variable: jadwal_aanwijzing C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\index.php 990
ERROR - 2023-12-20 17:50:32 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\index.php 990
ERROR - 2023-12-20 17:50:32 --> Severity: Notice --> Undefined variable: jadwal_aanwijzing C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\index.php 992
ERROR - 2023-12-20 17:50:32 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\index.php 992
ERROR - 2023-12-20 17:50:32 --> Severity: Notice --> Undefined variable: jadwal_aanwijzing C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\index.php 993
ERROR - 2023-12-20 17:50:32 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\index.php 993
ERROR - 2023-12-20 17:50:32 --> Severity: Notice --> Undefined variable: jadwal_aanwijzing C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\index.php 993
ERROR - 2023-12-20 17:50:32 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\index.php 993
ERROR - 2023-12-20 17:50:33 --> Severity: Notice --> Undefined variable: jadwal_aanwijzing_pq C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\index.php 907
ERROR - 2023-12-20 17:50:33 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\index.php 907
ERROR - 2023-12-20 17:50:33 --> Severity: Notice --> Undefined variable: jadwal_aanwijzing_pq C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\index.php 908
ERROR - 2023-12-20 17:50:33 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\index.php 908
ERROR - 2023-12-20 17:50:33 --> Severity: Notice --> Undefined variable: jadwal_aanwijzing_pq C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\index.php 910
ERROR - 2023-12-20 17:50:33 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\index.php 910
ERROR - 2023-12-20 17:50:33 --> Severity: Notice --> Undefined variable: jadwal_aanwijzing_pq C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\index.php 911
ERROR - 2023-12-20 17:50:33 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\index.php 911
ERROR - 2023-12-20 17:50:33 --> Severity: Notice --> Undefined variable: jadwal_aanwijzing_pq C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\index.php 911
ERROR - 2023-12-20 17:50:33 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\index.php 911
ERROR - 2023-12-20 17:50:33 --> Severity: Notice --> Undefined variable: jadwal_aanwijzing C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\index.php 989
ERROR - 2023-12-20 17:50:33 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\index.php 989
ERROR - 2023-12-20 17:50:33 --> Severity: Notice --> Undefined variable: jadwal_aanwijzing C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\index.php 990
ERROR - 2023-12-20 17:50:33 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\index.php 990
ERROR - 2023-12-20 17:50:33 --> Severity: Notice --> Undefined variable: jadwal_aanwijzing C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\index.php 992
ERROR - 2023-12-20 17:50:33 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\index.php 992
ERROR - 2023-12-20 17:50:33 --> Severity: Notice --> Undefined variable: jadwal_aanwijzing C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\index.php 993
ERROR - 2023-12-20 17:50:33 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\index.php 993
ERROR - 2023-12-20 17:50:33 --> Severity: Notice --> Undefined variable: jadwal_aanwijzing C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\index.php 993
ERROR - 2023-12-20 17:50:33 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\index.php 993
ERROR - 2023-12-20 17:50:34 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc-fix\application\controllers\panitia\info_tender\Informasi_tender_penunjukan_langsung.php 1811
ERROR - 2023-12-20 17:50:34 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc-fix\application\controllers\panitia\info_tender\Informasi_tender_penunjukan_langsung.php 1812
ERROR - 2023-12-20 17:50:34 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc-fix\application\controllers\panitia\info_tender\Informasi_tender_penunjukan_langsung.php 1811
ERROR - 2023-12-20 17:50:34 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc-fix\application\controllers\panitia\info_tender\Informasi_tender_penunjukan_langsung.php 1812
ERROR - 2023-12-20 17:50:35 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc-fix\application\controllers\panitia\info_tender\Informasi_tender_penunjukan_langsung.php 1811
ERROR - 2023-12-20 17:50:35 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc-fix\application\controllers\panitia\info_tender\Informasi_tender_penunjukan_langsung.php 1812
ERROR - 2023-12-20 17:50:35 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc-fix\application\controllers\panitia\info_tender\Informasi_tender_penunjukan_langsung.php 1811
ERROR - 2023-12-20 17:50:35 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc-fix\application\controllers\panitia\info_tender\Informasi_tender_penunjukan_langsung.php 1812
ERROR - 2023-12-20 17:50:45 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\aanwijzing.php 505
ERROR - 2023-12-20 17:50:45 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\aanwijzing.php 505
ERROR - 2023-12-20 17:50:45 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\aanwijzing.php 523
ERROR - 2023-12-20 17:50:45 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\aanwijzing.php 526
ERROR - 2023-12-20 17:50:48 --> Severity: Notice --> Undefined variable: jadwal_aanwijzing_pq C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\index.php 907
ERROR - 2023-12-20 17:50:48 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\index.php 907
ERROR - 2023-12-20 17:50:48 --> Severity: Notice --> Undefined variable: jadwal_aanwijzing_pq C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\index.php 908
ERROR - 2023-12-20 17:50:48 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\index.php 908
ERROR - 2023-12-20 17:50:48 --> Severity: Notice --> Undefined variable: jadwal_aanwijzing_pq C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\index.php 910
ERROR - 2023-12-20 17:50:48 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\index.php 910
ERROR - 2023-12-20 17:50:48 --> Severity: Notice --> Undefined variable: jadwal_aanwijzing_pq C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\index.php 911
ERROR - 2023-12-20 17:50:48 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\index.php 911
ERROR - 2023-12-20 17:50:48 --> Severity: Notice --> Undefined variable: jadwal_aanwijzing_pq C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\index.php 911
ERROR - 2023-12-20 17:50:48 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\index.php 911
ERROR - 2023-12-20 17:50:48 --> Severity: Notice --> Undefined variable: jadwal_aanwijzing C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\index.php 989
ERROR - 2023-12-20 17:50:48 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\index.php 989
ERROR - 2023-12-20 17:50:48 --> Severity: Notice --> Undefined variable: jadwal_aanwijzing C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\index.php 990
ERROR - 2023-12-20 17:50:48 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\index.php 990
ERROR - 2023-12-20 17:50:48 --> Severity: Notice --> Undefined variable: jadwal_aanwijzing C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\index.php 992
ERROR - 2023-12-20 17:50:48 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\index.php 992
ERROR - 2023-12-20 17:50:48 --> Severity: Notice --> Undefined variable: jadwal_aanwijzing C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\index.php 993
ERROR - 2023-12-20 17:50:48 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\index.php 993
ERROR - 2023-12-20 17:50:48 --> Severity: Notice --> Undefined variable: jadwal_aanwijzing C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\index.php 993
ERROR - 2023-12-20 17:50:48 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\index.php 993
ERROR - 2023-12-20 17:50:49 --> Severity: Notice --> Undefined variable: jadwal_aanwijzing_pq C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\index.php 907
ERROR - 2023-12-20 17:50:49 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\index.php 907
ERROR - 2023-12-20 17:50:49 --> Severity: Notice --> Undefined variable: jadwal_aanwijzing_pq C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\index.php 908
ERROR - 2023-12-20 17:50:49 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\index.php 908
ERROR - 2023-12-20 17:50:49 --> Severity: Notice --> Undefined variable: jadwal_aanwijzing_pq C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\index.php 910
ERROR - 2023-12-20 17:50:49 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\index.php 910
ERROR - 2023-12-20 17:50:49 --> Severity: Notice --> Undefined variable: jadwal_aanwijzing_pq C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\index.php 911
ERROR - 2023-12-20 17:50:49 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\index.php 911
ERROR - 2023-12-20 17:50:49 --> Severity: Notice --> Undefined variable: jadwal_aanwijzing_pq C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\index.php 911
ERROR - 2023-12-20 17:50:49 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\index.php 911
ERROR - 2023-12-20 17:50:49 --> Severity: Notice --> Undefined variable: jadwal_aanwijzing C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\index.php 989
ERROR - 2023-12-20 17:50:49 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\index.php 989
ERROR - 2023-12-20 17:50:49 --> Severity: Notice --> Undefined variable: jadwal_aanwijzing C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\index.php 990
ERROR - 2023-12-20 17:50:49 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\index.php 990
ERROR - 2023-12-20 17:50:49 --> Severity: Notice --> Undefined variable: jadwal_aanwijzing C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\index.php 992
ERROR - 2023-12-20 17:50:49 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\index.php 992
ERROR - 2023-12-20 17:50:49 --> Severity: Notice --> Undefined variable: jadwal_aanwijzing C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\index.php 993
ERROR - 2023-12-20 17:50:49 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\index.php 993
ERROR - 2023-12-20 17:50:49 --> Severity: Notice --> Undefined variable: jadwal_aanwijzing C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\index.php 993
ERROR - 2023-12-20 17:50:49 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\index.php 993
ERROR - 2023-12-20 17:50:49 --> Severity: Notice --> Undefined variable: jadwal_aanwijzing_pq C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\index.php 907
ERROR - 2023-12-20 17:50:49 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\index.php 907
ERROR - 2023-12-20 17:50:49 --> Severity: Notice --> Undefined variable: jadwal_aanwijzing_pq C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\index.php 908
ERROR - 2023-12-20 17:50:49 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\index.php 908
ERROR - 2023-12-20 17:50:49 --> Severity: Notice --> Undefined variable: jadwal_aanwijzing_pq C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\index.php 910
ERROR - 2023-12-20 17:50:49 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\index.php 910
ERROR - 2023-12-20 17:50:49 --> Severity: Notice --> Undefined variable: jadwal_aanwijzing_pq C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\index.php 911
ERROR - 2023-12-20 17:50:49 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\index.php 911
ERROR - 2023-12-20 17:50:49 --> Severity: Notice --> Undefined variable: jadwal_aanwijzing_pq C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\index.php 911
ERROR - 2023-12-20 17:50:49 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\index.php 911
ERROR - 2023-12-20 17:50:49 --> Severity: Notice --> Undefined variable: jadwal_aanwijzing C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\index.php 989
ERROR - 2023-12-20 17:50:49 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\index.php 989
ERROR - 2023-12-20 17:50:49 --> Severity: Notice --> Undefined variable: jadwal_aanwijzing C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\index.php 990
ERROR - 2023-12-20 17:50:49 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\index.php 990
ERROR - 2023-12-20 17:50:49 --> Severity: Notice --> Undefined variable: jadwal_aanwijzing C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\index.php 992
ERROR - 2023-12-20 17:50:49 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\index.php 992
ERROR - 2023-12-20 17:50:49 --> Severity: Notice --> Undefined variable: jadwal_aanwijzing C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\index.php 993
ERROR - 2023-12-20 17:50:49 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\index.php 993
ERROR - 2023-12-20 17:50:49 --> Severity: Notice --> Undefined variable: jadwal_aanwijzing C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\index.php 993
ERROR - 2023-12-20 17:50:49 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\index.php 993
ERROR - 2023-12-20 17:50:50 --> Severity: Notice --> Undefined variable: jadwal_aanwijzing_pq C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\index.php 907
ERROR - 2023-12-20 17:50:50 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\index.php 907
ERROR - 2023-12-20 17:50:50 --> Severity: Notice --> Undefined variable: jadwal_aanwijzing_pq C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\index.php 908
ERROR - 2023-12-20 17:50:50 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\index.php 908
ERROR - 2023-12-20 17:50:50 --> Severity: Notice --> Undefined variable: jadwal_aanwijzing_pq C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\index.php 910
ERROR - 2023-12-20 17:50:50 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\index.php 910
ERROR - 2023-12-20 17:50:50 --> Severity: Notice --> Undefined variable: jadwal_aanwijzing_pq C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\index.php 911
ERROR - 2023-12-20 17:50:50 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\index.php 911
ERROR - 2023-12-20 17:50:50 --> Severity: Notice --> Undefined variable: jadwal_aanwijzing_pq C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\index.php 911
ERROR - 2023-12-20 17:50:50 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\index.php 911
ERROR - 2023-12-20 17:50:50 --> Severity: Notice --> Undefined variable: jadwal_aanwijzing C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\index.php 989
ERROR - 2023-12-20 17:50:50 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\index.php 989
ERROR - 2023-12-20 17:50:50 --> Severity: Notice --> Undefined variable: jadwal_aanwijzing C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\index.php 990
ERROR - 2023-12-20 17:50:50 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\index.php 990
ERROR - 2023-12-20 17:50:50 --> Severity: Notice --> Undefined variable: jadwal_aanwijzing C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\index.php 992
ERROR - 2023-12-20 17:50:50 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\index.php 992
ERROR - 2023-12-20 17:50:50 --> Severity: Notice --> Undefined variable: jadwal_aanwijzing C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\index.php 993
ERROR - 2023-12-20 17:50:50 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\index.php 993
ERROR - 2023-12-20 17:50:50 --> Severity: Notice --> Undefined variable: jadwal_aanwijzing C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\index.php 993
ERROR - 2023-12-20 17:50:50 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\index.php 993
ERROR - 2023-12-20 17:51:30 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc-fix\application\controllers\panitia\info_tender\Informasi_tender_penunjukan_langsung.php 1811
ERROR - 2023-12-20 17:51:30 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc-fix\application\controllers\panitia\info_tender\Informasi_tender_penunjukan_langsung.php 1812
ERROR - 2023-12-20 17:51:31 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc-fix\application\controllers\panitia\info_tender\Informasi_tender_penunjukan_langsung.php 1811
ERROR - 2023-12-20 17:51:31 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc-fix\application\controllers\panitia\info_tender\Informasi_tender_penunjukan_langsung.php 1812
ERROR - 2023-12-20 17:51:31 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc-fix\application\controllers\panitia\info_tender\Informasi_tender_penunjukan_langsung.php 1811
ERROR - 2023-12-20 17:51:31 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc-fix\application\controllers\panitia\info_tender\Informasi_tender_penunjukan_langsung.php 1812
ERROR - 2023-12-20 17:51:31 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc-fix\application\controllers\panitia\info_tender\Informasi_tender_penunjukan_langsung.php 1811
ERROR - 2023-12-20 17:51:31 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc-fix\application\controllers\panitia\info_tender\Informasi_tender_penunjukan_langsung.php 1812
ERROR - 2023-12-20 17:51:32 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc-fix\application\controllers\panitia\info_tender\Informasi_tender_penunjukan_langsung.php 1811
ERROR - 2023-12-20 17:51:32 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc-fix\application\controllers\panitia\info_tender\Informasi_tender_penunjukan_langsung.php 1812
ERROR - 2023-12-20 17:51:35 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc-fix\application\controllers\panitia\info_tender\Informasi_tender_penunjukan_langsung.php 1811
ERROR - 2023-12-20 17:51:35 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc-fix\application\controllers\panitia\info_tender\Informasi_tender_penunjukan_langsung.php 1812
ERROR - 2023-12-20 17:51:35 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc-fix\application\controllers\panitia\info_tender\Informasi_tender_penunjukan_langsung.php 1811
ERROR - 2023-12-20 17:51:35 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc-fix\application\controllers\panitia\info_tender\Informasi_tender_penunjukan_langsung.php 1812
ERROR - 2023-12-20 17:51:36 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc-fix\application\controllers\panitia\info_tender\Informasi_tender_penunjukan_langsung.php 1811
ERROR - 2023-12-20 17:51:36 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc-fix\application\controllers\panitia\info_tender\Informasi_tender_penunjukan_langsung.php 1812
ERROR - 2023-12-20 17:51:36 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc-fix\application\controllers\panitia\info_tender\Informasi_tender_penunjukan_langsung.php 1811
ERROR - 2023-12-20 17:51:36 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc-fix\application\controllers\panitia\info_tender\Informasi_tender_penunjukan_langsung.php 1812
ERROR - 2023-12-20 17:52:00 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc-fix\application\controllers\panitia\info_tender\Informasi_tender_penunjukan_langsung.php 1811
ERROR - 2023-12-20 17:52:00 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc-fix\application\controllers\panitia\info_tender\Informasi_tender_penunjukan_langsung.php 1812
ERROR - 2023-12-20 17:52:01 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc-fix\application\controllers\panitia\info_tender\Informasi_tender_penunjukan_langsung.php 1811
ERROR - 2023-12-20 17:52:01 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc-fix\application\controllers\panitia\info_tender\Informasi_tender_penunjukan_langsung.php 1812
ERROR - 2023-12-20 17:52:01 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc-fix\application\controllers\panitia\info_tender\Informasi_tender_penunjukan_langsung.php 1811
ERROR - 2023-12-20 17:52:01 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc-fix\application\controllers\panitia\info_tender\Informasi_tender_penunjukan_langsung.php 1812
ERROR - 2023-12-20 17:52:01 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc-fix\application\controllers\panitia\info_tender\Informasi_tender_penunjukan_langsung.php 1811
ERROR - 2023-12-20 17:52:01 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc-fix\application\controllers\panitia\info_tender\Informasi_tender_penunjukan_langsung.php 1812
ERROR - 2023-12-20 17:52:09 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc-fix\application\controllers\panitia\info_tender\Informasi_tender_penunjukan_langsung.php 1811
ERROR - 2023-12-20 17:52:09 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc-fix\application\controllers\panitia\info_tender\Informasi_tender_penunjukan_langsung.php 1812
ERROR - 2023-12-20 17:52:10 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc-fix\application\controllers\panitia\info_tender\Informasi_tender_penunjukan_langsung.php 1811
ERROR - 2023-12-20 17:52:10 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc-fix\application\controllers\panitia\info_tender\Informasi_tender_penunjukan_langsung.php 1812
ERROR - 2023-12-20 17:52:10 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc-fix\application\controllers\panitia\info_tender\Informasi_tender_penunjukan_langsung.php 1811
ERROR - 2023-12-20 17:52:10 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc-fix\application\controllers\panitia\info_tender\Informasi_tender_penunjukan_langsung.php 1812
ERROR - 2023-12-20 17:52:11 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc-fix\application\controllers\panitia\info_tender\Informasi_tender_penunjukan_langsung.php 1811
ERROR - 2023-12-20 17:52:11 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc-fix\application\controllers\panitia\info_tender\Informasi_tender_penunjukan_langsung.php 1812
ERROR - 2023-12-20 17:52:13 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\aanwijzing.php 505
ERROR - 2023-12-20 17:52:13 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\aanwijzing.php 505
ERROR - 2023-12-20 17:52:13 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\aanwijzing.php 523
ERROR - 2023-12-20 17:52:13 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\aanwijzing.php 526
ERROR - 2023-12-20 17:52:44 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\aanwijzing.php 505
ERROR - 2023-12-20 17:52:44 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\aanwijzing.php 505
ERROR - 2023-12-20 17:52:44 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\aanwijzing.php 523
ERROR - 2023-12-20 17:52:44 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\aanwijzing.php 526
ERROR - 2023-12-20 17:52:59 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\aanwijzing.php 506
ERROR - 2023-12-20 17:52:59 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\aanwijzing.php 506
ERROR - 2023-12-20 17:52:59 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\aanwijzing.php 524
ERROR - 2023-12-20 17:52:59 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\aanwijzing.php 527
ERROR - 2023-12-20 17:53:00 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc-fix\application\controllers\panitia\info_tender\Informasi_tender_penunjukan_langsung.php 1811
ERROR - 2023-12-20 17:53:00 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc-fix\application\controllers\panitia\info_tender\Informasi_tender_penunjukan_langsung.php 1812
ERROR - 2023-12-20 17:59:23 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc-fix\application\controllers\panitia\info_tender\Informasi_tender_penunjukan_langsung.php 1799
ERROR - 2023-12-20 17:59:23 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc-fix\application\controllers\panitia\info_tender\Informasi_tender_penunjukan_langsung.php 1800
ERROR - 2023-12-20 17:59:23 --> Severity: Notice --> Undefined variable: jadwal_aanwijzing_pq C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\index.php 907
ERROR - 2023-12-20 17:59:23 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\index.php 907
ERROR - 2023-12-20 17:59:23 --> Severity: Notice --> Undefined variable: jadwal_aanwijzing_pq C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\index.php 908
ERROR - 2023-12-20 17:59:23 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\index.php 908
ERROR - 2023-12-20 17:59:23 --> Severity: Notice --> Undefined variable: jadwal_aanwijzing_pq C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\index.php 910
ERROR - 2023-12-20 17:59:23 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\index.php 910
ERROR - 2023-12-20 17:59:23 --> Severity: Notice --> Undefined variable: jadwal_aanwijzing_pq C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\index.php 911
ERROR - 2023-12-20 17:59:23 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\index.php 911
ERROR - 2023-12-20 17:59:23 --> Severity: Notice --> Undefined variable: jadwal_aanwijzing_pq C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\index.php 911
ERROR - 2023-12-20 17:59:23 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\index.php 911
ERROR - 2023-12-20 17:59:23 --> Severity: Notice --> Undefined variable: jadwal_aanwijzing C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\index.php 989
ERROR - 2023-12-20 17:59:23 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\index.php 989
ERROR - 2023-12-20 17:59:23 --> Severity: Notice --> Undefined variable: jadwal_aanwijzing C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\index.php 990
ERROR - 2023-12-20 17:59:23 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\index.php 990
ERROR - 2023-12-20 17:59:23 --> Severity: Notice --> Undefined variable: jadwal_aanwijzing C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\index.php 992
ERROR - 2023-12-20 17:59:23 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\index.php 992
ERROR - 2023-12-20 17:59:23 --> Severity: Notice --> Undefined variable: jadwal_aanwijzing C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\index.php 993
ERROR - 2023-12-20 17:59:23 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\index.php 993
ERROR - 2023-12-20 17:59:23 --> Severity: Notice --> Undefined variable: jadwal_aanwijzing C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\index.php 993
ERROR - 2023-12-20 17:59:23 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\index.php 993
ERROR - 2023-12-20 17:59:23 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc-fix\application\controllers\panitia\info_tender\Informasi_tender_penunjukan_langsung.php 1799
ERROR - 2023-12-20 17:59:23 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc-fix\application\controllers\panitia\info_tender\Informasi_tender_penunjukan_langsung.php 1800
ERROR - 2023-12-20 17:59:24 --> Severity: Notice --> Undefined variable: jadwal_aanwijzing_pq C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\index.php 907
ERROR - 2023-12-20 17:59:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\index.php 907
ERROR - 2023-12-20 17:59:24 --> Severity: Notice --> Undefined variable: jadwal_aanwijzing_pq C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\index.php 908
ERROR - 2023-12-20 17:59:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\index.php 908
ERROR - 2023-12-20 17:59:24 --> Severity: Notice --> Undefined variable: jadwal_aanwijzing_pq C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\index.php 910
ERROR - 2023-12-20 17:59:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\index.php 910
ERROR - 2023-12-20 17:59:24 --> Severity: Notice --> Undefined variable: jadwal_aanwijzing_pq C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\index.php 911
ERROR - 2023-12-20 17:59:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\index.php 911
ERROR - 2023-12-20 17:59:24 --> Severity: Notice --> Undefined variable: jadwal_aanwijzing_pq C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\index.php 911
ERROR - 2023-12-20 17:59:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\index.php 911
ERROR - 2023-12-20 17:59:24 --> Severity: Notice --> Undefined variable: jadwal_aanwijzing C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\index.php 989
ERROR - 2023-12-20 17:59:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\index.php 989
ERROR - 2023-12-20 17:59:24 --> Severity: Notice --> Undefined variable: jadwal_aanwijzing C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\index.php 990
ERROR - 2023-12-20 17:59:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\index.php 990
ERROR - 2023-12-20 17:59:24 --> Severity: Notice --> Undefined variable: jadwal_aanwijzing C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\index.php 992
ERROR - 2023-12-20 17:59:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\index.php 992
ERROR - 2023-12-20 17:59:24 --> Severity: Notice --> Undefined variable: jadwal_aanwijzing C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\index.php 993
ERROR - 2023-12-20 17:59:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\index.php 993
ERROR - 2023-12-20 17:59:24 --> Severity: Notice --> Undefined variable: jadwal_aanwijzing C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\index.php 993
ERROR - 2023-12-20 17:59:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\index.php 993
ERROR - 2023-12-20 17:59:25 --> Severity: Notice --> Undefined variable: jadwal_aanwijzing_pq C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\index.php 907
ERROR - 2023-12-20 17:59:25 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\index.php 907
ERROR - 2023-12-20 17:59:25 --> Severity: Notice --> Undefined variable: jadwal_aanwijzing_pq C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\index.php 908
ERROR - 2023-12-20 17:59:25 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\index.php 908
ERROR - 2023-12-20 17:59:25 --> Severity: Notice --> Undefined variable: jadwal_aanwijzing_pq C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\index.php 910
ERROR - 2023-12-20 17:59:25 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\index.php 910
ERROR - 2023-12-20 17:59:25 --> Severity: Notice --> Undefined variable: jadwal_aanwijzing_pq C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\index.php 911
ERROR - 2023-12-20 17:59:25 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\index.php 911
ERROR - 2023-12-20 17:59:25 --> Severity: Notice --> Undefined variable: jadwal_aanwijzing_pq C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\index.php 911
ERROR - 2023-12-20 17:59:25 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\index.php 911
ERROR - 2023-12-20 17:59:25 --> Severity: Notice --> Undefined variable: jadwal_aanwijzing C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\index.php 989
ERROR - 2023-12-20 17:59:25 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\index.php 989
ERROR - 2023-12-20 17:59:25 --> Severity: Notice --> Undefined variable: jadwal_aanwijzing C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\index.php 990
ERROR - 2023-12-20 17:59:25 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\index.php 990
ERROR - 2023-12-20 17:59:25 --> Severity: Notice --> Undefined variable: jadwal_aanwijzing C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\index.php 992
ERROR - 2023-12-20 17:59:25 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\index.php 992
ERROR - 2023-12-20 17:59:25 --> Severity: Notice --> Undefined variable: jadwal_aanwijzing C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\index.php 993
ERROR - 2023-12-20 17:59:25 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\index.php 993
ERROR - 2023-12-20 17:59:25 --> Severity: Notice --> Undefined variable: jadwal_aanwijzing C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\index.php 993
ERROR - 2023-12-20 17:59:25 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\index.php 993
ERROR - 2023-12-20 17:59:25 --> Severity: Notice --> Undefined variable: jadwal_aanwijzing_pq C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\index.php 907
ERROR - 2023-12-20 17:59:25 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\index.php 907
ERROR - 2023-12-20 17:59:25 --> Severity: Notice --> Undefined variable: jadwal_aanwijzing_pq C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\index.php 908
ERROR - 2023-12-20 17:59:25 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\index.php 908
ERROR - 2023-12-20 17:59:25 --> Severity: Notice --> Undefined variable: jadwal_aanwijzing_pq C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\index.php 910
ERROR - 2023-12-20 17:59:25 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\index.php 910
ERROR - 2023-12-20 17:59:25 --> Severity: Notice --> Undefined variable: jadwal_aanwijzing_pq C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\index.php 911
ERROR - 2023-12-20 17:59:25 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\index.php 911
ERROR - 2023-12-20 17:59:25 --> Severity: Notice --> Undefined variable: jadwal_aanwijzing_pq C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\index.php 911
ERROR - 2023-12-20 17:59:25 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\index.php 911
ERROR - 2023-12-20 17:59:25 --> Severity: Notice --> Undefined variable: jadwal_aanwijzing C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\index.php 989
ERROR - 2023-12-20 17:59:25 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\index.php 989
ERROR - 2023-12-20 17:59:25 --> Severity: Notice --> Undefined variable: jadwal_aanwijzing C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\index.php 990
ERROR - 2023-12-20 17:59:25 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\index.php 990
ERROR - 2023-12-20 17:59:25 --> Severity: Notice --> Undefined variable: jadwal_aanwijzing C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\index.php 992
ERROR - 2023-12-20 17:59:25 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\index.php 992
ERROR - 2023-12-20 17:59:25 --> Severity: Notice --> Undefined variable: jadwal_aanwijzing C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\index.php 993
ERROR - 2023-12-20 17:59:25 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\index.php 993
ERROR - 2023-12-20 17:59:25 --> Severity: Notice --> Undefined variable: jadwal_aanwijzing C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\index.php 993
ERROR - 2023-12-20 17:59:25 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\jmto-eproc-fix\application\views\panitia\info_tender\Informasi_tender_penunjukan_langsung\index.php 993
