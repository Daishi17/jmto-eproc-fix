<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-12-20 14:53:29 --> Severity: error --> Exception: Function name must be a string C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\print_ba\undangan_penawaran.php 163
ERROR - 2023-12-20 14:53:29 --> Severity: error --> Exception: Function name must be a string C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\print_ba\undangan_penawaran.php 163
ERROR - 2023-12-20 15:12:06 --> 404 Page Not Found: panitia/info_tender/Informasi_tender_terbatas_pra_1_file/undangan_penawaran
ERROR - 2023-12-20 15:12:11 --> Severity: error --> Exception: Function name must be a string C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\print_ba\undangan_penawaran.php 163
ERROR - 2023-12-20 15:12:12 --> Severity: error --> Exception: Function name must be a string C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\print_ba\undangan_penawaran.php 163
ERROR - 2023-12-20 16:05:52 --> 404 Page Not Found: panitia/info_tender/Informasi_tender_terbatas_pra_1_file/undangan_penawaran
ERROR - 2023-12-20 16:09:13 --> Severity: Notice --> Undefined offset: 2 C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\print_ba\undangan_penawaran.php 54
ERROR - 2023-12-20 16:09:13 --> Severity: Notice --> Undefined offset: 1 C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\print_ba\undangan_penawaran.php 54
ERROR - 2023-12-20 16:09:13 --> Severity: Notice --> Undefined offset: 0 C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\print_ba\undangan_penawaran.php 54
ERROR - 2023-12-20 16:09:14 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_terbatas_pra_1_file.php 2278
ERROR - 2023-12-20 16:09:14 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_terbatas_pra_1_file.php 2279
ERROR - 2023-12-20 16:09:14 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_terbatas_pra_1_file.php 2280
ERROR - 2023-12-20 16:09:14 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_terbatas_pra_1_file.php 2281
ERROR - 2023-12-20 16:09:14 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_terbatas_pra_1_file.php 2282
ERROR - 2023-12-20 16:09:14 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_terbatas_pra_1_file.php 2284
ERROR - 2023-12-20 16:09:14 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_terbatas_pra_1_file.php 2285
ERROR - 2023-12-20 16:09:14 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_terbatas_pra_1_file.php 2286
ERROR - 2023-12-20 16:09:14 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\print_ba\undangan_penawaran.php 132
ERROR - 2023-12-20 16:09:14 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\print_ba\undangan_penawaran.php 137
ERROR - 2023-12-20 16:09:14 --> Severity: Notice --> Undefined offset: 2 C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\print_ba\undangan_penawaran.php 54
ERROR - 2023-12-20 16:09:14 --> Severity: Notice --> Undefined offset: 1 C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\print_ba\undangan_penawaran.php 54
ERROR - 2023-12-20 16:09:14 --> Severity: Notice --> Undefined offset: 0 C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\print_ba\undangan_penawaran.php 54
ERROR - 2023-12-20 16:09:14 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\print_ba\undangan_penawaran.php 148
ERROR - 2023-12-20 16:09:14 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\print_ba\undangan_penawaran.php 155
ERROR - 2023-12-20 16:09:14 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\print_ba\undangan_penawaran.php 163
ERROR - 2023-12-20 16:09:14 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\print_ba\undangan_penawaran.php 168
ERROR - 2023-12-20 16:09:14 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\print_ba\undangan_penawaran.php 168
ERROR - 2023-12-20 16:09:14 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\print_ba\undangan_penawaran.php 183
ERROR - 2023-12-20 16:09:14 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\print_ba\undangan_penawaran.php 188
ERROR - 2023-12-20 16:09:14 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\print_ba\undangan_penawaran.php 188
ERROR - 2023-12-20 16:09:14 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\print_ba\undangan_penawaran.php 223
ERROR - 2023-12-20 16:09:14 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\print_ba\undangan_penawaran.php 228
ERROR - 2023-12-20 16:09:14 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\print_ba\undangan_penawaran.php 228
ERROR - 2023-12-20 16:09:14 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\print_ba\undangan_penawaran.php 250
ERROR - 2023-12-20 16:15:52 --> Unable to connect to the database
ERROR - 2023-12-20 16:16:01 --> Unable to connect to the database
ERROR - 2023-12-20 16:16:21 --> Unable to connect to the database
ERROR - 2023-12-20 16:16:21 --> Unable to connect to the database
