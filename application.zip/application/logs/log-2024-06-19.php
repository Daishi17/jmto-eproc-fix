<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2024-06-19 09:56:11 --> Severity: error --> Exception: Too few arguments to function Rekanan_tervalidasi::get_dokumen_vendor(), 0 passed in C:\laragon\www\jmto-eproc\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\laragon\www\jmto-eproc\application\controllers\validator\Rekanan_tervalidasi.php 306
ERROR - 2024-06-19 10:10:33 --> Severity: error --> Exception: Too few arguments to function Rekanan_tervalidasi::get_dokumen_vendor(), 0 passed in C:\laragon\www\jmto-eproc\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\laragon\www\jmto-eproc\application\controllers\validator\Rekanan_tervalidasi.php 306
