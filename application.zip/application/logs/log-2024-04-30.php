<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2024-04-30 13:24:11 --> Severity: Notice --> Trying to get property 'nip' of non-object C:\laragon\www\jmto-eproc\application\libraries\Role_login.php 21
ERROR - 2024-04-30 13:26:43 --> Severity: Warning --> number_format() expects parameter 1 to be float, string given C:\laragon\www\jmto-eproc\application\controllers\Get_rupiah.php 24
ERROR - 2024-04-30 13:26:43 --> Severity: Warning --> number_format() expects parameter 1 to be float, string given C:\laragon\www\jmto-eproc\application\controllers\Get_rupiah.php 24
ERROR - 2024-04-30 13:26:44 --> Severity: Warning --> number_format() expects parameter 1 to be float, string given C:\laragon\www\jmto-eproc\application\controllers\Get_rupiah.php 24
ERROR - 2024-04-30 13:26:44 --> Severity: Warning --> number_format() expects parameter 1 to be float, string given C:\laragon\www\jmto-eproc\application\controllers\Get_rupiah.php 24
ERROR - 2024-04-30 13:26:44 --> Severity: Warning --> number_format() expects parameter 1 to be float, string given C:\laragon\www\jmto-eproc\application\controllers\Get_rupiah.php 24
ERROR - 2024-04-30 13:26:44 --> Severity: Warning --> number_format() expects parameter 1 to be float, string given C:\laragon\www\jmto-eproc\application\controllers\Get_rupiah.php 24
ERROR - 2024-04-30 13:26:45 --> Severity: Warning --> number_format() expects parameter 1 to be float, string given C:\laragon\www\jmto-eproc\application\controllers\Get_rupiah.php 24
ERROR - 2024-04-30 13:26:45 --> Severity: Warning --> number_format() expects parameter 1 to be float, string given C:\laragon\www\jmto-eproc\application\controllers\Get_rupiah.php 24
ERROR - 2024-04-30 13:26:46 --> Severity: Warning --> number_format() expects parameter 1 to be float, string given C:\laragon\www\jmto-eproc\application\controllers\Get_rupiah.php 24
ERROR - 2024-04-30 13:26:46 --> Severity: Warning --> number_format() expects parameter 1 to be float, string given C:\laragon\www\jmto-eproc\application\controllers\Get_rupiah.php 24
ERROR - 2024-04-30 13:26:54 --> Severity: Warning --> number_format() expects parameter 1 to be float, string given C:\laragon\www\jmto-eproc\application\controllers\Get_rupiah.php 24
ERROR - 2024-04-30 13:26:54 --> Severity: Warning --> number_format() expects parameter 1 to be float, string given C:\laragon\www\jmto-eproc\application\controllers\Get_rupiah.php 24
ERROR - 2024-04-30 13:27:05 --> Severity: Warning --> number_format() expects parameter 1 to be float, string given C:\laragon\www\jmto-eproc\application\controllers\Get_rupiah.php 24
ERROR - 2024-04-30 13:27:05 --> Severity: Warning --> number_format() expects parameter 1 to be float, string given C:\laragon\www\jmto-eproc\application\controllers\Get_rupiah.php 24
ERROR - 2024-04-30 13:27:06 --> Severity: Warning --> number_format() expects parameter 1 to be float, string given C:\laragon\www\jmto-eproc\application\controllers\Get_rupiah.php 24
ERROR - 2024-04-30 13:27:06 --> Severity: Warning --> number_format() expects parameter 1 to be float, string given C:\laragon\www\jmto-eproc\application\controllers\Get_rupiah.php 24
ERROR - 2024-04-30 13:27:24 --> Severity: Notice --> Undefined variable: result_ruas_by_departemnt C:\laragon\www\jmto-eproc\application\views\administrator\sirup_rup\form_rup_edit.php 136
ERROR - 2024-04-30 13:27:24 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\jmto-eproc\application\views\administrator\sirup_rup\form_rup_edit.php 136
ERROR - 2024-04-30 13:34:44 --> Severity: Notice --> Undefined variable: result_ruas_by_departemnt C:\laragon\www\jmto-eproc\application\views\administrator\sirup_rup\form_rup_edit.php 136
ERROR - 2024-04-30 13:34:44 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\jmto-eproc\application\views\administrator\sirup_rup\form_rup_edit.php 136
ERROR - 2024-04-30 13:34:50 --> Severity: Notice --> Undefined variable: result_ruas_by_departemnt C:\laragon\www\jmto-eproc\application\views\administrator\sirup_rup\form_rup_edit.php 136
ERROR - 2024-04-30 13:34:50 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\jmto-eproc\application\views\administrator\sirup_rup\form_rup_edit.php 136
