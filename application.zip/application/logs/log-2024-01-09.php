<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2024-01-09 14:31:28 --> Severity: error --> Exception: Too few arguments to function Daftar_paket::by_id_rup(), 0 passed in C:\xampp\htdocs\jmto-eproc-fix\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\xampp\htdocs\jmto-eproc-fix\application\controllers\panitia\daftar_paket\Daftar_paket.php 388
ERROR - 2024-01-09 15:03:30 --> Query error: Unknown column 'tbl_panitia.role' in 'where clause' - Invalid query: SELECT *
FROM `tbl_panitia`
LEFT JOIN `tbl_manajemen_user` ON `tbl_panitia`.`id_manajemen_user` = `tbl_manajemen_user`.`id_manajemen_user`
LEFT JOIN `tbl_pegawai` ON `tbl_manajemen_user`.`id_pegawai` = `tbl_pegawai`.`id_pegawai`
WHERE `id_rup` = '205'
AND `tbl_panitia`.`role` = 5
ERROR - 2024-01-09 15:03:57 --> Query error: Unknown column 'tbl_panitia.role' in 'where clause' - Invalid query: SELECT *
FROM `tbl_panitia`
LEFT JOIN `tbl_manajemen_user` ON `tbl_panitia`.`id_manajemen_user` = `tbl_manajemen_user`.`id_manajemen_user`
LEFT JOIN `tbl_pegawai` ON `tbl_manajemen_user`.`id_pegawai` = `tbl_pegawai`.`id_pegawai`
WHERE `id_rup` = '205'
AND `tbl_panitia`.`role` = 5
ERROR - 2024-01-09 15:04:07 --> Query error: Unknown column 'tbl_panitia.role' in 'where clause' - Invalid query: SELECT *
FROM `tbl_panitia`
LEFT JOIN `tbl_manajemen_user` ON `tbl_panitia`.`id_manajemen_user` = `tbl_manajemen_user`.`id_manajemen_user`
LEFT JOIN `tbl_pegawai` ON `tbl_manajemen_user`.`id_pegawai` = `tbl_pegawai`.`id_pegawai`
WHERE `id_rup` = '205'
AND `tbl_panitia`.`role` = 5
ERROR - 2024-01-09 17:52:00 --> Query error: Unknown column 'INF' in 'field list' - Invalid query: UPDATE `tbl_vendor_mengikuti_paket` SET `nilai_penawaran` = '0', `ev_penawaran_teknis` = '51', `ev_penawaran_hps` = '0', `ev_penawaran_biaya` = INF
WHERE `id_vendor_mengikuti_paket` = '83'
ERROR - 2024-01-09 17:52:35 --> Query error: Unknown column 'INF' in 'field list' - Invalid query: UPDATE `tbl_vendor_mengikuti_paket` SET `nilai_penawaran` = '0', `ev_penawaran_teknis` = '51', `ev_penawaran_hps` = '0', `ev_penawaran_biaya` = INF
WHERE `id_vendor_mengikuti_paket` = '83'
ERROR - 2024-01-09 18:03:01 --> Query error: Unknown column 'NAN' in 'field list' - Invalid query: UPDATE `tbl_vendor_mengikuti_paket` SET `nilai_penawaran` = '0', `ev_penawaran_teknis` = '55', `ev_penawaran_hps` = '0', `ev_penawaran_biaya` = NAN
WHERE `id_vendor_mengikuti_paket` = '84'
ERROR - 2024-01-09 18:30:50 --> Query error: MySQL server has gone away - Invalid query: SELECT *
FROM `tbl_rup`
WHERE `tbl_rup`.`id_rup` = '205'
ERROR - 2024-01-09 18:30:50 --> Query error: MySQL server has gone away - Invalid query: SELECT *
FROM `tbl_vendor_mengikuti_paket`
LEFT JOIN `tbl_vendor` ON `tbl_vendor_mengikuti_paket`.`id_vendor` = `tbl_vendor`.`id_vendor`
WHERE `tbl_vendor_mengikuti_paket`.`id_vendor_mengikuti_paket` = '83'
ERROR - 2024-01-09 18:30:50 --> Query error: MySQL server has gone away - Invalid query: SELECT *
FROM `tbl_rup`
WHERE `tbl_rup`.`id_rup` = '205'
ERROR - 2024-01-09 18:32:18 --> Query error: MySQL server has gone away - Invalid query: SELECT *
FROM `tbl_rup`
LEFT JOIN `tbl_departemen` ON `tbl_rup`.`id_departemen` = `tbl_departemen`.`id_departemen`
LEFT JOIN `tbl_jadwal_tender` ON `tbl_rup`.`id_jadwal_tender` = `tbl_jadwal_tender`.`id_jadwal_tender`
LEFT JOIN `tbl_section` ON `tbl_rup`.`id_section` = `tbl_section`.`id_section`
LEFT JOIN `tbl_rkap` ON `tbl_rup`.`id_rkap` = `tbl_rkap`.`id_rkap`
LEFT JOIN `tbl_provinsi` ON `tbl_rup`.`id_provinsi` = `tbl_provinsi`.`id_provinsi`
LEFT JOIN `tbl_kabupaten` ON `tbl_rup`.`id_kabupaten` = `tbl_kabupaten`.`id_kabupaten`
LEFT JOIN `tbl_jenis_pengadaan` ON `tbl_rup`.`id_jenis_pengadaan` = `tbl_jenis_pengadaan`.`id_jenis_pengadaan`
LEFT JOIN `tbl_metode_pengadaan` ON `tbl_rup`.`id_metode_pengadaan` = `tbl_metode_pengadaan`.`id_metode_pengadaan`
LEFT JOIN `tbl_jenis_anggaran` ON `tbl_rup`.`id_jenis_anggaran` = `tbl_jenis_anggaran`.`id_jenis_anggaran`
LEFT JOIN `mst_ruas` ON `tbl_rup`.`id_ruas` = `mst_ruas`.`id_ruas`
WHERE `id_url_rup` = '7d2aec7ff9a940e8be2eaeefabac54bf'
ERROR - 2024-01-09 18:32:18 --> Query error: MySQL server has gone away - Invalid query: SELECT *
FROM `tbl_vendor_mengikuti_paket`
LEFT JOIN `tbl_rup` ON `tbl_vendor_mengikuti_paket`.`id_rup` = `tbl_rup`.`id_rup`
LEFT JOIN `tbl_vendor` ON `tbl_vendor_mengikuti_paket`.`id_vendor` = `tbl_vendor`.`id_vendor`
WHERE `tbl_vendor_mengikuti_paket`.`id_rup` = '205'
AND `tbl_vendor_mengikuti_paket`.`ev_kualifikasi_akhir` > 60
ORDER BY `tbl_rup`.`id_rup` DESC
 LIMIT 10
ERROR - 2024-01-09 18:32:18 --> Query error: MySQL server has gone away - Invalid query: SELECT *
FROM `tbl_vendor_mengikuti_paket`
LEFT JOIN `tbl_rup` ON `tbl_vendor_mengikuti_paket`.`id_rup` = `tbl_rup`.`id_rup`
LEFT JOIN `tbl_vendor` ON `tbl_vendor_mengikuti_paket`.`id_vendor` = `tbl_vendor`.`id_vendor`
WHERE `tbl_vendor_mengikuti_paket`.`id_rup` = '205'
AND `tbl_vendor_mengikuti_paket`.`ev_kualifikasi_akhir` > 60
ORDER BY `tbl_rup`.`id_rup` DESC
 LIMIT 10
ERROR - 2024-01-09 18:32:39 --> Query error: MySQL server has gone away - Invalid query: SELECT *
FROM `tbl_vendor_mengikuti_paket`
LEFT JOIN `tbl_rup` ON `tbl_vendor_mengikuti_paket`.`id_rup` = `tbl_rup`.`id_rup`
LEFT JOIN `tbl_vendor` ON `tbl_vendor_mengikuti_paket`.`id_vendor` = `tbl_vendor`.`id_vendor`
WHERE `tbl_vendor_mengikuti_paket`.`id_rup` = '205'
AND `tbl_vendor_mengikuti_paket`.`ev_kualifikasi_akhir` > 60
ORDER BY `tbl_rup`.`id_rup` DESC
 LIMIT 10
ERROR - 2024-01-09 18:32:40 --> Query error: MySQL server has gone away - Invalid query: SELECT *
FROM `tbl_rup`
WHERE `tbl_rup`.`id_rup` = '205'
ERROR - 2024-01-09 18:32:40 --> Query error: MySQL server has gone away - Invalid query: SELECT *
FROM `tbl_vendor_mengikuti_paket`
LEFT JOIN `tbl_vendor` ON `tbl_vendor_mengikuti_paket`.`id_vendor` = `tbl_vendor`.`id_vendor`
WHERE `tbl_vendor_mengikuti_paket`.`id_vendor_mengikuti_paket` = '83'
ERROR - 2024-01-09 18:32:40 --> Query error: MySQL server has gone away - Invalid query: SELECT *
FROM `tbl_rup`
WHERE `tbl_rup`.`id_rup` = '205'
ERROR - 2024-01-09 18:33:12 --> Query error: Unknown column 'NAN' in 'field list' - Invalid query: UPDATE `tbl_vendor_mengikuti_paket` SET `nilai_penawaran` = '0', `ev_penawaran_teknis` = '51', `ev_penawaran_hps` = '0', `ev_penawaran_biaya` = NAN
WHERE `id_vendor_mengikuti_paket` = '83'
ERROR - 2024-01-09 18:34:00 --> Query error: MySQL server has gone away - Invalid query: SELECT *
FROM `tbl_vendor_mengikuti_paket`
LEFT JOIN `tbl_rup` ON `tbl_vendor_mengikuti_paket`.`id_rup` = `tbl_rup`.`id_rup`
LEFT JOIN `tbl_vendor` ON `tbl_vendor_mengikuti_paket`.`id_vendor` = `tbl_vendor`.`id_vendor`
WHERE `tbl_vendor_mengikuti_paket`.`id_rup` = '205'
AND `tbl_vendor_mengikuti_paket`.`ev_kualifikasi_akhir` > 60
ORDER BY `tbl_rup`.`id_rup` DESC
 LIMIT 10
ERROR - 2024-01-09 18:34:00 --> Query error: MySQL server has gone away - Invalid query: SELECT *
FROM `tbl_rup`
WHERE `tbl_rup`.`id_rup` = '205'
ERROR - 2024-01-09 18:34:00 --> Query error: MySQL server has gone away - Invalid query: SELECT *
FROM `tbl_vendor_mengikuti_paket`
LEFT JOIN `tbl_rup` ON `tbl_vendor_mengikuti_paket`.`id_rup` = `tbl_rup`.`id_rup`
LEFT JOIN `tbl_vendor` ON `tbl_vendor_mengikuti_paket`.`id_vendor` = `tbl_vendor`.`id_vendor`
WHERE `tbl_vendor_mengikuti_paket`.`id_rup` = '205'
AND `tbl_vendor_mengikuti_paket`.`ev_kualifikasi_akhir` > 60
ORDER BY `tbl_rup`.`id_rup` DESC
 LIMIT 10
ERROR - 2024-01-09 18:34:08 --> Query error: Unknown column 'NAN' in 'field list' - Invalid query: UPDATE `tbl_vendor_mengikuti_paket` SET `nilai_penawaran` = '0', `ev_penawaran_teknis` = '51', `ev_penawaran_hps` = '0', `ev_penawaran_biaya` = NAN
WHERE `id_vendor_mengikuti_paket` = '83'
ERROR - 2024-01-09 18:36:27 --> Query error: MySQL server has gone away - Invalid query: SELECT *
FROM `tbl_vendor_mengikuti_paket`
LEFT JOIN `tbl_rup` ON `tbl_vendor_mengikuti_paket`.`id_rup` = `tbl_rup`.`id_rup`
LEFT JOIN `tbl_vendor` ON `tbl_vendor_mengikuti_paket`.`id_vendor` = `tbl_vendor`.`id_vendor`
WHERE `tbl_vendor_mengikuti_paket`.`id_rup` = '205'
AND `tbl_vendor_mengikuti_paket`.`ev_kualifikasi_akhir` > 60
ORDER BY `tbl_rup`.`id_rup` DESC
 LIMIT 10
ERROR - 2024-01-09 18:36:32 --> Query error: MySQL server has gone away - Invalid query: SELECT *
FROM `tbl_ba_tender`
WHERE `tbl_ba_tender`.`id_rup` = '205'
ERROR - 2024-01-09 18:36:32 --> Query error: MySQL server has gone away - Invalid query: SELECT *
FROM `tbl_ba_teknis_detail`
WHERE `id_rup` = '205'
ERROR - 2024-01-09 18:36:33 --> Query error: MySQL server has gone away - Invalid query: SELECT *
FROM `tbl_rup`
LEFT JOIN `tbl_departemen` ON `tbl_rup`.`id_departemen` = `tbl_departemen`.`id_departemen`
LEFT JOIN `tbl_jadwal_tender` ON `tbl_rup`.`id_jadwal_tender` = `tbl_jadwal_tender`.`id_jadwal_tender`
LEFT JOIN `tbl_section` ON `tbl_rup`.`id_section` = `tbl_section`.`id_section`
LEFT JOIN `tbl_rkap` ON `tbl_rup`.`id_rkap` = `tbl_rkap`.`id_rkap`
LEFT JOIN `tbl_provinsi` ON `tbl_rup`.`id_provinsi` = `tbl_provinsi`.`id_provinsi`
LEFT JOIN `tbl_kabupaten` ON `tbl_rup`.`id_kabupaten` = `tbl_kabupaten`.`id_kabupaten`
LEFT JOIN `tbl_jenis_pengadaan` ON `tbl_rup`.`id_jenis_pengadaan` = `tbl_jenis_pengadaan`.`id_jenis_pengadaan`
LEFT JOIN `tbl_metode_pengadaan` ON `tbl_rup`.`id_metode_pengadaan` = `tbl_metode_pengadaan`.`id_metode_pengadaan`
LEFT JOIN `tbl_jenis_anggaran` ON `tbl_rup`.`id_jenis_anggaran` = `tbl_jenis_anggaran`.`id_jenis_anggaran`
LEFT JOIN `mst_ruas` ON `tbl_rup`.`id_ruas` = `mst_ruas`.`id_ruas`
WHERE `id_url_rup` = '7d2aec7ff9a940e8be2eaeefabac54bf'
ERROR - 2024-01-09 18:39:45 --> Query error: MySQL server has gone away - Invalid query: SELECT *
FROM `tbl_vendor_mengikuti_paket`
LEFT JOIN `tbl_rup` ON `tbl_vendor_mengikuti_paket`.`id_rup` = `tbl_rup`.`id_rup`
LEFT JOIN `tbl_vendor` ON `tbl_vendor_mengikuti_paket`.`id_vendor` = `tbl_vendor`.`id_vendor`
WHERE `tbl_vendor_mengikuti_paket`.`id_rup` = '205'
AND `tbl_vendor_mengikuti_paket`.`ev_kualifikasi_akhir` > 60
ORDER BY `tbl_rup`.`id_rup` DESC
ERROR - 2024-01-09 18:39:45 --> Query error: MySQL server has gone away - Invalid query: SELECT *
FROM `tbl_vendor_mengikuti_paket`
LEFT JOIN `tbl_rup` ON `tbl_vendor_mengikuti_paket`.`id_rup` = `tbl_rup`.`id_rup`
LEFT JOIN `tbl_vendor` ON `tbl_vendor_mengikuti_paket`.`id_vendor` = `tbl_vendor`.`id_vendor`
WHERE `tbl_vendor_mengikuti_paket`.`id_rup` = '205'
AND `tbl_vendor_mengikuti_paket`.`ev_kualifikasi_akhir` > 60
ORDER BY `tbl_rup`.`id_rup` DESC
 LIMIT 10
ERROR - 2024-01-09 18:39:45 --> Query error: MySQL server has gone away - Invalid query: SELECT *
FROM `tbl_rup`
WHERE `tbl_rup`.`id_rup` = '205'
ERROR - 2024-01-09 18:39:45 --> Query error: MySQL server has gone away - Invalid query: SELECT *
FROM `tbl_vendor_mengikuti_paket`
LEFT JOIN `tbl_rup` ON `tbl_vendor_mengikuti_paket`.`id_rup` = `tbl_rup`.`id_rup`
LEFT JOIN `tbl_vendor` ON `tbl_vendor_mengikuti_paket`.`id_vendor` = `tbl_vendor`.`id_vendor`
WHERE `tbl_vendor_mengikuti_paket`.`id_rup` = '205'
AND `tbl_vendor_mengikuti_paket`.`ev_kualifikasi_akhir` > 60
ORDER BY `tbl_rup`.`id_rup` DESC
 LIMIT 10
ERROR - 2024-01-09 18:39:45 --> Query error: MySQL server has gone away - Invalid query: SELECT *
FROM `tbl_rup`
WHERE `tbl_rup`.`id_rup` = '205'
ERROR - 2024-01-09 18:39:45 --> Query error: MySQL server has gone away - Invalid query: SELECT *
FROM `tbl_vendor_mengikuti_paket`
LEFT JOIN `tbl_vendor` ON `tbl_vendor_mengikuti_paket`.`id_vendor` = `tbl_vendor`.`id_vendor`
WHERE `tbl_vendor_mengikuti_paket`.`id_vendor_mengikuti_paket` = '84'
ERROR - 2024-01-09 19:14:46 --> Query error: MySQL server has gone away - Invalid query: SELECT *
FROM `tbl_vendor_mengikuti_paket`
LEFT JOIN `tbl_rup` ON `tbl_vendor_mengikuti_paket`.`id_rup` = `tbl_rup`.`id_rup`
LEFT JOIN `tbl_vendor` ON `tbl_vendor_mengikuti_paket`.`id_vendor` = `tbl_vendor`.`id_vendor`
WHERE `tbl_vendor_mengikuti_paket`.`id_rup` = '205'
AND `tbl_vendor_mengikuti_paket`.`ev_kualifikasi_akhir` > 60
ORDER BY `tbl_rup`.`id_rup` DESC
ERROR - 2024-01-09 19:14:46 --> Query error: MySQL server has gone away - Invalid query: SELECT *
FROM `tbl_rup`
WHERE `tbl_rup`.`id_rup` = '205'
