<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2024-01-09 14:13:27 --> Severity: Notice --> Trying to get property 'nip' of non-object C:\laragon\www\jmto-eproc\application\libraries\Role_login.php 21
ERROR - 2024-01-09 14:13:32 --> Severity: Notice --> Trying to get property 'nip' of non-object C:\laragon\www\jmto-eproc\application\libraries\Role_login.php 21
ERROR - 2024-01-09 14:18:48 --> Severity: error --> Exception: Too few arguments to function Daftar_paket::by_id_rup(), 0 passed in C:\laragon\www\jmto-eproc\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 388
ERROR - 2024-01-09 14:35:37 --> Query error: Unknown column 'Array' in 'where clause' - Invalid query: UPDATE `tbl_rup` SET `id_rup` = '206'
WHERE `id_rup` = Array
ERROR - 2024-01-09 14:35:49 --> Query error: Unknown column 'Array' in 'where clause' - Invalid query: UPDATE `tbl_rup` SET `id_rup` = '206'
WHERE `id_rup` = Array
ERROR - 2024-01-09 14:35:52 --> Query error: Unknown column 'Array' in 'where clause' - Invalid query: UPDATE `tbl_rup` SET `id_rup` = NULL
WHERE `id_rup` = Array
ERROR - 2024-01-09 14:36:35 --> Query error: Unknown column 'Array' in 'where clause' - Invalid query: UPDATE `tbl_rup` SET `id_rup` = '206'
WHERE `id_rup` = Array
ERROR - 2024-01-09 14:37:30 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '= 1
WHERE `id_rup` IS NULL' at line 1 - Invalid query: UPDATE `tbl_rup` SET  = 1
WHERE `id_rup` IS NULL
ERROR - 2024-01-09 14:37:33 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '= 1
WHERE `id_rup` IS NULL' at line 1 - Invalid query: UPDATE `tbl_rup` SET  = 1
WHERE `id_rup` IS NULL
ERROR - 2024-01-09 14:37:41 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '= 1
WHERE `id_rup` IS NULL' at line 1 - Invalid query: UPDATE `tbl_rup` SET  = 1
WHERE `id_rup` IS NULL
ERROR - 2024-01-09 15:06:10 --> Query error: Unknown column 'sts_kirim_ba_rapat' in 'field list' - Invalid query: UPDATE `tbl_rup` SET `sts_kirim_ba_rapat` = 1
WHERE `id_rup` = '206'
ERROR - 2024-01-09 15:06:15 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '= 1
WHERE `id_rup` IS NULL' at line 1 - Invalid query: UPDATE `tbl_rup` SET  = 1
WHERE `id_rup` IS NULL
ERROR - 2024-01-09 15:08:37 --> Query error: Unknown column 'sts_kirim_ba_rapat' in 'field list' - Invalid query: UPDATE `tbl_rup` SET `sts_kirim_ba_rapat` = 1
WHERE `id_rup` = '206'
ERROR - 2024-01-09 15:08:48 --> Query error: Unknown column 'sts_kirim_ba_rapat' in 'field list' - Invalid query: UPDATE `tbl_rup` SET `sts_kirim_ba_rapat` = 1
WHERE `id_rup` = '206'
ERROR - 2024-01-09 15:09:14 --> Query error: Unknown column 'sts_kirim_ba_rapat' in 'field list' - Invalid query: UPDATE `tbl_rup` SET `sts_kirim_ba_rapat` = 1
WHERE `id_rup` = '206'
ERROR - 2024-01-09 15:12:55 --> Query error: Unknown column 'sts_kirim_ba_negosiasi' in 'field list' - Invalid query: UPDATE `tbl_rup` SET `sts_kirim_ba_negosiasi` = 1
WHERE `id_rup` = '206'
