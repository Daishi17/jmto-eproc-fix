<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2024-01-09 14:13:27 --> Severity: Notice --> Trying to get property 'nip' of non-object C:\laragon\www\jmto-eproc\application\libraries\Role_login.php 21
ERROR - 2024-01-09 14:13:32 --> Severity: Notice --> Trying to get property 'nip' of non-object C:\laragon\www\jmto-eproc\application\libraries\Role_login.php 21
ERROR - 2024-01-09 14:18:48 --> Severity: error --> Exception: Too few arguments to function Daftar_paket::by_id_rup(), 0 passed in C:\laragon\www\jmto-eproc\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 388
ERROR - 2024-01-09 14:35:37 --> Query error: Unknown column 'Array' in 'where clause' - Invalid query: UPDATE `tbl_rup` SET `id_rup` = '206'
WHERE `id_rup` = Array
ERROR - 2024-01-09 14:35:49 --> Query error: Unknown column 'Array' in 'where clause' - Invalid query: UPDATE `tbl_rup` SET `id_rup` = '206'
WHERE `id_rup` = Array
ERROR - 2024-01-09 14:35:52 --> Query error: Unknown column 'Array' in 'where clause' - Invalid query: UPDATE `tbl_rup` SET `id_rup` = NULL
WHERE `id_rup` = Array
ERROR - 2024-01-09 14:36:35 --> Query error: Unknown column 'Array' in 'where clause' - Invalid query: UPDATE `tbl_rup` SET `id_rup` = '206'
WHERE `id_rup` = Array
ERROR - 2024-01-09 14:37:30 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '= 1
WHERE `id_rup` IS NULL' at line 1 - Invalid query: UPDATE `tbl_rup` SET  = 1
WHERE `id_rup` IS NULL
ERROR - 2024-01-09 14:37:33 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '= 1
WHERE `id_rup` IS NULL' at line 1 - Invalid query: UPDATE `tbl_rup` SET  = 1
WHERE `id_rup` IS NULL
ERROR - 2024-01-09 14:37:41 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '= 1
WHERE `id_rup` IS NULL' at line 1 - Invalid query: UPDATE `tbl_rup` SET  = 1
WHERE `id_rup` IS NULL
ERROR - 2024-01-09 15:06:10 --> Query error: Unknown column 'sts_kirim_ba_rapat' in 'field list' - Invalid query: UPDATE `tbl_rup` SET `sts_kirim_ba_rapat` = 1
WHERE `id_rup` = '206'
ERROR - 2024-01-09 15:06:15 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '= 1
WHERE `id_rup` IS NULL' at line 1 - Invalid query: UPDATE `tbl_rup` SET  = 1
WHERE `id_rup` IS NULL
ERROR - 2024-01-09 15:08:37 --> Query error: Unknown column 'sts_kirim_ba_rapat' in 'field list' - Invalid query: UPDATE `tbl_rup` SET `sts_kirim_ba_rapat` = 1
WHERE `id_rup` = '206'
ERROR - 2024-01-09 15:08:48 --> Query error: Unknown column 'sts_kirim_ba_rapat' in 'field list' - Invalid query: UPDATE `tbl_rup` SET `sts_kirim_ba_rapat` = 1
WHERE `id_rup` = '206'
ERROR - 2024-01-09 15:09:14 --> Query error: Unknown column 'sts_kirim_ba_rapat' in 'field list' - Invalid query: UPDATE `tbl_rup` SET `sts_kirim_ba_rapat` = 1
WHERE `id_rup` = '206'
ERROR - 2024-01-09 15:12:55 --> Query error: Unknown column 'sts_kirim_ba_negosiasi' in 'field list' - Invalid query: UPDATE `tbl_rup` SET `sts_kirim_ba_negosiasi` = 1
WHERE `id_rup` = '206'
ERROR - 2024-01-09 17:01:59 --> Query error: Unknown column 'INF' in 'field list' - Invalid query: UPDATE `tbl_vendor_mengikuti_paket` SET `nilai_penawaran` = NULL, `ev_penawaran_teknis` = '55', `ev_penawaran_hps` = '0', `ev_penawaran_biaya` = INF
WHERE `id_vendor_mengikuti_paket` = '81'
ERROR - 2024-01-09 17:02:04 --> Query error: Unknown column 'NAN' in 'field list' - Invalid query: UPDATE `tbl_vendor_mengikuti_paket` SET `nilai_penawaran` = NULL, `ev_penawaran_teknis` = NULL, `ev_penawaran_hps` = NAN, `ev_penawaran_biaya` = NAN
WHERE `id_vendor_mengikuti_paket` IS NULL
ERROR - 2024-01-09 17:02:16 --> Query error: Unknown column 'INF' in 'field list' - Invalid query: UPDATE `tbl_vendor_mengikuti_paket` SET `nilai_penawaran` = NULL, `ev_penawaran_teknis` = '55', `ev_penawaran_hps` = '0', `ev_penawaran_biaya` = INF
WHERE `id_vendor_mengikuti_paket` = '81'
ERROR - 2024-01-09 17:03:02 --> Query error: Unknown column 'NAN' in 'field list' - Invalid query: UPDATE `tbl_vendor_mengikuti_paket` SET `nilai_penawaran` = '0', `ev_penawaran_teknis` = '55', `ev_penawaran_hps` = '0', `ev_penawaran_biaya` = NAN
WHERE `id_vendor_mengikuti_paket` = '81'
ERROR - 2024-01-09 17:04:01 --> Query error: Unknown column 'INF' in 'field list' - Invalid query: UPDATE `tbl_vendor_mengikuti_paket` SET `nilai_penawaran` = NULL, `ev_penawaran_teknis` = NULL, `ev_penawaran_hps` = NULL, `ev_penawaran_biaya` = INF
WHERE `id_vendor_mengikuti_paket` = '82'
ERROR - 2024-01-09 17:06:56 --> Query error: Unknown column 'INF' in 'field list' - Invalid query: UPDATE `tbl_vendor_mengikuti_paket` SET `nilai_penawaran` = NULL, `ev_penawaran_teknis` = NULL, `ev_penawaran_hps` = NULL, `ev_penawaran_biaya` = INF
WHERE `id_vendor_mengikuti_paket` = '82'
ERROR - 2024-01-09 17:07:01 --> Query error: Unknown column 'NAN' in 'field list' - Invalid query: UPDATE `tbl_vendor_mengikuti_paket` SET `nilai_penawaran` = NULL, `ev_penawaran_teknis` = NULL, `ev_penawaran_hps` = NAN, `ev_penawaran_biaya` = NAN
WHERE `id_vendor_mengikuti_paket` IS NULL
ERROR - 2024-01-09 17:10:45 --> Query error: Unknown column 'NAN' in 'field list' - Invalid query: UPDATE `tbl_vendor_mengikuti_paket` SET `nilai_penawaran` = '0', `ev_penawaran_teknis` = '51', `ev_penawaran_hps` = '0', `ev_penawaran_biaya` = NAN
WHERE `id_vendor_mengikuti_paket` = '81'
ERROR - 2024-01-09 17:18:02 --> Query error: Unknown column 'tbl_rup.nama_program_rup' in 'order clause' - Invalid query: SELECT *
FROM `tbl_vendor_mengikuti_paket`
LEFT JOIN `tbl_rup` ON `tbl_vendor_mengikuti_paket`.`id_rup` = `tbl_rup`.`id_rup`
LEFT JOIN `tbl_vendor` ON `tbl_vendor_mengikuti_paket`.`id_vendor` = `tbl_vendor`.`id_vendor`
WHERE `tbl_vendor_mengikuti_paket`.`id_rup` = '205'
AND `tbl_vendor_mengikuti_paket`.`ev_keuangan` > 60
AND `tbl_vendor_mengikuti_paket`.`ev_teknis` > 60
ORDER BY `tbl_rup`.`nama_program_rup` ASC
 LIMIT 10
ERROR - 2024-01-09 17:18:23 --> Query error: Unknown column 'NAN' in 'field list' - Invalid query: UPDATE `tbl_vendor_mengikuti_paket` SET `nilai_penawaran` = '0', `ev_penawaran_teknis` = '55', `ev_penawaran_hps` = '0', `ev_penawaran_biaya` = NAN
WHERE `id_vendor_mengikuti_paket` = '84'
ERROR - 2024-01-09 17:18:27 --> Query error: Unknown column 'NAN' in 'field list' - Invalid query: UPDATE `tbl_vendor_mengikuti_paket` SET `nilai_penawaran` = NULL, `ev_penawaran_teknis` = NULL, `ev_penawaran_hps` = NAN, `ev_penawaran_biaya` = NAN
WHERE `id_vendor_mengikuti_paket` IS NULL
ERROR - 2024-01-09 17:30:54 --> Query error: Unknown column 'NAN' in 'field list' - Invalid query: UPDATE `tbl_vendor_mengikuti_paket` SET `nilai_penawaran` = NULL, `ev_penawaran_teknis` = NULL, `ev_penawaran_hps` = NAN, `ev_penawaran_biaya` = NAN
WHERE `id_vendor_mengikuti_paket` IS NULL
ERROR - 2024-01-09 17:32:54 --> Query error: Unknown column 'INF' in 'field list' - Invalid query: UPDATE `tbl_vendor_mengikuti_paket` SET `nilai_penawaran` = NULL, `ev_penawaran_teknis` = NULL, `ev_penawaran_hps` = NULL, `ev_penawaran_biaya` = INF
WHERE `id_vendor_mengikuti_paket` = '82'
ERROR - 2024-01-09 17:36:10 --> Query error: Unknown column 'NAN' in 'field list' - Invalid query: UPDATE `tbl_vendor_mengikuti_paket` SET `nilai_penawaran` = '0', `ev_penawaran_teknis` = '51', `ev_penawaran_hps` = '0', `ev_penawaran_biaya` = NAN
WHERE `id_vendor_mengikuti_paket` = '83'
ERROR - 2024-01-09 17:46:31 --> Query error: Unknown column 'INF' in 'field list' - Invalid query: UPDATE `tbl_vendor_mengikuti_paket` SET `nilai_penawaran` = '0', `ev_penawaran_teknis` = '51', `ev_penawaran_hps` = '0', `ev_penawaran_biaya` = INF
WHERE `id_vendor_mengikuti_paket` = '83'
ERROR - 2024-01-09 17:46:52 --> Query error: Unknown column 'INF' in 'field list' - Invalid query: UPDATE `tbl_vendor_mengikuti_paket` SET `nilai_penawaran` = '0', `ev_penawaran_teknis` = '51', `ev_penawaran_hps` = '0', `ev_penawaran_biaya` = INF
WHERE `id_vendor_mengikuti_paket` = '83'
ERROR - 2024-01-09 18:46:49 --> Unable to connect to the database
ERROR - 2024-01-09 18:47:00 --> Unable to connect to the database
ERROR - 2024-01-09 18:47:00 --> Unable to connect to the database
ERROR - 2024-01-09 18:47:00 --> Unable to connect to the database
ERROR - 2024-01-09 18:47:00 --> Unable to connect to the database
ERROR - 2024-01-09 18:47:00 --> Unable to connect to the database
ERROR - 2024-01-09 18:47:00 --> Unable to connect to the database
