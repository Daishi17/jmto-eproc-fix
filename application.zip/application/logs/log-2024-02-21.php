<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2024-02-21 04:25:52 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): A connection attempt failed because the connected party did not properly respond after a period of time, or established connection failed because connected host has failed to respond.
 C:\laragon\www\jmto-eproc\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2024-02-21 04:25:52 --> Unable to connect to the database
ERROR - 2024-02-21 04:26:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): A connection attempt failed because the connected party did not properly respond after a period of time, or established connection failed because connected host has failed to respond.
 C:\laragon\www\jmto-eproc\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2024-02-21 04:26:02 --> Unable to connect to the database
ERROR - 2024-02-21 04:26:30 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): A connection attempt failed because the connected party did not properly respond after a period of time, or established connection failed because connected host has failed to respond.
 C:\laragon\www\jmto-eproc\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2024-02-21 04:26:30 --> Unable to connect to the database
ERROR - 2024-02-21 11:26:57 --> Severity: error --> Exception: Too few arguments to function Daftar_paket::by_id_rup(), 0 passed in C:\laragon\www\jmto-eproc\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 393
ERROR - 2024-02-21 11:36:08 --> Severity: error --> Exception: Too few arguments to function Daftar_paket::by_id_rup(), 0 passed in C:\laragon\www\jmto-eproc\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 393
ERROR - 2024-02-21 11:37:44 --> Severity: error --> Exception: Too few arguments to function Daftar_paket::by_id_rup(), 0 passed in C:\laragon\www\jmto-eproc\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 393
ERROR - 2024-02-21 11:38:41 --> Severity: error --> Exception: Too few arguments to function Daftar_paket::by_id_rup(), 0 passed in C:\laragon\www\jmto-eproc\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 393
ERROR - 2024-02-21 17:32:49 --> Severity: error --> Exception: Call to a member function gettable_pengalaman_manajerial() on null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_terbatas_pra_1_file.php 3087
ERROR - 2024-02-21 17:33:44 --> Severity: error --> Exception: Call to a member function gettable_pengalaman_manajerial() on null C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_terbatas_pra_1_file.php 3087
ERROR - 2024-02-21 17:40:19 --> Severity: Notice --> Undefined index: ba_evaluasi_jam C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 964
ERROR - 2024-02-21 17:40:19 --> Severity: Notice --> Undefined variable: peserta_tender_pq_penawaran C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1333
ERROR - 2024-02-21 17:40:19 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1333
ERROR - 2024-02-21 17:40:20 --> Severity: Notice --> Undefined index: ba_evaluasi_jam C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 964
ERROR - 2024-02-21 17:40:20 --> Severity: Notice --> Undefined variable: peserta_tender_pq_penawaran C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1333
ERROR - 2024-02-21 17:40:20 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1333
ERROR - 2024-02-21 17:40:21 --> Severity: Notice --> Undefined index: ba_evaluasi_jam C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 964
ERROR - 2024-02-21 17:40:21 --> Severity: Notice --> Undefined variable: peserta_tender_pq_penawaran C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1333
ERROR - 2024-02-21 17:40:21 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1333
ERROR - 2024-02-21 17:40:22 --> Severity: Notice --> Undefined index: ba_evaluasi_jam C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 964
ERROR - 2024-02-21 17:40:22 --> Severity: Notice --> Undefined variable: peserta_tender_pq_penawaran C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1333
ERROR - 2024-02-21 17:40:22 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1333
ERROR - 2024-02-21 17:40:25 --> Severity: Notice --> Undefined index: ba_evaluasi_jam C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 964
ERROR - 2024-02-21 17:40:25 --> Severity: Notice --> Undefined variable: peserta_tender_pq_penawaran C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1333
ERROR - 2024-02-21 17:40:25 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1333
ERROR - 2024-02-21 17:40:26 --> Severity: Notice --> Undefined index: ba_evaluasi_jam C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 964
ERROR - 2024-02-21 17:40:26 --> Severity: Notice --> Undefined variable: peserta_tender_pq_penawaran C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1333
ERROR - 2024-02-21 17:40:26 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1333
ERROR - 2024-02-21 17:40:27 --> Severity: Notice --> Undefined index: ba_evaluasi_jam C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 964
ERROR - 2024-02-21 17:40:27 --> Severity: Notice --> Undefined variable: peserta_tender_pq_penawaran C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1333
ERROR - 2024-02-21 17:40:27 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1333
ERROR - 2024-02-21 17:40:28 --> Severity: Notice --> Undefined index: ba_evaluasi_jam C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 964
ERROR - 2024-02-21 17:40:28 --> Severity: Notice --> Undefined variable: peserta_tender_pq_penawaran C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1333
ERROR - 2024-02-21 17:40:28 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1333
ERROR - 2024-02-21 18:05:17 --> Severity: Notice --> Undefined index: ba_evaluasi_jam C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 964
ERROR - 2024-02-21 18:05:17 --> Severity: Notice --> Undefined variable: peserta_tender_pq_penawaran C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1333
ERROR - 2024-02-21 18:05:17 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1333
ERROR - 2024-02-21 18:05:17 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1556
ERROR - 2024-02-21 18:05:17 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1566
ERROR - 2024-02-21 18:05:19 --> Severity: Notice --> Undefined index: ba_evaluasi_jam C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 964
ERROR - 2024-02-21 18:05:19 --> Severity: Notice --> Undefined variable: peserta_tender_pq_penawaran C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1333
ERROR - 2024-02-21 18:05:19 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1333
ERROR - 2024-02-21 18:05:19 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1556
ERROR - 2024-02-21 18:05:19 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1566
ERROR - 2024-02-21 18:05:20 --> Severity: Notice --> Undefined index: ba_evaluasi_jam C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 964
ERROR - 2024-02-21 18:05:20 --> Severity: Notice --> Undefined variable: peserta_tender_pq_penawaran C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1333
ERROR - 2024-02-21 18:05:20 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1333
ERROR - 2024-02-21 18:05:20 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1556
ERROR - 2024-02-21 18:05:20 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1566
ERROR - 2024-02-21 18:05:21 --> Severity: Notice --> Undefined index: ba_evaluasi_jam C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 964
ERROR - 2024-02-21 18:05:21 --> Severity: Notice --> Undefined variable: peserta_tender_pq_penawaran C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1333
ERROR - 2024-02-21 18:05:21 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1333
ERROR - 2024-02-21 18:05:21 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1556
ERROR - 2024-02-21 18:05:21 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1566
ERROR - 2024-02-21 18:06:24 --> Severity: Notice --> Undefined index: ba_evaluasi_jam C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 964
ERROR - 2024-02-21 18:06:24 --> Severity: Notice --> Undefined variable: peserta_tender_pq_penawaran C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1333
ERROR - 2024-02-21 18:06:24 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1333
ERROR - 2024-02-21 18:06:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1556
ERROR - 2024-02-21 18:06:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1566
ERROR - 2024-02-21 18:06:25 --> Severity: Notice --> Undefined index: ba_evaluasi_jam C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 964
ERROR - 2024-02-21 18:06:25 --> Severity: Notice --> Undefined variable: peserta_tender_pq_penawaran C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1333
ERROR - 2024-02-21 18:06:25 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1333
ERROR - 2024-02-21 18:06:25 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1556
ERROR - 2024-02-21 18:06:25 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1566
ERROR - 2024-02-21 18:06:26 --> Severity: Notice --> Undefined index: ba_evaluasi_jam C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 964
ERROR - 2024-02-21 18:06:26 --> Severity: Notice --> Undefined variable: peserta_tender_pq_penawaran C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1333
ERROR - 2024-02-21 18:06:26 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1333
ERROR - 2024-02-21 18:06:26 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1556
ERROR - 2024-02-21 18:06:26 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1566
ERROR - 2024-02-21 18:06:27 --> Severity: Notice --> Undefined index: ba_evaluasi_jam C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 964
ERROR - 2024-02-21 18:06:27 --> Severity: Notice --> Undefined variable: peserta_tender_pq_penawaran C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1333
ERROR - 2024-02-21 18:06:27 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1333
ERROR - 2024-02-21 18:06:27 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1556
ERROR - 2024-02-21 18:06:27 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1566
ERROR - 2024-02-21 18:06:30 --> 404 Page Not Found: panitia/info_tender/Informasi_tender_terbatas_pra_1_file/get_pengalaman
ERROR - 2024-02-21 18:06:36 --> Severity: Notice --> Undefined index: ba_evaluasi_jam C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 964
ERROR - 2024-02-21 18:06:36 --> Severity: Notice --> Undefined variable: peserta_tender_pq_penawaran C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1333
ERROR - 2024-02-21 18:06:36 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1333
ERROR - 2024-02-21 18:06:36 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1556
ERROR - 2024-02-21 18:06:36 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1566
ERROR - 2024-02-21 18:06:38 --> Severity: Notice --> Undefined index: ba_evaluasi_jam C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 964
ERROR - 2024-02-21 18:06:38 --> Severity: Notice --> Undefined variable: peserta_tender_pq_penawaran C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1333
ERROR - 2024-02-21 18:06:38 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1333
ERROR - 2024-02-21 18:06:38 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1556
ERROR - 2024-02-21 18:06:38 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1566
ERROR - 2024-02-21 18:06:39 --> Severity: Notice --> Undefined index: ba_evaluasi_jam C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 964
ERROR - 2024-02-21 18:06:39 --> Severity: Notice --> Undefined variable: peserta_tender_pq_penawaran C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1333
ERROR - 2024-02-21 18:06:39 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1333
ERROR - 2024-02-21 18:06:39 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1556
ERROR - 2024-02-21 18:06:39 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1566
ERROR - 2024-02-21 18:06:40 --> Severity: Notice --> Undefined index: ba_evaluasi_jam C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 964
ERROR - 2024-02-21 18:06:40 --> Severity: Notice --> Undefined variable: peserta_tender_pq_penawaran C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1333
ERROR - 2024-02-21 18:06:40 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1333
ERROR - 2024-02-21 18:06:40 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1556
ERROR - 2024-02-21 18:06:40 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1566
ERROR - 2024-02-21 18:07:55 --> Severity: Notice --> Undefined index: ba_evaluasi_jam C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 964
ERROR - 2024-02-21 18:07:55 --> Severity: Notice --> Undefined variable: peserta_tender_pq_penawaran C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1333
ERROR - 2024-02-21 18:07:55 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1333
ERROR - 2024-02-21 18:07:55 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1556
ERROR - 2024-02-21 18:07:55 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1566
ERROR - 2024-02-21 18:07:57 --> Severity: Notice --> Undefined index: ba_evaluasi_jam C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 964
ERROR - 2024-02-21 18:07:57 --> Severity: Notice --> Undefined variable: peserta_tender_pq_penawaran C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1333
ERROR - 2024-02-21 18:07:57 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1333
ERROR - 2024-02-21 18:07:57 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1556
ERROR - 2024-02-21 18:07:57 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1566
ERROR - 2024-02-21 18:07:58 --> Severity: Notice --> Undefined index: ba_evaluasi_jam C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 964
ERROR - 2024-02-21 18:07:58 --> Severity: Notice --> Undefined variable: peserta_tender_pq_penawaran C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1333
ERROR - 2024-02-21 18:07:58 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1333
ERROR - 2024-02-21 18:07:58 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1556
ERROR - 2024-02-21 18:07:58 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1566
ERROR - 2024-02-21 18:07:59 --> Severity: Notice --> Undefined index: ba_evaluasi_jam C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 964
ERROR - 2024-02-21 18:07:59 --> Severity: Notice --> Undefined variable: peserta_tender_pq_penawaran C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1333
ERROR - 2024-02-21 18:07:59 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1333
ERROR - 2024-02-21 18:07:59 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1556
ERROR - 2024-02-21 18:07:59 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1566
ERROR - 2024-02-21 18:08:26 --> Severity: Notice --> Undefined index: ba_evaluasi_jam C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 964
ERROR - 2024-02-21 18:08:26 --> Severity: Notice --> Undefined variable: peserta_tender_pq_penawaran C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1333
ERROR - 2024-02-21 18:08:26 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1333
ERROR - 2024-02-21 18:08:26 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1556
ERROR - 2024-02-21 18:08:26 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1566
ERROR - 2024-02-21 18:08:27 --> Severity: Notice --> Undefined index: ba_evaluasi_jam C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 964
ERROR - 2024-02-21 18:08:27 --> Severity: Notice --> Undefined variable: peserta_tender_pq_penawaran C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1333
ERROR - 2024-02-21 18:08:27 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1333
ERROR - 2024-02-21 18:08:27 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1556
ERROR - 2024-02-21 18:08:27 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1566
ERROR - 2024-02-21 18:08:28 --> Severity: Notice --> Undefined index: ba_evaluasi_jam C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 964
ERROR - 2024-02-21 18:08:28 --> Severity: Notice --> Undefined variable: peserta_tender_pq_penawaran C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1333
ERROR - 2024-02-21 18:08:28 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1333
ERROR - 2024-02-21 18:08:28 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1556
ERROR - 2024-02-21 18:08:28 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1566
ERROR - 2024-02-21 18:08:29 --> Severity: Notice --> Undefined index: ba_evaluasi_jam C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 964
ERROR - 2024-02-21 18:08:29 --> Severity: Notice --> Undefined variable: peserta_tender_pq_penawaran C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1333
ERROR - 2024-02-21 18:08:29 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1333
ERROR - 2024-02-21 18:08:29 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1556
ERROR - 2024-02-21 18:08:29 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1566
ERROR - 2024-02-21 18:11:54 --> Severity: Notice --> Undefined index: ba_evaluasi_jam C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 964
ERROR - 2024-02-21 18:11:54 --> Severity: Notice --> Undefined variable: peserta_tender_pq_penawaran C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1333
ERROR - 2024-02-21 18:11:54 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1333
ERROR - 2024-02-21 18:11:54 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1556
ERROR - 2024-02-21 18:11:54 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1566
ERROR - 2024-02-21 18:11:55 --> Severity: Notice --> Undefined index: ba_evaluasi_jam C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 964
ERROR - 2024-02-21 18:11:55 --> Severity: Notice --> Undefined variable: peserta_tender_pq_penawaran C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1333
ERROR - 2024-02-21 18:11:55 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1333
ERROR - 2024-02-21 18:11:55 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1556
ERROR - 2024-02-21 18:11:55 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1566
ERROR - 2024-02-21 18:11:56 --> Severity: Notice --> Undefined index: ba_evaluasi_jam C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 964
ERROR - 2024-02-21 18:11:56 --> Severity: Notice --> Undefined variable: peserta_tender_pq_penawaran C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1333
ERROR - 2024-02-21 18:11:56 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1333
ERROR - 2024-02-21 18:11:56 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1556
ERROR - 2024-02-21 18:11:56 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1566
ERROR - 2024-02-21 18:11:57 --> Severity: Notice --> Undefined index: ba_evaluasi_jam C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 964
ERROR - 2024-02-21 18:11:57 --> Severity: Notice --> Undefined variable: peserta_tender_pq_penawaran C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1333
ERROR - 2024-02-21 18:11:57 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1333
ERROR - 2024-02-21 18:11:57 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1556
ERROR - 2024-02-21 18:11:57 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1566
ERROR - 2024-02-21 18:12:14 --> Severity: Notice --> Undefined index: ba_evaluasi_jam C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 964
ERROR - 2024-02-21 18:12:14 --> Severity: Notice --> Undefined variable: peserta_tender_pq_penawaran C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1333
ERROR - 2024-02-21 18:12:14 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1333
ERROR - 2024-02-21 18:12:14 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1556
ERROR - 2024-02-21 18:12:14 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1566
ERROR - 2024-02-21 18:12:15 --> Severity: Notice --> Undefined index: ba_evaluasi_jam C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 964
ERROR - 2024-02-21 18:12:15 --> Severity: Notice --> Undefined variable: peserta_tender_pq_penawaran C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1333
ERROR - 2024-02-21 18:12:15 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1333
ERROR - 2024-02-21 18:12:15 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1556
ERROR - 2024-02-21 18:12:15 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1566
ERROR - 2024-02-21 18:12:16 --> Severity: Notice --> Undefined index: ba_evaluasi_jam C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 964
ERROR - 2024-02-21 18:12:16 --> Severity: Notice --> Undefined variable: peserta_tender_pq_penawaran C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1333
ERROR - 2024-02-21 18:12:16 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1333
ERROR - 2024-02-21 18:12:16 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1556
ERROR - 2024-02-21 18:12:16 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1566
ERROR - 2024-02-21 18:12:17 --> Severity: Notice --> Undefined index: ba_evaluasi_jam C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 964
ERROR - 2024-02-21 18:12:17 --> Severity: Notice --> Undefined variable: peserta_tender_pq_penawaran C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1333
ERROR - 2024-02-21 18:12:17 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1333
ERROR - 2024-02-21 18:12:17 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1556
ERROR - 2024-02-21 18:12:17 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1566
ERROR - 2024-02-21 18:12:36 --> Severity: Notice --> Undefined index: ba_evaluasi_jam C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 964
ERROR - 2024-02-21 18:12:36 --> Severity: Notice --> Undefined variable: peserta_tender_pq_penawaran C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1333
ERROR - 2024-02-21 18:12:36 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1333
ERROR - 2024-02-21 18:12:36 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1556
ERROR - 2024-02-21 18:12:36 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1566
ERROR - 2024-02-21 18:12:37 --> Severity: Notice --> Undefined index: ba_evaluasi_jam C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 964
ERROR - 2024-02-21 18:12:37 --> Severity: Notice --> Undefined variable: peserta_tender_pq_penawaran C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1333
ERROR - 2024-02-21 18:12:37 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1333
ERROR - 2024-02-21 18:12:37 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1556
ERROR - 2024-02-21 18:12:37 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1566
ERROR - 2024-02-21 18:12:38 --> Severity: Notice --> Undefined index: ba_evaluasi_jam C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 964
ERROR - 2024-02-21 18:12:38 --> Severity: Notice --> Undefined variable: peserta_tender_pq_penawaran C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1333
ERROR - 2024-02-21 18:12:38 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1333
ERROR - 2024-02-21 18:12:38 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1556
ERROR - 2024-02-21 18:12:38 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1566
ERROR - 2024-02-21 18:12:39 --> Severity: Notice --> Undefined index: ba_evaluasi_jam C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 964
ERROR - 2024-02-21 18:12:39 --> Severity: Notice --> Undefined variable: peserta_tender_pq_penawaran C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1333
ERROR - 2024-02-21 18:12:39 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1333
ERROR - 2024-02-21 18:12:39 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1556
ERROR - 2024-02-21 18:12:39 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1566
ERROR - 2024-02-21 18:12:44 --> Severity: Notice --> Undefined property: stdClass::$nama_pekerjaanASDASFSDF C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_terbatas_pra_1_file.php 3092
ERROR - 2024-02-21 18:12:44 --> Severity: Notice --> Undefined property: stdClass::$nama_pekerjaanASDASFSDF C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_terbatas_pra_1_file.php 3092
ERROR - 2024-02-21 18:12:44 --> Severity: Notice --> Undefined property: stdClass::$nama_pekerjaanASDASFSDF C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_terbatas_pra_1_file.php 3092
ERROR - 2024-02-21 18:12:44 --> Severity: Notice --> Undefined property: stdClass::$nama_pekerjaanASDASFSDF C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_terbatas_pra_1_file.php 3092
ERROR - 2024-02-21 18:12:44 --> Severity: Notice --> Undefined property: stdClass::$nama_pekerjaanASDASFSDF C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_terbatas_pra_1_file.php 3092
ERROR - 2024-02-21 18:12:44 --> Severity: Notice --> Undefined property: stdClass::$nama_pekerjaanASDASFSDF C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_terbatas_pra_1_file.php 3092
ERROR - 2024-02-21 18:12:44 --> Severity: Notice --> Undefined property: stdClass::$nama_pekerjaanASDASFSDF C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_terbatas_pra_1_file.php 3092
ERROR - 2024-02-21 18:13:16 --> Severity: Notice --> Undefined index: ba_evaluasi_jam C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 964
ERROR - 2024-02-21 18:13:16 --> Severity: Notice --> Undefined variable: peserta_tender_pq_penawaran C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1333
ERROR - 2024-02-21 18:13:16 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1333
ERROR - 2024-02-21 18:13:16 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1556
ERROR - 2024-02-21 18:13:16 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1566
ERROR - 2024-02-21 18:13:18 --> Severity: Notice --> Undefined index: ba_evaluasi_jam C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 964
ERROR - 2024-02-21 18:13:18 --> Severity: Notice --> Undefined variable: peserta_tender_pq_penawaran C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1333
ERROR - 2024-02-21 18:13:18 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1333
ERROR - 2024-02-21 18:13:18 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1556
ERROR - 2024-02-21 18:13:18 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1566
ERROR - 2024-02-21 18:13:19 --> Severity: Notice --> Undefined index: ba_evaluasi_jam C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 964
ERROR - 2024-02-21 18:13:19 --> Severity: Notice --> Undefined variable: peserta_tender_pq_penawaran C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1333
ERROR - 2024-02-21 18:13:19 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1333
ERROR - 2024-02-21 18:13:19 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1556
ERROR - 2024-02-21 18:13:19 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1566
ERROR - 2024-02-21 18:13:20 --> Severity: Notice --> Undefined index: ba_evaluasi_jam C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 964
ERROR - 2024-02-21 18:13:20 --> Severity: Notice --> Undefined variable: peserta_tender_pq_penawaran C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1333
ERROR - 2024-02-21 18:13:20 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1333
ERROR - 2024-02-21 18:13:20 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1556
ERROR - 2024-02-21 18:13:20 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1566
ERROR - 2024-02-21 18:13:51 --> Severity: Notice --> Undefined index: ba_evaluasi_jam C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 964
ERROR - 2024-02-21 18:13:51 --> Severity: Notice --> Undefined variable: peserta_tender_pq_penawaran C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1333
ERROR - 2024-02-21 18:13:51 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1333
ERROR - 2024-02-21 18:13:51 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1556
ERROR - 2024-02-21 18:13:51 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1566
ERROR - 2024-02-21 18:13:53 --> Severity: Notice --> Undefined index: ba_evaluasi_jam C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 964
ERROR - 2024-02-21 18:13:53 --> Severity: Notice --> Undefined variable: peserta_tender_pq_penawaran C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1333
ERROR - 2024-02-21 18:13:53 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1333
ERROR - 2024-02-21 18:13:53 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1556
ERROR - 2024-02-21 18:13:53 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1566
ERROR - 2024-02-21 18:13:54 --> Severity: Notice --> Undefined index: ba_evaluasi_jam C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 964
ERROR - 2024-02-21 18:13:54 --> Severity: Notice --> Undefined variable: peserta_tender_pq_penawaran C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1333
ERROR - 2024-02-21 18:13:54 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1333
ERROR - 2024-02-21 18:13:54 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1556
ERROR - 2024-02-21 18:13:54 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1566
ERROR - 2024-02-21 18:13:55 --> Severity: Notice --> Undefined index: ba_evaluasi_jam C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 964
ERROR - 2024-02-21 18:13:55 --> Severity: Notice --> Undefined variable: peserta_tender_pq_penawaran C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1333
ERROR - 2024-02-21 18:13:55 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1333
ERROR - 2024-02-21 18:13:55 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1556
ERROR - 2024-02-21 18:13:55 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1566
ERROR - 2024-02-21 18:14:13 --> Severity: Notice --> Undefined index: ba_evaluasi_jam C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 964
ERROR - 2024-02-21 18:14:13 --> Severity: Notice --> Undefined variable: peserta_tender_pq_penawaran C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1333
ERROR - 2024-02-21 18:14:13 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1333
ERROR - 2024-02-21 18:14:13 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1556
ERROR - 2024-02-21 18:14:13 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1566
ERROR - 2024-02-21 18:14:15 --> Severity: Notice --> Undefined index: ba_evaluasi_jam C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 964
ERROR - 2024-02-21 18:14:15 --> Severity: Notice --> Undefined variable: peserta_tender_pq_penawaran C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1333
ERROR - 2024-02-21 18:14:15 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1333
ERROR - 2024-02-21 18:14:15 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1556
ERROR - 2024-02-21 18:14:15 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1566
ERROR - 2024-02-21 18:14:16 --> Severity: Notice --> Undefined index: ba_evaluasi_jam C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 964
ERROR - 2024-02-21 18:14:16 --> Severity: Notice --> Undefined variable: peserta_tender_pq_penawaran C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1333
ERROR - 2024-02-21 18:14:16 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1333
ERROR - 2024-02-21 18:14:16 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1556
ERROR - 2024-02-21 18:14:16 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1566
ERROR - 2024-02-21 18:14:16 --> Severity: Notice --> Undefined index: ba_evaluasi_jam C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 964
ERROR - 2024-02-21 18:14:16 --> Severity: Notice --> Undefined variable: peserta_tender_pq_penawaran C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1333
ERROR - 2024-02-21 18:14:16 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1333
ERROR - 2024-02-21 18:14:16 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1556
ERROR - 2024-02-21 18:14:17 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1566
ERROR - 2024-02-21 18:15:01 --> Severity: Notice --> Undefined index: ba_evaluasi_jam C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 964
ERROR - 2024-02-21 18:15:01 --> Severity: Notice --> Undefined variable: peserta_tender_pq_penawaran C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1333
ERROR - 2024-02-21 18:15:01 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1333
ERROR - 2024-02-21 18:15:01 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1556
ERROR - 2024-02-21 18:15:01 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1566
ERROR - 2024-02-21 18:15:02 --> Severity: Notice --> Undefined index: ba_evaluasi_jam C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 964
ERROR - 2024-02-21 18:15:02 --> Severity: Notice --> Undefined variable: peserta_tender_pq_penawaran C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1333
ERROR - 2024-02-21 18:15:02 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1333
ERROR - 2024-02-21 18:15:02 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1556
ERROR - 2024-02-21 18:15:02 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1566
ERROR - 2024-02-21 18:15:03 --> Severity: Notice --> Undefined index: ba_evaluasi_jam C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 964
ERROR - 2024-02-21 18:15:03 --> Severity: Notice --> Undefined variable: peserta_tender_pq_penawaran C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1333
ERROR - 2024-02-21 18:15:03 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1333
ERROR - 2024-02-21 18:15:03 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1556
ERROR - 2024-02-21 18:15:03 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1566
ERROR - 2024-02-21 18:15:04 --> Severity: Notice --> Undefined index: ba_evaluasi_jam C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 964
ERROR - 2024-02-21 18:15:04 --> Severity: Notice --> Undefined variable: peserta_tender_pq_penawaran C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1333
ERROR - 2024-02-21 18:15:04 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1333
ERROR - 2024-02-21 18:15:04 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1556
ERROR - 2024-02-21 18:15:04 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1566
ERROR - 2024-02-21 18:15:07 --> Severity: Notice --> Undefined index: ba_evaluasi_jam C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 964
ERROR - 2024-02-21 18:15:07 --> Severity: Notice --> Undefined variable: peserta_tender_pq_penawaran C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1333
ERROR - 2024-02-21 18:15:07 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1333
ERROR - 2024-02-21 18:15:07 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1556
ERROR - 2024-02-21 18:15:07 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1566
ERROR - 2024-02-21 18:15:08 --> Severity: Notice --> Undefined index: ba_evaluasi_jam C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 964
ERROR - 2024-02-21 18:15:08 --> Severity: Notice --> Undefined variable: peserta_tender_pq_penawaran C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1333
ERROR - 2024-02-21 18:15:08 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1333
ERROR - 2024-02-21 18:15:08 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1556
ERROR - 2024-02-21 18:15:08 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1566
ERROR - 2024-02-21 18:15:09 --> Severity: Notice --> Undefined index: ba_evaluasi_jam C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 964
ERROR - 2024-02-21 18:15:09 --> Severity: Notice --> Undefined variable: peserta_tender_pq_penawaran C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1333
ERROR - 2024-02-21 18:15:09 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1333
ERROR - 2024-02-21 18:15:09 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1556
ERROR - 2024-02-21 18:15:09 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1566
ERROR - 2024-02-21 18:15:10 --> Severity: Notice --> Undefined index: ba_evaluasi_jam C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 964
ERROR - 2024-02-21 18:15:10 --> Severity: Notice --> Undefined variable: peserta_tender_pq_penawaran C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1333
ERROR - 2024-02-21 18:15:10 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1333
ERROR - 2024-02-21 18:15:10 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1556
ERROR - 2024-02-21 18:15:10 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1566
ERROR - 2024-02-21 18:16:07 --> Severity: Notice --> Undefined index: ba_evaluasi_jam C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 964
ERROR - 2024-02-21 18:16:07 --> Severity: Notice --> Undefined variable: peserta_tender_pq_penawaran C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1333
ERROR - 2024-02-21 18:16:07 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1333
ERROR - 2024-02-21 18:16:07 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1556
ERROR - 2024-02-21 18:16:07 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1566
ERROR - 2024-02-21 18:16:08 --> Severity: Notice --> Undefined index: ba_evaluasi_jam C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 964
ERROR - 2024-02-21 18:16:08 --> Severity: Notice --> Undefined variable: peserta_tender_pq_penawaran C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1333
ERROR - 2024-02-21 18:16:08 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1333
ERROR - 2024-02-21 18:16:08 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1556
ERROR - 2024-02-21 18:16:08 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1566
ERROR - 2024-02-21 18:16:09 --> Severity: Notice --> Undefined index: ba_evaluasi_jam C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 964
ERROR - 2024-02-21 18:16:09 --> Severity: Notice --> Undefined variable: peserta_tender_pq_penawaran C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1333
ERROR - 2024-02-21 18:16:09 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1333
ERROR - 2024-02-21 18:16:09 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1556
ERROR - 2024-02-21 18:16:09 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1566
ERROR - 2024-02-21 18:16:10 --> Severity: Notice --> Undefined index: ba_evaluasi_jam C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 964
ERROR - 2024-02-21 18:16:10 --> Severity: Notice --> Undefined variable: peserta_tender_pq_penawaran C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1333
ERROR - 2024-02-21 18:16:10 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1333
ERROR - 2024-02-21 18:16:10 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1556
ERROR - 2024-02-21 18:16:10 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1566
ERROR - 2024-02-21 18:16:12 --> Query error: Column 'id_vendor' in where clause is ambiguous - Invalid query: SELECT *
FROM `tbl_vendor_pengalaman`
LEFT JOIN `tbl_vendor` ON `tbl_vendor_pengalaman`.`id_vendor` = `tbl_vendor`.`id_vendor`
WHERE `id_vendor` = '86'
ORDER BY `tbl_vendor_pengalaman`.`id_pengalaman` DESC, `tbl_vendor_pengalaman`.`id_pengalaman` DESC
 LIMIT 10
ERROR - 2024-02-21 18:16:40 --> Severity: Notice --> Undefined index: ba_evaluasi_jam C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 964
ERROR - 2024-02-21 18:16:40 --> Severity: Notice --> Undefined variable: peserta_tender_pq_penawaran C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1333
ERROR - 2024-02-21 18:16:40 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1333
ERROR - 2024-02-21 18:16:40 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1556
ERROR - 2024-02-21 18:16:40 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1566
ERROR - 2024-02-21 18:16:41 --> Severity: Notice --> Undefined index: ba_evaluasi_jam C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 964
ERROR - 2024-02-21 18:16:41 --> Severity: Notice --> Undefined variable: peserta_tender_pq_penawaran C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1333
ERROR - 2024-02-21 18:16:41 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1333
ERROR - 2024-02-21 18:16:41 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1556
ERROR - 2024-02-21 18:16:41 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1566
ERROR - 2024-02-21 18:16:42 --> Severity: Notice --> Undefined index: ba_evaluasi_jam C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 964
ERROR - 2024-02-21 18:16:42 --> Severity: Notice --> Undefined variable: peserta_tender_pq_penawaran C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1333
ERROR - 2024-02-21 18:16:42 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1333
ERROR - 2024-02-21 18:16:42 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1556
ERROR - 2024-02-21 18:16:42 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1566
ERROR - 2024-02-21 18:16:43 --> Severity: Notice --> Undefined index: ba_evaluasi_jam C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 964
ERROR - 2024-02-21 18:16:43 --> Severity: Notice --> Undefined variable: peserta_tender_pq_penawaran C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1333
ERROR - 2024-02-21 18:16:43 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1333
ERROR - 2024-02-21 18:16:43 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1556
ERROR - 2024-02-21 18:16:43 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1566
ERROR - 2024-02-21 18:16:53 --> Severity: Notice --> Undefined index: ba_evaluasi_jam C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 964
ERROR - 2024-02-21 18:16:53 --> Severity: Notice --> Undefined variable: peserta_tender_pq_penawaran C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1333
ERROR - 2024-02-21 18:16:53 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1333
ERROR - 2024-02-21 18:16:53 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1556
ERROR - 2024-02-21 18:16:53 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1566
ERROR - 2024-02-21 18:16:55 --> Severity: Notice --> Undefined index: ba_evaluasi_jam C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 964
ERROR - 2024-02-21 18:16:55 --> Severity: Notice --> Undefined variable: peserta_tender_pq_penawaran C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1333
ERROR - 2024-02-21 18:16:55 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1333
ERROR - 2024-02-21 18:16:55 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1556
ERROR - 2024-02-21 18:16:55 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1566
ERROR - 2024-02-21 18:16:56 --> Severity: Notice --> Undefined index: ba_evaluasi_jam C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 964
ERROR - 2024-02-21 18:16:56 --> Severity: Notice --> Undefined variable: peserta_tender_pq_penawaran C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1333
ERROR - 2024-02-21 18:16:56 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1333
ERROR - 2024-02-21 18:16:56 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1556
ERROR - 2024-02-21 18:16:56 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1566
ERROR - 2024-02-21 18:16:57 --> Severity: Notice --> Undefined index: ba_evaluasi_jam C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 964
ERROR - 2024-02-21 18:16:57 --> Severity: Notice --> Undefined variable: peserta_tender_pq_penawaran C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1333
ERROR - 2024-02-21 18:16:57 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1333
ERROR - 2024-02-21 18:16:57 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1556
ERROR - 2024-02-21 18:16:57 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1566
ERROR - 2024-02-21 18:18:29 --> Severity: Notice --> Undefined index: ba_evaluasi_jam C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 964
ERROR - 2024-02-21 18:18:29 --> Severity: Notice --> Undefined variable: peserta_tender_pq_penawaran C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1333
ERROR - 2024-02-21 18:18:29 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1333
ERROR - 2024-02-21 18:18:29 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1556
ERROR - 2024-02-21 18:18:29 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1566
ERROR - 2024-02-21 18:18:30 --> Severity: Notice --> Undefined index: ba_evaluasi_jam C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 964
ERROR - 2024-02-21 18:18:30 --> Severity: Notice --> Undefined variable: peserta_tender_pq_penawaran C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1333
ERROR - 2024-02-21 18:18:30 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1333
ERROR - 2024-02-21 18:18:30 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1556
ERROR - 2024-02-21 18:18:30 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1566
ERROR - 2024-02-21 18:18:31 --> Severity: Notice --> Undefined index: ba_evaluasi_jam C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 964
ERROR - 2024-02-21 18:18:31 --> Severity: Notice --> Undefined variable: peserta_tender_pq_penawaran C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1333
ERROR - 2024-02-21 18:18:31 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1333
ERROR - 2024-02-21 18:18:31 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1556
ERROR - 2024-02-21 18:18:31 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1566
ERROR - 2024-02-21 18:18:32 --> Severity: Notice --> Undefined index: ba_evaluasi_jam C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 964
ERROR - 2024-02-21 18:18:32 --> Severity: Notice --> Undefined variable: peserta_tender_pq_penawaran C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1333
ERROR - 2024-02-21 18:18:32 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1333
ERROR - 2024-02-21 18:18:32 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1556
ERROR - 2024-02-21 18:18:32 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1566
ERROR - 2024-02-21 18:18:34 --> Severity: Notice --> Undefined property: stdClass::$sts_token_dokumen C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_terbatas_pra_1_file.php 3112
ERROR - 2024-02-21 18:18:34 --> Severity: Notice --> Undefined property: stdClass::$file_laporan_keuangan C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_terbatas_pra_1_file.php 3115
ERROR - 2024-02-21 18:18:34 --> Severity: Notice --> Undefined property: stdClass::$sts_token_dokumen C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_terbatas_pra_1_file.php 3112
ERROR - 2024-02-21 18:18:34 --> Severity: Notice --> Undefined property: stdClass::$file_laporan_keuangan C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_terbatas_pra_1_file.php 3115
ERROR - 2024-02-21 18:18:34 --> Severity: Notice --> Undefined property: stdClass::$sts_token_dokumen C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_terbatas_pra_1_file.php 3112
ERROR - 2024-02-21 18:18:34 --> Severity: Notice --> Undefined property: stdClass::$file_laporan_keuangan C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_terbatas_pra_1_file.php 3115
ERROR - 2024-02-21 18:18:34 --> Severity: Notice --> Undefined property: stdClass::$sts_token_dokumen C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_terbatas_pra_1_file.php 3112
ERROR - 2024-02-21 18:18:34 --> Severity: Notice --> Undefined property: stdClass::$file_laporan_keuangan C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_terbatas_pra_1_file.php 3115
ERROR - 2024-02-21 18:18:34 --> Severity: Notice --> Undefined property: stdClass::$sts_token_dokumen C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_terbatas_pra_1_file.php 3112
ERROR - 2024-02-21 18:18:34 --> Severity: Notice --> Undefined property: stdClass::$file_laporan_keuangan C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_terbatas_pra_1_file.php 3115
ERROR - 2024-02-21 18:18:34 --> Severity: Notice --> Undefined property: stdClass::$sts_token_dokumen C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_terbatas_pra_1_file.php 3112
ERROR - 2024-02-21 18:18:34 --> Severity: Notice --> Undefined property: stdClass::$file_laporan_keuangan C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_terbatas_pra_1_file.php 3115
ERROR - 2024-02-21 18:18:34 --> Severity: Notice --> Undefined property: stdClass::$sts_token_dokumen C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_terbatas_pra_1_file.php 3112
ERROR - 2024-02-21 18:18:34 --> Severity: Notice --> Undefined property: stdClass::$file_laporan_keuangan C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_terbatas_pra_1_file.php 3115
ERROR - 2024-02-21 18:20:31 --> Severity: Notice --> Undefined index: ba_evaluasi_jam C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 964
ERROR - 2024-02-21 18:20:31 --> Severity: Notice --> Undefined variable: peserta_tender_pq_penawaran C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1333
ERROR - 2024-02-21 18:20:31 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1333
ERROR - 2024-02-21 18:20:31 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1556
ERROR - 2024-02-21 18:20:31 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1566
ERROR - 2024-02-21 18:20:32 --> Severity: Notice --> Undefined index: ba_evaluasi_jam C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 964
ERROR - 2024-02-21 18:20:32 --> Severity: Notice --> Undefined variable: peserta_tender_pq_penawaran C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1333
ERROR - 2024-02-21 18:20:32 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1333
ERROR - 2024-02-21 18:20:32 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1556
ERROR - 2024-02-21 18:20:32 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1566
ERROR - 2024-02-21 18:20:33 --> Severity: Notice --> Undefined index: ba_evaluasi_jam C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 964
ERROR - 2024-02-21 18:20:33 --> Severity: Notice --> Undefined variable: peserta_tender_pq_penawaran C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1333
ERROR - 2024-02-21 18:20:33 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1333
ERROR - 2024-02-21 18:20:33 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1556
ERROR - 2024-02-21 18:20:33 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1566
ERROR - 2024-02-21 18:20:34 --> Severity: Notice --> Undefined index: ba_evaluasi_jam C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 964
ERROR - 2024-02-21 18:20:34 --> Severity: Notice --> Undefined variable: peserta_tender_pq_penawaran C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1333
ERROR - 2024-02-21 18:20:34 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1333
ERROR - 2024-02-21 18:20:34 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1556
ERROR - 2024-02-21 18:20:34 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1566
ERROR - 2024-02-21 18:20:36 --> Severity: Notice --> Undefined property: stdClass::$file_laporan_auditor C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_terbatas_pra_1_file.php 3115
ERROR - 2024-02-21 18:20:36 --> Severity: Notice --> Undefined property: stdClass::$file_laporan_auditor C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_terbatas_pra_1_file.php 3115
ERROR - 2024-02-21 18:20:36 --> Severity: Notice --> Undefined property: stdClass::$file_laporan_auditor C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_terbatas_pra_1_file.php 3115
ERROR - 2024-02-21 18:20:36 --> Severity: Notice --> Undefined property: stdClass::$file_laporan_auditor C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_terbatas_pra_1_file.php 3115
ERROR - 2024-02-21 18:20:36 --> Severity: Notice --> Undefined property: stdClass::$file_laporan_auditor C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_terbatas_pra_1_file.php 3115
ERROR - 2024-02-21 18:20:36 --> Severity: Notice --> Undefined property: stdClass::$file_laporan_auditor C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_terbatas_pra_1_file.php 3115
ERROR - 2024-02-21 18:20:36 --> Severity: Notice --> Undefined property: stdClass::$file_laporan_auditor C:\laragon\www\jmto-eproc\application\controllers\panitia\info_tender\Informasi_tender_terbatas_pra_1_file.php 3115
ERROR - 2024-02-21 18:20:41 --> Severity: Notice --> Undefined index: ba_evaluasi_jam C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 964
ERROR - 2024-02-21 18:20:41 --> Severity: Notice --> Undefined variable: peserta_tender_pq_penawaran C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1333
ERROR - 2024-02-21 18:20:41 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1333
ERROR - 2024-02-21 18:20:41 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1556
ERROR - 2024-02-21 18:20:41 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1566
ERROR - 2024-02-21 18:20:42 --> Severity: Notice --> Undefined index: ba_evaluasi_jam C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 964
ERROR - 2024-02-21 18:20:42 --> Severity: Notice --> Undefined variable: peserta_tender_pq_penawaran C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1333
ERROR - 2024-02-21 18:20:42 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1333
ERROR - 2024-02-21 18:20:42 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1556
ERROR - 2024-02-21 18:20:42 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1566
ERROR - 2024-02-21 18:20:43 --> Severity: Notice --> Undefined index: ba_evaluasi_jam C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 964
ERROR - 2024-02-21 18:20:43 --> Severity: Notice --> Undefined variable: peserta_tender_pq_penawaran C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1333
ERROR - 2024-02-21 18:20:43 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1333
ERROR - 2024-02-21 18:20:43 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1556
ERROR - 2024-02-21 18:20:43 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1566
ERROR - 2024-02-21 18:20:44 --> Severity: Notice --> Undefined index: ba_evaluasi_jam C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 964
ERROR - 2024-02-21 18:20:44 --> Severity: Notice --> Undefined variable: peserta_tender_pq_penawaran C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1333
ERROR - 2024-02-21 18:20:44 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1333
ERROR - 2024-02-21 18:20:44 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1556
ERROR - 2024-02-21 18:20:44 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1566
ERROR - 2024-02-21 18:21:08 --> Severity: Notice --> Undefined index: ba_evaluasi_jam C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 964
ERROR - 2024-02-21 18:21:08 --> Severity: Notice --> Undefined variable: peserta_tender_pq_penawaran C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1333
ERROR - 2024-02-21 18:21:08 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1333
ERROR - 2024-02-21 18:21:08 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1556
ERROR - 2024-02-21 18:21:08 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1566
ERROR - 2024-02-21 18:21:09 --> Severity: Notice --> Undefined index: ba_evaluasi_jam C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 964
ERROR - 2024-02-21 18:21:09 --> Severity: Notice --> Undefined variable: peserta_tender_pq_penawaran C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1333
ERROR - 2024-02-21 18:21:09 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1333
ERROR - 2024-02-21 18:21:09 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1556
ERROR - 2024-02-21 18:21:09 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1566
ERROR - 2024-02-21 18:21:10 --> Severity: Notice --> Undefined index: ba_evaluasi_jam C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 964
ERROR - 2024-02-21 18:21:10 --> Severity: Notice --> Undefined variable: peserta_tender_pq_penawaran C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1333
ERROR - 2024-02-21 18:21:10 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1333
ERROR - 2024-02-21 18:21:10 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1556
ERROR - 2024-02-21 18:21:10 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1566
ERROR - 2024-02-21 18:21:11 --> Severity: Notice --> Undefined index: ba_evaluasi_jam C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 964
ERROR - 2024-02-21 18:21:11 --> Severity: Notice --> Undefined variable: peserta_tender_pq_penawaran C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1333
ERROR - 2024-02-21 18:21:11 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1333
ERROR - 2024-02-21 18:21:11 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1556
ERROR - 2024-02-21 18:21:11 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1566
ERROR - 2024-02-21 18:24:45 --> Severity: Notice --> Undefined index: ba_evaluasi_jam C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 964
ERROR - 2024-02-21 18:24:45 --> Severity: Notice --> Undefined variable: peserta_tender_pq_penawaran C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1333
ERROR - 2024-02-21 18:24:45 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1333
ERROR - 2024-02-21 18:24:45 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1556
ERROR - 2024-02-21 18:24:45 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1566
ERROR - 2024-02-21 18:24:46 --> Severity: Notice --> Undefined index: ba_evaluasi_jam C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 964
ERROR - 2024-02-21 18:24:46 --> Severity: Notice --> Undefined variable: peserta_tender_pq_penawaran C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1333
ERROR - 2024-02-21 18:24:46 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1333
ERROR - 2024-02-21 18:24:46 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1556
ERROR - 2024-02-21 18:24:46 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1566
ERROR - 2024-02-21 18:24:47 --> Severity: Notice --> Undefined index: ba_evaluasi_jam C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 964
ERROR - 2024-02-21 18:24:47 --> Severity: Notice --> Undefined variable: peserta_tender_pq_penawaran C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1333
ERROR - 2024-02-21 18:24:47 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1333
ERROR - 2024-02-21 18:24:47 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1556
ERROR - 2024-02-21 18:24:47 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1566
ERROR - 2024-02-21 18:24:48 --> Severity: Notice --> Undefined index: ba_evaluasi_jam C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 964
ERROR - 2024-02-21 18:24:48 --> Severity: Notice --> Undefined variable: peserta_tender_pq_penawaran C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1333
ERROR - 2024-02-21 18:24:48 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1333
ERROR - 2024-02-21 18:24:48 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1556
ERROR - 2024-02-21 18:24:48 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\panitia\info_tender\Informasi_tender_terbatas_pra_1_file\index.php 1566
ERROR - 2024-02-21 18:28:03 --> Query error: Column 'id_vendor' in where clause is ambiguous - Invalid query: SELECT *
FROM `tbl_vendor_pengalaman`
LEFT JOIN `tbl_vendor` ON `tbl_vendor_pengalaman`.`id_vendor` = `tbl_vendor`.`id_vendor`
WHERE `tbl_vendor_pengalaman`.`id_vendor` = '86'
AND   (
`id_vendor` LIKE '%s%' ESCAPE '!'
OR  `nama_pekerjaan` LIKE '%s%' ESCAPE '!'
OR  `instansi_pemberi` LIKE '%s%' ESCAPE '!'
OR  `tanggal_kontrak` LIKE '%s%' ESCAPE '!'
OR  `tanggal_kontrak` LIKE '%s%' ESCAPE '!'
OR  `instansi_pemberi` LIKE '%s%' ESCAPE '!'
OR  `nilai_kontrak` LIKE '%s%' ESCAPE '!'
OR  `id_vendor` LIKE '%s%' ESCAPE '!'
OR  `id_vendor` LIKE '%s%' ESCAPE '!'
OR  `id_vendor` LIKE '%s%' ESCAPE '!'
 )
ORDER BY `tbl_vendor_pengalaman`.`id_pengalaman` DESC, `tbl_vendor_pengalaman`.`id_pengalaman` DESC
 LIMIT 10
ERROR - 2024-02-21 18:28:04 --> Query error: Column 'id_vendor' in where clause is ambiguous - Invalid query: SELECT *
FROM `tbl_vendor_pengalaman`
LEFT JOIN `tbl_vendor` ON `tbl_vendor_pengalaman`.`id_vendor` = `tbl_vendor`.`id_vendor`
WHERE `tbl_vendor_pengalaman`.`id_vendor` = '86'
AND   (
`id_vendor` LIKE '%sdf%' ESCAPE '!'
OR  `nama_pekerjaan` LIKE '%sdf%' ESCAPE '!'
OR  `instansi_pemberi` LIKE '%sdf%' ESCAPE '!'
OR  `tanggal_kontrak` LIKE '%sdf%' ESCAPE '!'
OR  `tanggal_kontrak` LIKE '%sdf%' ESCAPE '!'
OR  `instansi_pemberi` LIKE '%sdf%' ESCAPE '!'
OR  `nilai_kontrak` LIKE '%sdf%' ESCAPE '!'
OR  `id_vendor` LIKE '%sdf%' ESCAPE '!'
OR  `id_vendor` LIKE '%sdf%' ESCAPE '!'
OR  `id_vendor` LIKE '%sdf%' ESCAPE '!'
 )
ORDER BY `tbl_vendor_pengalaman`.`id_pengalaman` DESC, `tbl_vendor_pengalaman`.`id_pengalaman` DESC
 LIMIT 10
ERROR - 2024-02-21 18:28:08 --> Query error: Column 'id_vendor' in where clause is ambiguous - Invalid query: SELECT *
FROM `tbl_vendor_pengalaman`
LEFT JOIN `tbl_vendor` ON `tbl_vendor_pengalaman`.`id_vendor` = `tbl_vendor`.`id_vendor`
WHERE `tbl_vendor_pengalaman`.`id_vendor` = '86'
AND   (
`id_vendor` LIKE '%s%' ESCAPE '!'
OR  `nama_pekerjaan` LIKE '%s%' ESCAPE '!'
OR  `instansi_pemberi` LIKE '%s%' ESCAPE '!'
OR  `tanggal_kontrak` LIKE '%s%' ESCAPE '!'
OR  `tanggal_kontrak` LIKE '%s%' ESCAPE '!'
OR  `instansi_pemberi` LIKE '%s%' ESCAPE '!'
OR  `nilai_kontrak` LIKE '%s%' ESCAPE '!'
OR  `id_vendor` LIKE '%s%' ESCAPE '!'
OR  `id_vendor` LIKE '%s%' ESCAPE '!'
OR  `id_vendor` LIKE '%s%' ESCAPE '!'
 )
ORDER BY `tbl_vendor_pengalaman`.`id_pengalaman` DESC, `tbl_vendor_pengalaman`.`id_pengalaman` DESC
 LIMIT 10
ERROR - 2024-02-21 18:28:09 --> Query error: Column 'id_vendor' in where clause is ambiguous - Invalid query: SELECT *
FROM `tbl_vendor_pengalaman`
LEFT JOIN `tbl_vendor` ON `tbl_vendor_pengalaman`.`id_vendor` = `tbl_vendor`.`id_vendor`
WHERE `tbl_vendor_pengalaman`.`id_vendor` = '86'
AND   (
`id_vendor` LIKE '%sfd%' ESCAPE '!'
OR  `nama_pekerjaan` LIKE '%sfd%' ESCAPE '!'
OR  `instansi_pemberi` LIKE '%sfd%' ESCAPE '!'
OR  `tanggal_kontrak` LIKE '%sfd%' ESCAPE '!'
OR  `tanggal_kontrak` LIKE '%sfd%' ESCAPE '!'
OR  `instansi_pemberi` LIKE '%sfd%' ESCAPE '!'
OR  `nilai_kontrak` LIKE '%sfd%' ESCAPE '!'
OR  `id_vendor` LIKE '%sfd%' ESCAPE '!'
OR  `id_vendor` LIKE '%sfd%' ESCAPE '!'
OR  `id_vendor` LIKE '%sfd%' ESCAPE '!'
 )
ORDER BY `tbl_vendor_pengalaman`.`id_pengalaman` DESC, `tbl_vendor_pengalaman`.`id_pengalaman` DESC
 LIMIT 10
