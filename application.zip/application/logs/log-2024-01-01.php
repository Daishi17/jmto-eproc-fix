<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2024-01-01 18:57:58 --> Severity: error --> Exception: Too few arguments to function Daftar_paket::by_id_rup(), 0 passed in C:\xampp\htdocs\jmto-eproc-fix\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\xampp\htdocs\jmto-eproc-fix\application\controllers\panitia\daftar_paket\Daftar_paket.php 387
