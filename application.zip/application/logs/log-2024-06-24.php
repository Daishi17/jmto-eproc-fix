<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2024-06-24 19:38:58 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_laporan\M_laporan.php 122
ERROR - 2024-06-24 19:38:58 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_laporan\M_laporan.php 122
ERROR - 2024-06-24 19:38:58 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_laporan\M_laporan.php 122
ERROR - 2024-06-24 19:38:58 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_laporan\M_laporan.php 122
ERROR - 2024-06-24 19:38:58 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_laporan\M_laporan.php 122
ERROR - 2024-06-24 19:38:58 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_laporan\M_laporan.php 122
ERROR - 2024-06-24 19:38:58 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_laporan\M_laporan.php 122
ERROR - 2024-06-24 19:38:58 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_laporan\M_laporan.php 122
ERROR - 2024-06-24 19:38:58 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_laporan\M_laporan.php 122
ERROR - 2024-06-24 19:38:58 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_laporan\M_laporan.php 122
ERROR - 2024-06-24 19:38:58 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_laporan\M_laporan.php 122
ERROR - 2024-06-24 19:38:58 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_laporan\M_laporan.php 122
ERROR - 2024-06-24 19:38:58 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_laporan\M_laporan.php 122
ERROR - 2024-06-24 19:38:58 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_laporan\M_laporan.php 122
ERROR - 2024-06-24 19:38:58 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_laporan\M_laporan.php 122
ERROR - 2024-06-24 19:38:58 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_laporan\M_laporan.php 122
ERROR - 2024-06-24 19:38:58 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_laporan\M_laporan.php 122
ERROR - 2024-06-24 19:38:58 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_laporan\M_laporan.php 122
ERROR - 2024-06-24 19:38:58 --> Severity: Notice --> Undefined index: length C:\laragon\www\jmto-eproc\application\models\M_laporan\M_laporan.php 151
ERROR - 2024-06-24 19:38:58 --> Severity: Notice --> Undefined index: length C:\laragon\www\jmto-eproc\application\models\M_laporan\M_laporan.php 152
ERROR - 2024-06-24 19:38:58 --> Severity: Notice --> Undefined index: start C:\laragon\www\jmto-eproc\application\models\M_laporan\M_laporan.php 152
ERROR - 2024-06-24 19:38:58 --> Severity: Notice --> Undefined index: start C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 311
ERROR - 2024-06-24 19:38:58 --> Severity: Notice --> Undefined index: draw C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 350
ERROR - 2024-06-24 19:38:58 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_laporan\M_laporan.php 122
ERROR - 2024-06-24 19:38:58 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_laporan\M_laporan.php 122
ERROR - 2024-06-24 19:38:58 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_laporan\M_laporan.php 122
ERROR - 2024-06-24 19:38:58 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_laporan\M_laporan.php 122
ERROR - 2024-06-24 19:38:58 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_laporan\M_laporan.php 122
ERROR - 2024-06-24 19:38:58 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_laporan\M_laporan.php 122
ERROR - 2024-06-24 19:38:58 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_laporan\M_laporan.php 122
ERROR - 2024-06-24 19:38:58 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_laporan\M_laporan.php 122
ERROR - 2024-06-24 19:38:58 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_laporan\M_laporan.php 122
ERROR - 2024-06-24 19:38:58 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_laporan\M_laporan.php 122
ERROR - 2024-06-24 19:38:58 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_laporan\M_laporan.php 122
ERROR - 2024-06-24 19:38:58 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_laporan\M_laporan.php 122
ERROR - 2024-06-24 19:38:58 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_laporan\M_laporan.php 122
ERROR - 2024-06-24 19:38:58 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_laporan\M_laporan.php 122
ERROR - 2024-06-24 19:38:58 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_laporan\M_laporan.php 122
ERROR - 2024-06-24 19:38:58 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_laporan\M_laporan.php 122
ERROR - 2024-06-24 19:38:58 --> Severity: Notice --> Undefined index: search C:\laragon\www\jmto-eproc\application\models\M_laporan\M_laporan.php 122
ERROR - 2024-06-24 19:38:58 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\models\M_laporan\M_laporan.php 122
ERROR - 2024-06-24 18:14:54 --> Severity: Warning --> mysqli::real_connect(): (HY000/2006): MySQL server has gone away C:\laragon\www\jmto-eproc\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2024-06-24 18:14:54 --> Unable to connect to the database
