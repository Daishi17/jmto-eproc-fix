<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2024-01-12 00:21:10 --> Severity: error --> Exception: Too few arguments to function Daftar_paket::by_id_rup(), 0 passed in C:\laragon\www\jmto-eproc\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 388
ERROR - 2024-01-12 01:42:11 --> Severity: error --> Exception: Cannot use object of type CI_DB_mysqli_result as array C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 1836
ERROR - 2024-01-12 01:42:11 --> Severity: error --> Exception: Cannot use object of type CI_DB_mysqli_result as array C:\laragon\www\jmto-eproc\application\models\M_panitia\M_panitia.php 1836
ERROR - 2024-01-12 13:48:35 --> 404 Page Not Found: panitia/info_tender/Informasi_tender_umum_pra_2_file/get_evaluasi_ba_teknis
ERROR - 2024-01-12 13:48:44 --> 404 Page Not Found: panitia/info_tender/Informasi_tender_umum_pra_2_file/get_evaluasi_ba_teknis
