<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2024-01-12 09:32:16 --> Severity: error --> Exception: Call to undefined method CI_DB_mysqli_driver::where_not() C:\xampp\htdocs\jmto-eproc-fix\application\models\M_panitia\M_panitia.php 1380
ERROR - 2024-01-12 09:32:41 --> Severity: error --> Exception: Call to undefined method CI_DB_mysqli_driver::where_not() C:\xampp\htdocs\jmto-eproc-fix\application\models\M_panitia\M_panitia.php 1380
ERROR - 2024-01-12 09:33:02 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'NOT IN(100)
ORDER BY `tbl_vendor_mengikuti_paket`.`ev_penawaran_akhir` DESC' at line 5 - Invalid query: SELECT *
FROM `tbl_vendor_mengikuti_paket`
JOIN `tbl_vendor` ON `tbl_vendor_mengikuti_paket`.`id_vendor` = `tbl_vendor`.`id_vendor`
WHERE `tbl_vendor_mengikuti_paket`.`id_rup` = '205'
AND `tbl_vendor_mengikuti_paket`.`nilai_penawaran` >= NOT IN(100)
ORDER BY `tbl_vendor_mengikuti_paket`.`ev_penawaran_akhir` DESC
ERROR - 2024-01-12 09:33:29 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'NOT IN(100)
ORDER BY `tbl_vendor_mengikuti_paket`.`ev_penawaran_akhir` DESC' at line 5 - Invalid query: SELECT *
FROM `tbl_vendor_mengikuti_paket`
JOIN `tbl_vendor` ON `tbl_vendor_mengikuti_paket`.`id_vendor` = `tbl_vendor`.`id_vendor`
WHERE `tbl_vendor_mengikuti_paket`.`id_rup` = '205'
AND `tbl_vendor_mengikuti_paket`.`ev_penawaran_akhir` >= NOT IN(100)
ORDER BY `tbl_vendor_mengikuti_paket`.`ev_penawaran_akhir` DESC
ERROR - 2024-01-12 09:34:40 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'NOT IN(100)
ORDER BY `tbl_vendor_mengikuti_paket`.`ev_penawaran_akhir` DESC' at line 5 - Invalid query: SELECT *
FROM `tbl_vendor_mengikuti_paket`
JOIN `tbl_vendor` ON `tbl_vendor_mengikuti_paket`.`id_vendor` = `tbl_vendor`.`id_vendor`
WHERE `tbl_vendor_mengikuti_paket`.`id_rup` = '205'
AND `tbl_vendor_mengikuti_paket`.`ev_penawaran_akhir` >= NOT IN(100)
ORDER BY `tbl_vendor_mengikuti_paket`.`ev_penawaran_akhir` DESC
ERROR - 2024-01-12 04:01:26 --> Severity: error --> Exception: syntax error, unexpected '$ev_hea_tkdn' (T_VARIABLE) C:\xampp\htdocs\jmto-eproc-fix\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 772
ERROR - 2024-01-12 13:48:40 --> 404 Page Not Found: panitia/info_tender/Informasi_tender_umum_pra_2_file/get_evaluasi_ba_teknis
ERROR - 2024-01-12 13:48:54 --> 404 Page Not Found: panitia/info_tender/Informasi_tender_umum_pra_2_file/get_evaluasi_ba_teknis
ERROR - 2024-01-12 13:49:06 --> 404 Page Not Found: panitia/info_tender/Informasi_tender_umum_pra_2_file/get_evaluasi_ba_teknis
ERROR - 2024-01-12 14:53:19 --> Query error: MySQL server has gone away - Invalid query: SELECT *
FROM `tbl_rup`
WHERE `tbl_rup`.`id_rup` = '205'
ERROR - 2024-01-12 15:51:36 --> Severity: error --> Exception: Too few arguments to function Daftar_paket::by_id_rup(), 0 passed in C:\xampp\htdocs\jmto-eproc-fix\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\xampp\htdocs\jmto-eproc-fix\application\controllers\panitia\daftar_paket\Daftar_paket.php 388
ERROR - 2024-01-12 16:21:55 --> Query error: MySQL server has gone away - Invalid query: SELECT *
FROM `tbl_rup`
WHERE `tbl_rup`.`id_rup` = '205'
ERROR - 2024-01-12 16:21:55 --> Query error: MySQL server has gone away - Invalid query: SELECT *
FROM `tbl_rup`
LEFT JOIN `tbl_departemen` ON `tbl_rup`.`id_departemen` = `tbl_departemen`.`id_departemen`
LEFT JOIN `tbl_jadwal_tender` ON `tbl_rup`.`id_jadwal_tender` = `tbl_jadwal_tender`.`id_jadwal_tender`
LEFT JOIN `tbl_section` ON `tbl_rup`.`id_section` = `tbl_section`.`id_section`
LEFT JOIN `tbl_rkap` ON `tbl_rup`.`id_rkap` = `tbl_rkap`.`id_rkap`
LEFT JOIN `tbl_provinsi` ON `tbl_rup`.`id_provinsi` = `tbl_provinsi`.`id_provinsi`
LEFT JOIN `tbl_kabupaten` ON `tbl_rup`.`id_kabupaten` = `tbl_kabupaten`.`id_kabupaten`
LEFT JOIN `tbl_jenis_pengadaan` ON `tbl_rup`.`id_jenis_pengadaan` = `tbl_jenis_pengadaan`.`id_jenis_pengadaan`
LEFT JOIN `tbl_metode_pengadaan` ON `tbl_rup`.`id_metode_pengadaan` = `tbl_metode_pengadaan`.`id_metode_pengadaan`
LEFT JOIN `tbl_jenis_anggaran` ON `tbl_rup`.`id_jenis_anggaran` = `tbl_jenis_anggaran`.`id_jenis_anggaran`
LEFT JOIN `mst_ruas` ON `tbl_rup`.`id_ruas` = `mst_ruas`.`id_ruas`
WHERE `id_url_rup` = '7d2aec7ff9a940e8be2eaeefabac54bf'
ERROR - 2024-01-12 16:21:56 --> Query error: MySQL server has gone away - Invalid query: SELECT *
FROM `tbl_vendor_mengikuti_paket`
LEFT JOIN `tbl_vendor` ON `tbl_vendor_mengikuti_paket`.`id_vendor` = `tbl_vendor`.`id_vendor`
WHERE `tbl_vendor_mengikuti_paket`.`id_rup` = '205'
AND `tbl_vendor_mengikuti_paket`.`sts_mengikuti_paket` = 1
ORDER BY `tbl_vendor_mengikuti_paket`.`id_rup` DESC
 LIMIT 10
ERROR - 2024-01-12 16:32:24 --> Query error: MySQL server has gone away - Invalid query: SELECT *
FROM `tbl_rup`
LEFT JOIN `tbl_departemen` ON `tbl_rup`.`id_departemen` = `tbl_departemen`.`id_departemen`
LEFT JOIN `tbl_jadwal_tender` ON `tbl_rup`.`id_jadwal_tender` = `tbl_jadwal_tender`.`id_jadwal_tender`
LEFT JOIN `tbl_section` ON `tbl_rup`.`id_section` = `tbl_section`.`id_section`
LEFT JOIN `tbl_rkap` ON `tbl_rup`.`id_rkap` = `tbl_rkap`.`id_rkap`
LEFT JOIN `tbl_provinsi` ON `tbl_rup`.`id_provinsi` = `tbl_provinsi`.`id_provinsi`
LEFT JOIN `tbl_kabupaten` ON `tbl_rup`.`id_kabupaten` = `tbl_kabupaten`.`id_kabupaten`
LEFT JOIN `tbl_jenis_pengadaan` ON `tbl_rup`.`id_jenis_pengadaan` = `tbl_jenis_pengadaan`.`id_jenis_pengadaan`
LEFT JOIN `tbl_metode_pengadaan` ON `tbl_rup`.`id_metode_pengadaan` = `tbl_metode_pengadaan`.`id_metode_pengadaan`
LEFT JOIN `tbl_jenis_anggaran` ON `tbl_rup`.`id_jenis_anggaran` = `tbl_jenis_anggaran`.`id_jenis_anggaran`
LEFT JOIN `mst_ruas` ON `tbl_rup`.`id_ruas` = `mst_ruas`.`id_ruas`
WHERE `id_url_rup` = '7d2aec7ff9a940e8be2eaeefabac54bf'
ERROR - 2024-01-12 16:32:24 --> Query error: MySQL server has gone away - Invalid query: SELECT *
FROM `tbl_vendor_mengikuti_paket`
LEFT JOIN `tbl_vendor` ON `tbl_vendor_mengikuti_paket`.`id_vendor` = `tbl_vendor`.`id_vendor`
WHERE `tbl_vendor_mengikuti_paket`.`id_rup` = '205'
AND `tbl_vendor_mengikuti_paket`.`sts_mengikuti_paket` = 1
ORDER BY `tbl_vendor_mengikuti_paket`.`id_rup` DESC
 LIMIT 10
ERROR - 2024-01-12 16:32:24 --> Query error: MySQL server has gone away - Invalid query: SELECT *
FROM `tbl_vendor_mengikuti_paket`
LEFT JOIN `tbl_rup` ON `tbl_vendor_mengikuti_paket`.`id_rup` = `tbl_rup`.`id_rup`
LEFT JOIN `tbl_vendor` ON `tbl_vendor_mengikuti_paket`.`id_vendor` = `tbl_vendor`.`id_vendor`
WHERE `tbl_vendor_mengikuti_paket`.`id_rup` = '205'
AND `tbl_vendor_mengikuti_paket`.`sts_mengikuti_paket` = 1
ORDER BY `tbl_rup`.`id_rup` DESC
 LIMIT 10
ERROR - 2024-01-12 16:32:24 --> Query error: MySQL server has gone away - Invalid query: SELECT *
FROM `tbl_vendor_mengikuti_paket`
LEFT JOIN `tbl_rup` ON `tbl_vendor_mengikuti_paket`.`id_rup` = `tbl_rup`.`id_rup`
LEFT JOIN `tbl_vendor` ON `tbl_vendor_mengikuti_paket`.`id_vendor` = `tbl_vendor`.`id_vendor`
WHERE `tbl_vendor_mengikuti_paket`.`id_rup` = '205'
AND `tbl_vendor_mengikuti_paket`.`sts_mengikuti_paket` = 1
ORDER BY `tbl_rup`.`id_rup` DESC
 LIMIT 10
ERROR - 2024-01-12 16:33:16 --> Severity: error --> Exception: Too few arguments to function Daftar_paket::by_id_rup(), 0 passed in C:\xampp\htdocs\jmto-eproc-fix\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\xampp\htdocs\jmto-eproc-fix\application\controllers\panitia\daftar_paket\Daftar_paket.php 388
ERROR - 2024-01-12 16:35:06 --> Severity: error --> Exception: Too few arguments to function Daftar_paket::by_id_rup(), 0 passed in C:\xampp\htdocs\jmto-eproc-fix\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\xampp\htdocs\jmto-eproc-fix\application\controllers\panitia\daftar_paket\Daftar_paket.php 388
ERROR - 2024-01-12 16:37:56 --> Query error: MySQL server has gone away - Invalid query: SELECT *
FROM `tbl_rup`
LEFT JOIN `tbl_departemen` ON `tbl_rup`.`id_departemen` = `tbl_departemen`.`id_departemen`
LEFT JOIN `tbl_jadwal_tender` ON `tbl_rup`.`id_jadwal_tender` = `tbl_jadwal_tender`.`id_jadwal_tender`
LEFT JOIN `tbl_section` ON `tbl_rup`.`id_section` = `tbl_section`.`id_section`
LEFT JOIN `tbl_rkap` ON `tbl_rup`.`id_rkap` = `tbl_rkap`.`id_rkap`
LEFT JOIN `tbl_provinsi` ON `tbl_rup`.`id_provinsi` = `tbl_provinsi`.`id_provinsi`
LEFT JOIN `tbl_kabupaten` ON `tbl_rup`.`id_kabupaten` = `tbl_kabupaten`.`id_kabupaten`
LEFT JOIN `tbl_jenis_pengadaan` ON `tbl_rup`.`id_jenis_pengadaan` = `tbl_jenis_pengadaan`.`id_jenis_pengadaan`
LEFT JOIN `tbl_metode_pengadaan` ON `tbl_rup`.`id_metode_pengadaan` = `tbl_metode_pengadaan`.`id_metode_pengadaan`
LEFT JOIN `tbl_jenis_anggaran` ON `tbl_rup`.`id_jenis_anggaran` = `tbl_jenis_anggaran`.`id_jenis_anggaran`
LEFT JOIN `mst_ruas` ON `tbl_rup`.`id_ruas` = `mst_ruas`.`id_ruas`
WHERE `id_url_rup` = '7d2aec7ff9a940e8be2eaeefabac54bf'
ERROR - 2024-01-12 16:37:56 --> Query error: MySQL server has gone away - Invalid query: SELECT *
FROM `tbl_rup`
WHERE `tbl_rup`.`id_rup` = '205'
ERROR - 2024-01-12 16:37:56 --> Query error: MySQL server has gone away - Invalid query: SELECT *
FROM `tbl_ba_teknis_detail`
WHERE `id_rup` = '205'
ERROR - 2024-01-12 16:51:46 --> Query error: MySQL server has gone away - Invalid query: SELECT *
FROM `tbl_ba_teknis_detail`
WHERE `id_rup` = '205'
ERROR - 2024-01-12 16:51:46 --> Query error: MySQL server has gone away - Invalid query: SELECT *
FROM `tbl_rup`
LEFT JOIN `tbl_departemen` ON `tbl_rup`.`id_departemen` = `tbl_departemen`.`id_departemen`
LEFT JOIN `tbl_jadwal_tender` ON `tbl_rup`.`id_jadwal_tender` = `tbl_jadwal_tender`.`id_jadwal_tender`
LEFT JOIN `tbl_section` ON `tbl_rup`.`id_section` = `tbl_section`.`id_section`
LEFT JOIN `tbl_rkap` ON `tbl_rup`.`id_rkap` = `tbl_rkap`.`id_rkap`
LEFT JOIN `tbl_provinsi` ON `tbl_rup`.`id_provinsi` = `tbl_provinsi`.`id_provinsi`
LEFT JOIN `tbl_kabupaten` ON `tbl_rup`.`id_kabupaten` = `tbl_kabupaten`.`id_kabupaten`
LEFT JOIN `tbl_jenis_pengadaan` ON `tbl_rup`.`id_jenis_pengadaan` = `tbl_jenis_pengadaan`.`id_jenis_pengadaan`
LEFT JOIN `tbl_metode_pengadaan` ON `tbl_rup`.`id_metode_pengadaan` = `tbl_metode_pengadaan`.`id_metode_pengadaan`
LEFT JOIN `tbl_jenis_anggaran` ON `tbl_rup`.`id_jenis_anggaran` = `tbl_jenis_anggaran`.`id_jenis_anggaran`
LEFT JOIN `mst_ruas` ON `tbl_rup`.`id_ruas` = `mst_ruas`.`id_ruas`
WHERE `id_url_rup` = '7d2aec7ff9a940e8be2eaeefabac54bf'
ERROR - 2024-01-12 16:51:46 --> Query error: MySQL server has gone away - Invalid query: SELECT *
FROM `tbl_vendor_mengikuti_paket`
LEFT JOIN `tbl_vendor` ON `tbl_vendor_mengikuti_paket`.`id_vendor` = `tbl_vendor`.`id_vendor`
WHERE `tbl_vendor_mengikuti_paket`.`id_rup` = '205'
AND `tbl_vendor_mengikuti_paket`.`sts_mengikuti_paket` = 1
ORDER BY `tbl_vendor_mengikuti_paket`.`id_rup` DESC
 LIMIT 10
ERROR - 2024-01-12 16:56:36 --> Query error: MySQL server has gone away - Invalid query: SELECT *
FROM `tbl_rup`
LEFT JOIN `tbl_departemen` ON `tbl_rup`.`id_departemen` = `tbl_departemen`.`id_departemen`
LEFT JOIN `tbl_jadwal_tender` ON `tbl_rup`.`id_jadwal_tender` = `tbl_jadwal_tender`.`id_jadwal_tender`
LEFT JOIN `tbl_section` ON `tbl_rup`.`id_section` = `tbl_section`.`id_section`
LEFT JOIN `tbl_rkap` ON `tbl_rup`.`id_rkap` = `tbl_rkap`.`id_rkap`
LEFT JOIN `tbl_provinsi` ON `tbl_rup`.`id_provinsi` = `tbl_provinsi`.`id_provinsi`
LEFT JOIN `tbl_kabupaten` ON `tbl_rup`.`id_kabupaten` = `tbl_kabupaten`.`id_kabupaten`
LEFT JOIN `tbl_jenis_pengadaan` ON `tbl_rup`.`id_jenis_pengadaan` = `tbl_jenis_pengadaan`.`id_jenis_pengadaan`
LEFT JOIN `tbl_metode_pengadaan` ON `tbl_rup`.`id_metode_pengadaan` = `tbl_metode_pengadaan`.`id_metode_pengadaan`
LEFT JOIN `tbl_jenis_anggaran` ON `tbl_rup`.`id_jenis_anggaran` = `tbl_jenis_anggaran`.`id_jenis_anggaran`
LEFT JOIN `mst_ruas` ON `tbl_rup`.`id_ruas` = `mst_ruas`.`id_ruas`
WHERE `id_url_rup` = '7d2aec7ff9a940e8be2eaeefabac54bf'
ERROR - 2024-01-12 16:56:36 --> Query error: MySQL server has gone away - Invalid query: SELECT *
FROM `tbl_rup`
WHERE `tbl_rup`.`id_rup` = '205'
ERROR - 2024-01-12 16:56:37 --> Query error: MySQL server has gone away - Invalid query: SELECT *
FROM `tbl_ba_tender`
WHERE `tbl_ba_tender`.`id_rup` = '205'
ERROR - 2024-01-12 16:56:37 --> Query error: MySQL server has gone away - Invalid query: SELECT *
FROM `tbl_ba_teknis_detail`
WHERE `id_rup` = '205'
ERROR - 2024-01-12 17:17:44 --> Query error: MySQL server has gone away - Invalid query: SELECT *
FROM `tbl_rup`
LEFT JOIN `tbl_departemen` ON `tbl_rup`.`id_departemen` = `tbl_departemen`.`id_departemen`
LEFT JOIN `tbl_jadwal_tender` ON `tbl_rup`.`id_jadwal_tender` = `tbl_jadwal_tender`.`id_jadwal_tender`
LEFT JOIN `tbl_section` ON `tbl_rup`.`id_section` = `tbl_section`.`id_section`
LEFT JOIN `tbl_rkap` ON `tbl_rup`.`id_rkap` = `tbl_rkap`.`id_rkap`
LEFT JOIN `tbl_provinsi` ON `tbl_rup`.`id_provinsi` = `tbl_provinsi`.`id_provinsi`
LEFT JOIN `tbl_kabupaten` ON `tbl_rup`.`id_kabupaten` = `tbl_kabupaten`.`id_kabupaten`
LEFT JOIN `tbl_jenis_pengadaan` ON `tbl_rup`.`id_jenis_pengadaan` = `tbl_jenis_pengadaan`.`id_jenis_pengadaan`
LEFT JOIN `tbl_metode_pengadaan` ON `tbl_rup`.`id_metode_pengadaan` = `tbl_metode_pengadaan`.`id_metode_pengadaan`
LEFT JOIN `tbl_jenis_anggaran` ON `tbl_rup`.`id_jenis_anggaran` = `tbl_jenis_anggaran`.`id_jenis_anggaran`
LEFT JOIN `mst_ruas` ON `tbl_rup`.`id_ruas` = `mst_ruas`.`id_ruas`
WHERE `id_url_rup` = '7d2aec7ff9a940e8be2eaeefabac54bf'
ERROR - 2024-01-12 17:17:45 --> Query error: MySQL server has gone away - Invalid query: SELECT *
FROM `tbl_ba_teknis_detail`
WHERE `id_rup` = '205'
ERROR - 2024-01-12 17:17:45 --> Query error: MySQL server has gone away - Invalid query: SELECT *
FROM `tbl_ba_tender`
WHERE `tbl_ba_tender`.`id_rup` = '205'
ERROR - 2024-01-12 17:17:45 --> Query error: MySQL server has gone away - Invalid query: SELECT *
FROM `tbl_rup`
WHERE `tbl_rup`.`id_rup` = '205'
ERROR - 2024-01-12 17:17:45 --> Query error: MySQL server has gone away - Invalid query: SELECT *
FROM `tbl_rup`
LEFT JOIN `tbl_departemen` ON `tbl_rup`.`id_departemen` = `tbl_departemen`.`id_departemen`
LEFT JOIN `tbl_jadwal_tender` ON `tbl_rup`.`id_jadwal_tender` = `tbl_jadwal_tender`.`id_jadwal_tender`
LEFT JOIN `tbl_section` ON `tbl_rup`.`id_section` = `tbl_section`.`id_section`
LEFT JOIN `tbl_rkap` ON `tbl_rup`.`id_rkap` = `tbl_rkap`.`id_rkap`
LEFT JOIN `tbl_provinsi` ON `tbl_rup`.`id_provinsi` = `tbl_provinsi`.`id_provinsi`
LEFT JOIN `tbl_kabupaten` ON `tbl_rup`.`id_kabupaten` = `tbl_kabupaten`.`id_kabupaten`
LEFT JOIN `tbl_jenis_pengadaan` ON `tbl_rup`.`id_jenis_pengadaan` = `tbl_jenis_pengadaan`.`id_jenis_pengadaan`
LEFT JOIN `tbl_metode_pengadaan` ON `tbl_rup`.`id_metode_pengadaan` = `tbl_metode_pengadaan`.`id_metode_pengadaan`
LEFT JOIN `tbl_jenis_anggaran` ON `tbl_rup`.`id_jenis_anggaran` = `tbl_jenis_anggaran`.`id_jenis_anggaran`
LEFT JOIN `mst_ruas` ON `tbl_rup`.`id_ruas` = `mst_ruas`.`id_ruas`
WHERE `id_url_rup` = '7d2aec7ff9a940e8be2eaeefabac54bf'
ERROR - 2024-01-12 17:18:11 --> Query error: MySQL server has gone away - Invalid query: SELECT *
FROM `tbl_vendor_mengikuti_paket`
LEFT JOIN `tbl_rup` ON `tbl_vendor_mengikuti_paket`.`id_rup` = `tbl_rup`.`id_rup`
LEFT JOIN `tbl_vendor` ON `tbl_vendor_mengikuti_paket`.`id_vendor` = `tbl_vendor`.`id_vendor`
WHERE `tbl_vendor_mengikuti_paket`.`id_rup` = '205'
AND `tbl_vendor_mengikuti_paket`.`sts_mengikuti_paket` = 1
ORDER BY `tbl_rup`.`id_rup` DESC
 LIMIT 10
ERROR - 2024-01-12 17:18:11 --> Query error: MySQL server has gone away - Invalid query: SELECT *
FROM `tbl_vendor_mengikuti_paket`
LEFT JOIN `tbl_vendor` ON `tbl_vendor_mengikuti_paket`.`id_vendor` = `tbl_vendor`.`id_vendor`
WHERE `tbl_vendor_mengikuti_paket`.`id_rup` = '205'
AND `tbl_vendor_mengikuti_paket`.`sts_mengikuti_paket` = 1
ORDER BY `tbl_vendor_mengikuti_paket`.`id_rup` DESC
 LIMIT 10
ERROR - 2024-01-12 17:18:11 --> Query error: MySQL server has gone away - Invalid query: SELECT *
FROM `tbl_vendor_mengikuti_paket`
LEFT JOIN `tbl_rup` ON `tbl_vendor_mengikuti_paket`.`id_rup` = `tbl_rup`.`id_rup`
LEFT JOIN `tbl_vendor` ON `tbl_vendor_mengikuti_paket`.`id_vendor` = `tbl_vendor`.`id_vendor`
WHERE `tbl_vendor_mengikuti_paket`.`id_rup` = '205'
AND `tbl_vendor_mengikuti_paket`.`sts_mengikuti_paket` = 1
ORDER BY `tbl_rup`.`id_rup` DESC
 LIMIT 10
ERROR - 2024-01-12 17:18:11 --> Query error: MySQL server has gone away - Invalid query: SELECT *
FROM `tbl_vendor_mengikuti_paket`
LEFT JOIN `tbl_rup` ON `tbl_vendor_mengikuti_paket`.`id_rup` = `tbl_rup`.`id_rup`
LEFT JOIN `tbl_vendor` ON `tbl_vendor_mengikuti_paket`.`id_vendor` = `tbl_vendor`.`id_vendor`
WHERE `tbl_vendor_mengikuti_paket`.`id_rup` = '205'
AND `tbl_vendor_mengikuti_paket`.`ev_keuangan` > 60
AND `tbl_vendor_mengikuti_paket`.`ev_teknis` > 60
ORDER BY `tbl_rup`.`id_rup` DESC
 LIMIT 10
ERROR - 2024-01-12 17:19:10 --> Query error: MySQL server has gone away - Invalid query: SELECT *
FROM `tbl_rup`
LEFT JOIN `tbl_departemen` ON `tbl_rup`.`id_departemen` = `tbl_departemen`.`id_departemen`
LEFT JOIN `tbl_jadwal_tender` ON `tbl_rup`.`id_jadwal_tender` = `tbl_jadwal_tender`.`id_jadwal_tender`
LEFT JOIN `tbl_section` ON `tbl_rup`.`id_section` = `tbl_section`.`id_section`
LEFT JOIN `tbl_rkap` ON `tbl_rup`.`id_rkap` = `tbl_rkap`.`id_rkap`
LEFT JOIN `tbl_provinsi` ON `tbl_rup`.`id_provinsi` = `tbl_provinsi`.`id_provinsi`
LEFT JOIN `tbl_kabupaten` ON `tbl_rup`.`id_kabupaten` = `tbl_kabupaten`.`id_kabupaten`
LEFT JOIN `tbl_jenis_pengadaan` ON `tbl_rup`.`id_jenis_pengadaan` = `tbl_jenis_pengadaan`.`id_jenis_pengadaan`
LEFT JOIN `tbl_metode_pengadaan` ON `tbl_rup`.`id_metode_pengadaan` = `tbl_metode_pengadaan`.`id_metode_pengadaan`
LEFT JOIN `tbl_jenis_anggaran` ON `tbl_rup`.`id_jenis_anggaran` = `tbl_jenis_anggaran`.`id_jenis_anggaran`
LEFT JOIN `mst_ruas` ON `tbl_rup`.`id_ruas` = `mst_ruas`.`id_ruas`
WHERE `id_url_rup` = '7d2aec7ff9a940e8be2eaeefabac54bf'
ERROR - 2024-01-12 17:19:10 --> Query error: MySQL server has gone away - Invalid query: SELECT *
FROM `tbl_rup`
LEFT JOIN `tbl_departemen` ON `tbl_rup`.`id_departemen` = `tbl_departemen`.`id_departemen`
LEFT JOIN `tbl_jadwal_tender` ON `tbl_rup`.`id_jadwal_tender` = `tbl_jadwal_tender`.`id_jadwal_tender`
LEFT JOIN `tbl_section` ON `tbl_rup`.`id_section` = `tbl_section`.`id_section`
LEFT JOIN `tbl_rkap` ON `tbl_rup`.`id_rkap` = `tbl_rkap`.`id_rkap`
LEFT JOIN `tbl_provinsi` ON `tbl_rup`.`id_provinsi` = `tbl_provinsi`.`id_provinsi`
LEFT JOIN `tbl_kabupaten` ON `tbl_rup`.`id_kabupaten` = `tbl_kabupaten`.`id_kabupaten`
LEFT JOIN `tbl_jenis_pengadaan` ON `tbl_rup`.`id_jenis_pengadaan` = `tbl_jenis_pengadaan`.`id_jenis_pengadaan`
LEFT JOIN `tbl_metode_pengadaan` ON `tbl_rup`.`id_metode_pengadaan` = `tbl_metode_pengadaan`.`id_metode_pengadaan`
LEFT JOIN `tbl_jenis_anggaran` ON `tbl_rup`.`id_jenis_anggaran` = `tbl_jenis_anggaran`.`id_jenis_anggaran`
LEFT JOIN `mst_ruas` ON `tbl_rup`.`id_ruas` = `mst_ruas`.`id_ruas`
WHERE `id_url_rup` = '7d2aec7ff9a940e8be2eaeefabac54bf'
ERROR - 2024-01-12 17:19:10 --> Query error: MySQL server has gone away - Invalid query: SELECT *
FROM `tbl_rup`
LEFT JOIN `tbl_departemen` ON `tbl_rup`.`id_departemen` = `tbl_departemen`.`id_departemen`
LEFT JOIN `tbl_jadwal_tender` ON `tbl_rup`.`id_jadwal_tender` = `tbl_jadwal_tender`.`id_jadwal_tender`
LEFT JOIN `tbl_section` ON `tbl_rup`.`id_section` = `tbl_section`.`id_section`
LEFT JOIN `tbl_rkap` ON `tbl_rup`.`id_rkap` = `tbl_rkap`.`id_rkap`
LEFT JOIN `tbl_provinsi` ON `tbl_rup`.`id_provinsi` = `tbl_provinsi`.`id_provinsi`
LEFT JOIN `tbl_kabupaten` ON `tbl_rup`.`id_kabupaten` = `tbl_kabupaten`.`id_kabupaten`
LEFT JOIN `tbl_jenis_pengadaan` ON `tbl_rup`.`id_jenis_pengadaan` = `tbl_jenis_pengadaan`.`id_jenis_pengadaan`
LEFT JOIN `tbl_metode_pengadaan` ON `tbl_rup`.`id_metode_pengadaan` = `tbl_metode_pengadaan`.`id_metode_pengadaan`
LEFT JOIN `tbl_jenis_anggaran` ON `tbl_rup`.`id_jenis_anggaran` = `tbl_jenis_anggaran`.`id_jenis_anggaran`
LEFT JOIN `mst_ruas` ON `tbl_rup`.`id_ruas` = `mst_ruas`.`id_ruas`
WHERE `id_url_rup` = '7d2aec7ff9a940e8be2eaeefabac54bf'
ERROR - 2024-01-12 17:19:10 --> Query error: MySQL server has gone away - Invalid query: SELECT *
FROM `tbl_rup`
LEFT JOIN `tbl_departemen` ON `tbl_rup`.`id_departemen` = `tbl_departemen`.`id_departemen`
LEFT JOIN `tbl_jadwal_tender` ON `tbl_rup`.`id_jadwal_tender` = `tbl_jadwal_tender`.`id_jadwal_tender`
LEFT JOIN `tbl_section` ON `tbl_rup`.`id_section` = `tbl_section`.`id_section`
LEFT JOIN `tbl_rkap` ON `tbl_rup`.`id_rkap` = `tbl_rkap`.`id_rkap`
LEFT JOIN `tbl_provinsi` ON `tbl_rup`.`id_provinsi` = `tbl_provinsi`.`id_provinsi`
LEFT JOIN `tbl_kabupaten` ON `tbl_rup`.`id_kabupaten` = `tbl_kabupaten`.`id_kabupaten`
LEFT JOIN `tbl_jenis_pengadaan` ON `tbl_rup`.`id_jenis_pengadaan` = `tbl_jenis_pengadaan`.`id_jenis_pengadaan`
LEFT JOIN `tbl_metode_pengadaan` ON `tbl_rup`.`id_metode_pengadaan` = `tbl_metode_pengadaan`.`id_metode_pengadaan`
LEFT JOIN `tbl_jenis_anggaran` ON `tbl_rup`.`id_jenis_anggaran` = `tbl_jenis_anggaran`.`id_jenis_anggaran`
LEFT JOIN `mst_ruas` ON `tbl_rup`.`id_ruas` = `mst_ruas`.`id_ruas`
WHERE `id_url_rup` = '7d2aec7ff9a940e8be2eaeefabac54bf'
