<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2024-01-12 09:32:16 --> Severity: error --> Exception: Call to undefined method CI_DB_mysqli_driver::where_not() C:\xampp\htdocs\jmto-eproc-fix\application\models\M_panitia\M_panitia.php 1380
ERROR - 2024-01-12 09:32:41 --> Severity: error --> Exception: Call to undefined method CI_DB_mysqli_driver::where_not() C:\xampp\htdocs\jmto-eproc-fix\application\models\M_panitia\M_panitia.php 1380
ERROR - 2024-01-12 09:33:02 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'NOT IN(100)
ORDER BY `tbl_vendor_mengikuti_paket`.`ev_penawaran_akhir` DESC' at line 5 - Invalid query: SELECT *
FROM `tbl_vendor_mengikuti_paket`
JOIN `tbl_vendor` ON `tbl_vendor_mengikuti_paket`.`id_vendor` = `tbl_vendor`.`id_vendor`
WHERE `tbl_vendor_mengikuti_paket`.`id_rup` = '205'
AND `tbl_vendor_mengikuti_paket`.`nilai_penawaran` >= NOT IN(100)
ORDER BY `tbl_vendor_mengikuti_paket`.`ev_penawaran_akhir` DESC
ERROR - 2024-01-12 09:33:29 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'NOT IN(100)
ORDER BY `tbl_vendor_mengikuti_paket`.`ev_penawaran_akhir` DESC' at line 5 - Invalid query: SELECT *
FROM `tbl_vendor_mengikuti_paket`
JOIN `tbl_vendor` ON `tbl_vendor_mengikuti_paket`.`id_vendor` = `tbl_vendor`.`id_vendor`
WHERE `tbl_vendor_mengikuti_paket`.`id_rup` = '205'
AND `tbl_vendor_mengikuti_paket`.`ev_penawaran_akhir` >= NOT IN(100)
ORDER BY `tbl_vendor_mengikuti_paket`.`ev_penawaran_akhir` DESC
ERROR - 2024-01-12 09:34:40 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'NOT IN(100)
ORDER BY `tbl_vendor_mengikuti_paket`.`ev_penawaran_akhir` DESC' at line 5 - Invalid query: SELECT *
FROM `tbl_vendor_mengikuti_paket`
JOIN `tbl_vendor` ON `tbl_vendor_mengikuti_paket`.`id_vendor` = `tbl_vendor`.`id_vendor`
WHERE `tbl_vendor_mengikuti_paket`.`id_rup` = '205'
AND `tbl_vendor_mengikuti_paket`.`ev_penawaran_akhir` >= NOT IN(100)
ORDER BY `tbl_vendor_mengikuti_paket`.`ev_penawaran_akhir` DESC
ERROR - 2024-01-12 04:01:26 --> Severity: error --> Exception: syntax error, unexpected '$ev_hea_tkdn' (T_VARIABLE) C:\xampp\htdocs\jmto-eproc-fix\application\controllers\panitia\info_tender\Informasi_tender_umum_pra_2_file.php 772
