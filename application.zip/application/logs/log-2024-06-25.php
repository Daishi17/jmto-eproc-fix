<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2024-06-25 01:15:18 --> Severity: Notice --> Trying to get property 'nip' of non-object C:\laragon\www\jmto-eproc\application\libraries\Role_login.php 21
ERROR - 2024-06-25 01:15:45 --> Severity: Notice --> Trying to get property 'nip' of non-object C:\laragon\www\jmto-eproc\application\libraries\Role_login.php 21
ERROR - 2024-06-25 01:16:24 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '`NULL`
AND `tbl_vendor_neraca_keuangan`.`tahun_selesai` < `IS` `NULL`
GROUP B...' at line 3 - Invalid query: SELECT *
FROM `tbl_vendor_neraca_keuangan`
WHERE `tbl_vendor_neraca_keuangan`.`tahun_mulai` > `IS` `NULL`
AND `tbl_vendor_neraca_keuangan`.`tahun_selesai` < `IS` `NULL`
GROUP BY `tbl_vendor_neraca_keuangan`.`id_vendor`
ERROR - 2024-06-25 01:21:30 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '`NULL`
AND `tbl_vendor_neraca_keuangan`.`tahun_selesai` < `IS` `NULL`
GROUP B...' at line 3 - Invalid query: SELECT *
FROM `tbl_vendor_neraca_keuangan`
WHERE `tbl_vendor_neraca_keuangan`.`tahun_mulai` > `IS` `NULL`
AND `tbl_vendor_neraca_keuangan`.`tahun_selesai` < `IS` `NULL`
GROUP BY `tbl_vendor_neraca_keuangan`.`id_vendor`
ERROR - 2024-06-25 01:27:57 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '`NULL`
AND `tbl_vendor_neraca_keuangan`.`tahun_selesai` < `IS` `NULL`
GROUP B...' at line 3 - Invalid query: SELECT *
FROM `tbl_vendor_neraca_keuangan`
WHERE `tbl_vendor_neraca_keuangan`.`tahun_mulai` > `IS` `NULL`
AND `tbl_vendor_neraca_keuangan`.`tahun_selesai` < `IS` `NULL`
GROUP BY `tbl_vendor_neraca_keuangan`.`id_vendor`
ERROR - 2024-06-25 01:29:51 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '`NULL`
AND `tbl_vendor_neraca_keuangan`.`tahun_selesai` < `IS` `NULL`
GROUP B...' at line 3 - Invalid query: SELECT *
FROM `tbl_vendor_neraca_keuangan`
WHERE `tbl_vendor_neraca_keuangan`.`tahun_mulai` > `IS` `NULL`
AND `tbl_vendor_neraca_keuangan`.`tahun_selesai` < `IS` `NULL`
GROUP BY `tbl_vendor_neraca_keuangan`.`id_vendor`
ERROR - 2024-06-25 01:30:24 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '`NULL`
AND `tbl_vendor_neraca_keuangan`.`tahun_selesai` < `IS` `NULL`
GROUP B...' at line 3 - Invalid query: SELECT *
FROM `tbl_vendor_neraca_keuangan`
WHERE `tbl_vendor_neraca_keuangan`.`tahun_mulai` > `IS` `NULL`
AND `tbl_vendor_neraca_keuangan`.`tahun_selesai` < `IS` `NULL`
GROUP BY `tbl_vendor_neraca_keuangan`.`id_vendor`
ERROR - 2024-06-25 01:32:20 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '`NULL`
AND `tbl_vendor_neraca_keuangan`.`tahun_selesai` < `IS` `NULL`
GROUP B...' at line 3 - Invalid query: SELECT *
FROM `tbl_vendor_neraca_keuangan`
WHERE `tbl_vendor_neraca_keuangan`.`tahun_mulai` > `IS` `NULL`
AND `tbl_vendor_neraca_keuangan`.`tahun_selesai` < `IS` `NULL`
GROUP BY `tbl_vendor_neraca_keuangan`.`id_vendor`
ERROR - 2024-06-25 01:33:22 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '`NULL`
AND `tbl_vendor_neraca_keuangan`.`tahun_selesai` < `IS` `NULL`
GROUP B...' at line 3 - Invalid query: SELECT *
FROM `tbl_vendor_neraca_keuangan`
WHERE `tbl_vendor_neraca_keuangan`.`tahun_mulai` > `IS` `NULL`
AND `tbl_vendor_neraca_keuangan`.`tahun_selesai` < `IS` `NULL`
GROUP BY `tbl_vendor_neraca_keuangan`.`id_vendor`
ERROR - 2024-06-25 01:34:22 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '`NULL`
AND `tbl_vendor_neraca_keuangan`.`tahun_selesai` < `IS` `NULL`
GROUP B...' at line 3 - Invalid query: SELECT *
FROM `tbl_vendor_neraca_keuangan`
WHERE `tbl_vendor_neraca_keuangan`.`tahun_mulai` > `IS` `NULL`
AND `tbl_vendor_neraca_keuangan`.`tahun_selesai` < `IS` `NULL`
GROUP BY `tbl_vendor_neraca_keuangan`.`id_vendor`
ERROR - 2024-06-25 01:35:37 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '`NULL`
AND `tbl_vendor_neraca_keuangan`.`tahun_selesai` < `IS` `NULL`
GROUP B...' at line 3 - Invalid query: SELECT *
FROM `tbl_vendor_neraca_keuangan`
WHERE `tbl_vendor_neraca_keuangan`.`tahun_mulai` > `IS` `NULL`
AND `tbl_vendor_neraca_keuangan`.`tahun_selesai` < `IS` `NULL`
GROUP BY `tbl_vendor_neraca_keuangan`.`id_vendor`
ERROR - 2024-06-25 01:38:30 --> Query error: Unknown column 'id_rup.id_rup' in 'where clause' - Invalid query: SELECT *
FROM `tbl_syratat_kbli_tender`
JOIN `tbl_kbli` ON `tbl_syratat_kbli_tender`.`id_kbli` = `tbl_kbli`.`id_kbli`
WHERE `id_rup`.`id_rup` = '16'
ERROR - 2024-06-25 01:38:44 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '`NULL`
AND `tbl_vendor_neraca_keuangan`.`tahun_selesai` < `IS` `NULL`
GROUP B...' at line 3 - Invalid query: SELECT *
FROM `tbl_vendor_neraca_keuangan`
WHERE `tbl_vendor_neraca_keuangan`.`tahun_mulai` > `IS` `NULL`
AND `tbl_vendor_neraca_keuangan`.`tahun_selesai` < `IS` `NULL`
GROUP BY `tbl_vendor_neraca_keuangan`.`id_vendor`
ERROR - 2024-06-25 01:39:20 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '`NULL`
AND `tbl_vendor_neraca_keuangan`.`tahun_selesai` < `IS` `NULL`
GROUP B...' at line 3 - Invalid query: SELECT *
FROM `tbl_vendor_neraca_keuangan`
WHERE `tbl_vendor_neraca_keuangan`.`tahun_mulai` > `IS` `NULL`
AND `tbl_vendor_neraca_keuangan`.`tahun_selesai` < `IS` `NULL`
GROUP BY `tbl_vendor_neraca_keuangan`.`id_vendor`
ERROR - 2024-06-25 01:40:04 --> Severity: error --> Exception: Too few arguments to function Daftar_paket::by_id_rup(), 0 passed in C:\laragon\www\jmto-eproc\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 388
ERROR - 2024-06-25 01:40:05 --> Severity: error --> Exception: Too few arguments to function Daftar_paket::by_id_rup(), 0 passed in C:\laragon\www\jmto-eproc\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 388
ERROR - 2024-06-25 01:41:16 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '`NULL`
AND `tbl_vendor_neraca_keuangan`.`tahun_selesai` < `IS` `NULL`
GROUP B...' at line 3 - Invalid query: SELECT *
FROM `tbl_vendor_neraca_keuangan`
WHERE `tbl_vendor_neraca_keuangan`.`tahun_mulai` > `IS` `NULL`
AND `tbl_vendor_neraca_keuangan`.`tahun_selesai` < `IS` `NULL`
GROUP BY `tbl_vendor_neraca_keuangan`.`id_vendor`
ERROR - 2024-06-25 01:47:07 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '`NULL`
AND `tbl_vendor_neraca_keuangan`.`tahun_selesai` < `IS` `NULL`
GROUP B...' at line 3 - Invalid query: SELECT *
FROM `tbl_vendor_neraca_keuangan`
WHERE `tbl_vendor_neraca_keuangan`.`tahun_mulai` > `IS` `NULL`
AND `tbl_vendor_neraca_keuangan`.`tahun_selesai` < `IS` `NULL`
GROUP BY `tbl_vendor_neraca_keuangan`.`id_vendor`
ERROR - 2024-06-25 01:51:53 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '`NULL`
AND `tbl_vendor_neraca_keuangan`.`tahun_selesai` < `IS` `NULL`
GROUP B...' at line 3 - Invalid query: SELECT *
FROM `tbl_vendor_neraca_keuangan`
WHERE `tbl_vendor_neraca_keuangan`.`tahun_mulai` > `IS` `NULL`
AND `tbl_vendor_neraca_keuangan`.`tahun_selesai` < `IS` `NULL`
GROUP BY `tbl_vendor_neraca_keuangan`.`id_vendor`
ERROR - 2024-06-25 01:52:40 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '`NULL`
AND `tbl_vendor_neraca_keuangan`.`tahun_selesai` < `IS` `NULL`
GROUP B...' at line 3 - Invalid query: SELECT *
FROM `tbl_vendor_neraca_keuangan`
WHERE `tbl_vendor_neraca_keuangan`.`tahun_mulai` > `IS` `NULL`
AND `tbl_vendor_neraca_keuangan`.`tahun_selesai` < `IS` `NULL`
GROUP BY `tbl_vendor_neraca_keuangan`.`id_vendor`
ERROR - 2024-06-25 01:53:25 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '`NULL`
AND `tbl_vendor_neraca_keuangan`.`tahun_selesai` < `IS` `NULL`
GROUP B...' at line 3 - Invalid query: SELECT *
FROM `tbl_vendor_neraca_keuangan`
WHERE `tbl_vendor_neraca_keuangan`.`tahun_mulai` > `IS` `NULL`
AND `tbl_vendor_neraca_keuangan`.`tahun_selesai` < `IS` `NULL`
GROUP BY `tbl_vendor_neraca_keuangan`.`id_vendor`
ERROR - 2024-06-25 01:55:08 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '`NULL`
AND `tbl_vendor_neraca_keuangan`.`tahun_selesai` < `IS` `NULL`
GROUP B...' at line 3 - Invalid query: SELECT *
FROM `tbl_vendor_neraca_keuangan`
WHERE `tbl_vendor_neraca_keuangan`.`tahun_mulai` > `IS` `NULL`
AND `tbl_vendor_neraca_keuangan`.`tahun_selesai` < `IS` `NULL`
GROUP BY `tbl_vendor_neraca_keuangan`.`id_vendor`
ERROR - 2024-06-25 01:56:16 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '`NULL`
AND `tbl_vendor_neraca_keuangan`.`tahun_selesai` < `IS` `NULL`
GROUP B...' at line 3 - Invalid query: SELECT *
FROM `tbl_vendor_neraca_keuangan`
WHERE `tbl_vendor_neraca_keuangan`.`tahun_mulai` > `IS` `NULL`
AND `tbl_vendor_neraca_keuangan`.`tahun_selesai` < `IS` `NULL`
GROUP BY `tbl_vendor_neraca_keuangan`.`id_vendor`
ERROR - 2024-06-25 01:59:51 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '`NULL`
AND `tbl_vendor_neraca_keuangan`.`tahun_selesai` < `IS` `NULL`
GROUP B...' at line 3 - Invalid query: SELECT *
FROM `tbl_vendor_neraca_keuangan`
WHERE `tbl_vendor_neraca_keuangan`.`tahun_mulai` > `IS` `NULL`
AND `tbl_vendor_neraca_keuangan`.`tahun_selesai` < `IS` `NULL`
GROUP BY `tbl_vendor_neraca_keuangan`.`id_vendor`
ERROR - 2024-06-25 02:00:07 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '`NULL`
AND `tbl_vendor_neraca_keuangan`.`tahun_selesai` < `IS` `NULL`
GROUP B...' at line 3 - Invalid query: SELECT *
FROM `tbl_vendor_neraca_keuangan`
WHERE `tbl_vendor_neraca_keuangan`.`tahun_mulai` > `IS` `NULL`
AND `tbl_vendor_neraca_keuangan`.`tahun_selesai` < `IS` `NULL`
GROUP BY `tbl_vendor_neraca_keuangan`.`id_vendor`
ERROR - 2024-06-25 02:08:24 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '`NULL`
AND `tbl_vendor_neraca_keuangan`.`tahun_selesai` < `IS` `NULL`
GROUP B...' at line 3 - Invalid query: SELECT *
FROM `tbl_vendor_neraca_keuangan`
WHERE `tbl_vendor_neraca_keuangan`.`tahun_mulai` > `IS` `NULL`
AND `tbl_vendor_neraca_keuangan`.`tahun_selesai` < `IS` `NULL`
GROUP BY `tbl_vendor_neraca_keuangan`.`id_vendor`
ERROR - 2024-06-25 02:12:09 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '`NULL`
AND `tbl_vendor_neraca_keuangan`.`tahun_selesai` < `IS` `NULL`
GROUP B...' at line 3 - Invalid query: SELECT *
FROM `tbl_vendor_neraca_keuangan`
WHERE `tbl_vendor_neraca_keuangan`.`tahun_mulai` > `IS` `NULL`
AND `tbl_vendor_neraca_keuangan`.`tahun_selesai` < `IS` `NULL`
GROUP BY `tbl_vendor_neraca_keuangan`.`id_vendor`
ERROR - 2024-06-25 04:15:53 --> 404 Page Not Found: Css/style.css.map
ERROR - 2024-06-25 04:15:53 --> 404 Page Not Found: Assets_landing/bootstrap.min.css.map
ERROR - 2024-06-25 04:15:53 --> 404 Page Not Found: Assets_landing/jarallax-video.min.js.map
ERROR - 2024-06-25 04:15:53 --> 404 Page Not Found: Assets_landing/jarallax.min.js.map
ERROR - 2024-06-25 04:16:49 --> 404 Page Not Found: Assets/img
ERROR - 2024-06-25 04:17:29 --> 404 Page Not Found: Assets/img
ERROR - 2024-06-25 04:18:19 --> 404 Page Not Found: Assets/img
ERROR - 2024-06-25 04:20:01 --> 404 Page Not Found: Assets/img
ERROR - 2024-06-25 04:20:12 --> 404 Page Not Found: Assets/img
ERROR - 2024-06-25 04:20:34 --> 404 Page Not Found: Assets/img
ERROR - 2024-06-25 04:20:58 --> 404 Page Not Found: Assets/img
ERROR - 2024-06-25 04:21:28 --> 404 Page Not Found: Assets/img
ERROR - 2024-06-25 04:21:43 --> 404 Page Not Found: Assets/img
ERROR - 2024-06-25 04:21:52 --> 404 Page Not Found: Assets/img
ERROR - 2024-06-25 04:22:03 --> 404 Page Not Found: Assets/img
ERROR - 2024-06-25 04:22:18 --> 404 Page Not Found: Assets/img
ERROR - 2024-06-25 04:22:21 --> 404 Page Not Found: Assets/img
ERROR - 2024-06-25 04:22:30 --> 404 Page Not Found: Assets/img
ERROR - 2024-06-25 04:22:37 --> 404 Page Not Found: Assets/img
ERROR - 2024-06-25 04:22:54 --> 404 Page Not Found: Assets/img
ERROR - 2024-06-25 07:43:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): A socket operation was attempted to an unreachable host.
 C:\laragon\www\jmto-eproc\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2024-06-25 07:43:01 --> Unable to connect to the database
