<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2024-06-09 10:50:22 --> Severity: Warning --> mysqli::real_connect(): (HY000/2006): MySQL server has gone away C:\laragon\www\jmto-eproc\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2024-06-09 10:50:22 --> Unable to connect to the database
ERROR - 2024-06-09 20:16:09 --> 404 Page Not Found: administrator/Laporan_realisasi_rup/get_data_jml_paket
ERROR - 2024-06-09 20:16:09 --> 404 Page Not Found: administrator/Laporan_realisasi_rup/get_data_jml_paket
ERROR - 2024-06-09 20:16:09 --> 404 Page Not Found: administrator/Laporan_realisasi_rup/get_data_jml_paket
ERROR - 2024-06-09 20:16:09 --> 404 Page Not Found: administrator/Laporan_realisasi_rup/get_data_jml_paket
ERROR - 2024-06-09 20:16:09 --> 404 Page Not Found: administrator/Laporan_realisasi_rup/get_data_jml_paket
ERROR - 2024-06-09 20:16:09 --> 404 Page Not Found: administrator/Laporan_realisasi_rup/get_data_jml_paket
ERROR - 2024-06-09 20:16:09 --> 404 Page Not Found: administrator/Laporan_realisasi_rup/get_data_jml_paket
ERROR - 2024-06-09 20:16:09 --> 404 Page Not Found: administrator/Laporan_realisasi_rup/get_data_jml_paket
ERROR - 2024-06-09 20:16:09 --> 404 Page Not Found: administrator/Laporan_realisasi_rup/get_data_jml_paket
ERROR - 2024-06-09 20:16:09 --> 404 Page Not Found: administrator/Laporan_realisasi_rup/get_data_jml_paket
ERROR - 2024-06-09 20:16:09 --> 404 Page Not Found: administrator/Laporan_realisasi_rup/get_data_jml_paket
ERROR - 2024-06-09 20:16:09 --> 404 Page Not Found: administrator/Laporan_realisasi_rup/get_data_jml_paket
ERROR - 2024-06-09 20:16:09 --> 404 Page Not Found: administrator/Laporan_realisasi_rup/get_data_jml_paket
ERROR - 2024-06-09 20:16:14 --> 404 Page Not Found: administrator/Laporan_realisasi_rup/get_data_jml_paket
ERROR - 2024-06-09 20:16:14 --> 404 Page Not Found: administrator/Laporan_realisasi_rup/get_data_jml_paket
ERROR - 2024-06-09 20:16:14 --> 404 Page Not Found: administrator/Laporan_realisasi_rup/get_data_jml_paket
ERROR - 2024-06-09 20:16:14 --> 404 Page Not Found: administrator/Laporan_realisasi_rup/get_data_jml_paket
ERROR - 2024-06-09 20:16:14 --> 404 Page Not Found: administrator/Laporan_realisasi_rup/get_data_jml_paket
ERROR - 2024-06-09 20:16:14 --> 404 Page Not Found: administrator/Laporan_realisasi_rup/get_data_jml_paket
ERROR - 2024-06-09 20:16:14 --> 404 Page Not Found: administrator/Laporan_realisasi_rup/get_data_jml_paket
ERROR - 2024-06-09 20:16:14 --> 404 Page Not Found: administrator/Laporan_realisasi_rup/get_data_jml_paket
ERROR - 2024-06-09 20:16:14 --> 404 Page Not Found: administrator/Laporan_realisasi_rup/get_data_jml_paket
ERROR - 2024-06-09 20:16:14 --> 404 Page Not Found: administrator/Laporan_realisasi_rup/get_data_jml_paket
ERROR - 2024-06-09 20:16:14 --> 404 Page Not Found: administrator/Laporan_realisasi_rup/get_data_jml_paket
ERROR - 2024-06-09 20:16:14 --> 404 Page Not Found: administrator/Laporan_realisasi_rup/get_data_jml_paket
ERROR - 2024-06-09 20:16:14 --> 404 Page Not Found: administrator/Laporan_realisasi_rup/get_data_jml_paket
ERROR - 2024-06-09 20:29:06 --> Severity: error --> Exception: Call to undefined method M_laporan_realisasi::jml_pengadaan_juksung_tw2() C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_realisasi_rup.php 84
ERROR - 2024-06-09 20:29:06 --> Severity: error --> Exception: Call to undefined method M_laporan_realisasi::jml_pengadaan_juksung_tw2() C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_realisasi_rup.php 84
ERROR - 2024-06-09 20:29:06 --> Severity: error --> Exception: Call to undefined method M_laporan_realisasi::jml_pengadaan_juksung_tw2() C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_realisasi_rup.php 84
ERROR - 2024-06-09 20:29:06 --> Severity: error --> Exception: Call to undefined method M_laporan_realisasi::jml_pengadaan_juksung_tw2() C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_realisasi_rup.php 84
ERROR - 2024-06-09 20:29:06 --> Severity: error --> Exception: Call to undefined method M_laporan_realisasi::jml_pengadaan_juksung_tw2() C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_realisasi_rup.php 84
ERROR - 2024-06-09 20:29:06 --> Severity: error --> Exception: Call to undefined method M_laporan_realisasi::jml_pengadaan_juksung_tw2() C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_realisasi_rup.php 84
ERROR - 2024-06-09 20:29:07 --> Severity: error --> Exception: Call to undefined method M_laporan_realisasi::jml_pengadaan_juksung_tw2() C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_realisasi_rup.php 84
ERROR - 2024-06-09 20:29:07 --> Severity: error --> Exception: Call to undefined method M_laporan_realisasi::jml_pengadaan_juksung_tw2() C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_realisasi_rup.php 84
ERROR - 2024-06-09 20:29:07 --> Severity: error --> Exception: Call to undefined method M_laporan_realisasi::jml_pengadaan_juksung_tw2() C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_realisasi_rup.php 84
ERROR - 2024-06-09 20:29:07 --> Severity: error --> Exception: Call to undefined method M_laporan_realisasi::jml_pengadaan_juksung_tw2() C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_realisasi_rup.php 84
ERROR - 2024-06-09 20:29:07 --> Severity: error --> Exception: Call to undefined method M_laporan_realisasi::jml_pengadaan_juksung_tw2() C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_realisasi_rup.php 84
ERROR - 2024-06-09 20:29:07 --> Severity: error --> Exception: Call to undefined method M_laporan_realisasi::jml_pengadaan_juksung_tw2() C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_realisasi_rup.php 84
ERROR - 2024-06-09 20:29:07 --> Severity: error --> Exception: Call to undefined method M_laporan_realisasi::jml_pengadaan_juksung_tw2() C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_realisasi_rup.php 84
ERROR - 2024-06-09 20:29:14 --> Severity: error --> Exception: Call to undefined method M_laporan_realisasi::jml_pengadaan_juksung_tw2() C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_realisasi_rup.php 84
ERROR - 2024-06-09 20:29:14 --> Severity: error --> Exception: Call to undefined method M_laporan_realisasi::jml_pengadaan_juksung_tw2() C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_realisasi_rup.php 84
ERROR - 2024-06-09 20:29:14 --> Severity: error --> Exception: Call to undefined method M_laporan_realisasi::jml_pengadaan_juksung_tw2() C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_realisasi_rup.php 84
ERROR - 2024-06-09 20:29:15 --> Severity: error --> Exception: Call to undefined method M_laporan_realisasi::jml_pengadaan_juksung_tw2() C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_realisasi_rup.php 84
ERROR - 2024-06-09 20:29:15 --> Severity: error --> Exception: Call to undefined method M_laporan_realisasi::jml_pengadaan_juksung_tw2() C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_realisasi_rup.php 84
ERROR - 2024-06-09 20:29:15 --> Severity: error --> Exception: Call to undefined method M_laporan_realisasi::jml_pengadaan_juksung_tw2() C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_realisasi_rup.php 84
ERROR - 2024-06-09 20:29:15 --> Severity: error --> Exception: Call to undefined method M_laporan_realisasi::jml_pengadaan_juksung_tw2() C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_realisasi_rup.php 84
ERROR - 2024-06-09 20:29:15 --> Severity: error --> Exception: Call to undefined method M_laporan_realisasi::jml_pengadaan_juksung_tw2() C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_realisasi_rup.php 84
ERROR - 2024-06-09 20:29:15 --> Severity: error --> Exception: Call to undefined method M_laporan_realisasi::jml_pengadaan_juksung_tw2() C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_realisasi_rup.php 84
ERROR - 2024-06-09 20:29:15 --> Severity: error --> Exception: Call to undefined method M_laporan_realisasi::jml_pengadaan_juksung_tw2() C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_realisasi_rup.php 84
ERROR - 2024-06-09 20:29:15 --> Severity: error --> Exception: Call to undefined method M_laporan_realisasi::jml_pengadaan_juksung_tw2() C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_realisasi_rup.php 84
ERROR - 2024-06-09 20:29:15 --> Severity: error --> Exception: Call to undefined method M_laporan_realisasi::jml_pengadaan_juksung_tw2() C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_realisasi_rup.php 84
ERROR - 2024-06-09 20:29:15 --> Severity: error --> Exception: Call to undefined method M_laporan_realisasi::jml_pengadaan_juksung_tw2() C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_realisasi_rup.php 84
