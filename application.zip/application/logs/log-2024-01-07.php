<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2024-01-07 16:19:28 --> Severity: error --> Exception: Too few arguments to function Daftar_paket::by_id_rup(), 0 passed in C:\xampp\htdocs\jmto-eproc-fix\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\xampp\htdocs\jmto-eproc-fix\application\controllers\panitia\daftar_paket\Daftar_paket.php 388
ERROR - 2024-01-07 16:20:32 --> Severity: error --> Exception: Too few arguments to function Daftar_paket::by_id_rup(), 0 passed in C:\xampp\htdocs\jmto-eproc-fix\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\xampp\htdocs\jmto-eproc-fix\application\controllers\panitia\daftar_paket\Daftar_paket.php 388
ERROR - 2024-01-07 16:27:30 --> Severity: error --> Exception: Too few arguments to function Daftar_paket::by_id_rup(), 0 passed in C:\xampp\htdocs\jmto-eproc-fix\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\xampp\htdocs\jmto-eproc-fix\application\controllers\panitia\daftar_paket\Daftar_paket.php 388
ERROR - 2024-01-07 16:31:55 --> Severity: error --> Exception: Too few arguments to function Daftar_paket::by_id_rup(), 0 passed in C:\xampp\htdocs\jmto-eproc-fix\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\xampp\htdocs\jmto-eproc-fix\application\controllers\panitia\daftar_paket\Daftar_paket.php 388
ERROR - 2024-01-07 18:48:54 --> Query error: Unknown column 'tbl_rup.sts_paket_panitia' in 'where clause' - Invalid query: SELECT *
FROM `tbl_rup`
LEFT JOIN `tbl_panitia` ON `tbl_rup`.`id_rup` = `tbl_panitia`.`id_rup`
LEFT JOIN `tbl_departemen` ON `tbl_rup`.`id_departemen` = `tbl_departemen`.`id_departemen`
LEFT JOIN `tbl_section` ON `tbl_rup`.`id_section` = `tbl_section`.`id_section`
LEFT JOIN `tbl_rkap` ON `tbl_rup`.`id_rkap` = `tbl_rkap`.`id_rkap`
LEFT JOIN `tbl_provinsi` ON `tbl_rup`.`id_provinsi` = `tbl_provinsi`.`id_provinsi`
LEFT JOIN `tbl_kabupaten` ON `tbl_rup`.`id_kabupaten` = `tbl_kabupaten`.`id_kabupaten`
LEFT JOIN `tbl_jenis_pengadaan` ON `tbl_rup`.`id_jenis_pengadaan` = `tbl_jenis_pengadaan`.`id_jenis_pengadaan`
LEFT JOIN `tbl_metode_pengadaan` ON `tbl_rup`.`id_metode_pengadaan` = `tbl_metode_pengadaan`.`id_metode_pengadaan`
LEFT JOIN `tbl_jenis_anggaran` ON `tbl_rup`.`id_jenis_anggaran` = `tbl_jenis_anggaran`.`id_jenis_anggaran`
LEFT JOIN `mst_ruas` ON `tbl_rup`.`id_ruas` = `mst_ruas`.`id_ruas`
WHERE `tbl_rup`.`status_paket_diumumkan` = 1
AND `tbl_rup`.`sts_paket_panitia` = 2
AND `tbl_panitia`.`id_manajemen_user` = '26'
ERROR - 2024-01-07 19:34:36 --> Severity: error --> Exception: Too few arguments to function Daftar_paket::by_id_rup(), 0 passed in C:\xampp\htdocs\jmto-eproc-fix\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\xampp\htdocs\jmto-eproc-fix\application\controllers\panitia\daftar_paket\Daftar_paket.php 388
ERROR - 2024-01-07 19:35:39 --> Severity: error --> Exception: Too few arguments to function Daftar_paket::by_id_rup(), 0 passed in C:\xampp\htdocs\jmto-eproc-fix\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\xampp\htdocs\jmto-eproc-fix\application\controllers\panitia\daftar_paket\Daftar_paket.php 388
ERROR - 2024-01-07 19:48:01 --> Severity: error --> Exception: Too few arguments to function Daftar_paket::by_id_rup(), 0 passed in C:\xampp\htdocs\jmto-eproc-fix\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\xampp\htdocs\jmto-eproc-fix\application\controllers\panitia\daftar_paket\Daftar_paket.php 388
ERROR - 2024-01-07 21:26:18 --> 404 Page Not Found: panitia/info_tender/Informasi_tender_terbatas_pasca_1_file/get_row_vendor_negosiasi
ERROR - 2024-01-07 21:26:21 --> 404 Page Not Found: panitia/info_tender/Informasi_tender_terbatas_pasca_1_file/get_row_vendor_negosiasi
ERROR - 2024-01-07 21:26:23 --> 404 Page Not Found: panitia/info_tender/Informasi_tender_terbatas_pasca_1_file/get_row_vendor_negosiasi
ERROR - 2024-01-07 21:27:11 --> 404 Page Not Found: panitia/info_tender/Informasi_tender_terbatas_pasca_1_file/get_row_vendor_negosiasi
ERROR - 2024-01-07 21:27:13 --> 404 Page Not Found: panitia/info_tender/Informasi_tender_terbatas_pasca_1_file/get_row_vendor_negosiasi
ERROR - 2024-01-07 21:27:22 --> 404 Page Not Found: panitia/info_tender/Informasi_tender_terbatas_pasca_1_file/get_row_vendor_negosiasi
ERROR - 2024-01-07 21:27:29 --> 404 Page Not Found: panitia/info_tender/Informasi_tender_terbatas_pasca_1_file/get_row_vendor_negosiasi
ERROR - 2024-01-07 21:48:18 --> Severity: error --> Exception: Call to undefined method M_panitia::jumlah_peserta_negosiasi_teknis() C:\xampp\htdocs\jmto-eproc-fix\application\controllers\panitia\info_tender\Informasi_tender_terbatas_pasca_1_file.php 2514
ERROR - 2024-01-07 21:48:43 --> Severity: error --> Exception: Call to undefined method M_panitia::jumlah_peserta_negosiasi_teknis() C:\xampp\htdocs\jmto-eproc-fix\application\controllers\panitia\info_tender\Informasi_tender_terbatas_pasca_1_file.php 2514
