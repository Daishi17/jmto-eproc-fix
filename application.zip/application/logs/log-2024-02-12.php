<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2024-02-12 00:03:58 --> Severity: error --> Exception: Too few arguments to function Daftar_paket::by_id_rup(), 0 passed in C:\laragon\www\jmto-eproc\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 388
ERROR - 2024-02-12 00:04:54 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 2108
ERROR - 2024-02-12 00:04:54 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 2109
ERROR - 2024-02-12 00:05:01 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 2108
ERROR - 2024-02-12 00:05:01 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 2109
ERROR - 2024-02-12 00:09:11 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 2108
ERROR - 2024-02-12 00:09:11 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 2109
ERROR - 2024-02-12 00:20:35 --> Unable to connect to the database
ERROR - 2024-02-12 00:20:56 --> Unable to connect to the database
ERROR - 2024-02-12 00:21:34 --> Unable to connect to the database
ERROR - 2024-02-12 00:25:05 --> Severity: error --> Exception: Too few arguments to function Daftar_paket::by_id_rup(), 0 passed in C:\laragon\www\jmto-eproc\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 388
ERROR - 2024-02-12 00:25:31 --> Severity: error --> Exception: Too few arguments to function Daftar_paket::by_id_rup(), 0 passed in C:\laragon\www\jmto-eproc\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 388
ERROR - 2024-02-12 01:03:30 --> Severity: error --> Exception: Too few arguments to function Daftar_paket::by_id_rup(), 0 passed in C:\laragon\www\jmto-eproc\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 388
ERROR - 2024-02-12 01:08:26 --> Severity: error --> Exception: Too few arguments to function Daftar_paket::by_id_rup(), 0 passed in C:\laragon\www\jmto-eproc\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 388
ERROR - 2024-02-12 01:09:45 --> Severity: Notice --> Undefined variable: result_ruas_by_departemnt C:\laragon\www\jmto-eproc\application\views\administrator\sirup_rup\form_rup_edit.php 136
ERROR - 2024-02-12 01:09:45 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\jmto-eproc\application\views\administrator\sirup_rup\form_rup_edit.php 136
ERROR - 2024-02-12 01:12:12 --> Severity: Warning --> stream_socket_enable_crypto(): SSL operation failed with code 1. OpenSSL Error messages:
error:1408F10B:SSL routines:ssl3_get_record:wrong version number C:\laragon\www\jmto-eproc\system\libraries\Email.php 2098
ERROR - 2024-02-12 01:12:12 --> Severity: Notice --> Uninitialized string offset: 3 C:\laragon\www\jmto-eproc\system\libraries\Email.php 2317
ERROR - 2024-02-12 01:13:44 --> Severity: error --> Exception: Too few arguments to function Daftar_paket::by_id_rup(), 0 passed in C:\laragon\www\jmto-eproc\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 388
ERROR - 2024-02-12 01:15:14 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 2110
ERROR - 2024-02-12 01:15:14 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 2111
ERROR - 2024-02-12 01:15:14 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 2110
ERROR - 2024-02-12 01:15:14 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 2111
ERROR - 2024-02-12 01:15:16 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 2110
ERROR - 2024-02-12 01:15:16 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 2111
ERROR - 2024-02-12 01:15:16 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 2110
ERROR - 2024-02-12 01:15:16 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 2111
ERROR - 2024-02-12 01:15:27 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 2110
ERROR - 2024-02-12 01:15:27 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 2111
ERROR - 2024-02-12 01:15:27 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 2110
ERROR - 2024-02-12 01:15:27 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\post_jadwal\Post_jadwal.php 2111
ERROR - 2024-02-12 01:20:28 --> Severity: error --> Exception: Too few arguments to function Daftar_paket::by_id_rup(), 0 passed in C:\laragon\www\jmto-eproc\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 388
ERROR - 2024-02-12 01:20:42 --> Severity: error --> Exception: Too few arguments to function Daftar_paket::by_id_rup(), 0 passed in C:\laragon\www\jmto-eproc\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 388
ERROR - 2024-02-12 01:22:38 --> Severity: error --> Exception: Too few arguments to function Daftar_paket::by_id_rup(), 0 passed in C:\laragon\www\jmto-eproc\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 388
