<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2024-06-04 16:14:52 --> Severity: Notice --> Trying to get property 'nip' of non-object C:\laragon\www\jmto-eproc\application\libraries\Role_login.php 21
ERROR - 2024-06-04 09:32:05 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): A connection attempt failed because the connected party did not properly respond after a period of time, or established connection failed because connected host has failed to respond.
 C:\laragon\www\jmto-eproc\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2024-06-04 09:32:05 --> Unable to connect to the database
ERROR - 2024-06-04 09:32:06 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): A connection attempt failed because the connected party did not properly respond after a period of time, or established connection failed because connected host has failed to respond.
 C:\laragon\www\jmto-eproc\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2024-06-04 09:32:06 --> Unable to connect to the database
ERROR - 2024-06-04 09:32:06 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): A connection attempt failed because the connected party did not properly respond after a period of time, or established connection failed because connected host has failed to respond.
 C:\laragon\www\jmto-eproc\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2024-06-04 09:32:06 --> Unable to connect to the database
ERROR - 2024-06-04 09:32:06 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): A connection attempt failed because the connected party did not properly respond after a period of time, or established connection failed because connected host has failed to respond.
 C:\laragon\www\jmto-eproc\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2024-06-04 09:32:06 --> Unable to connect to the database
ERROR - 2024-06-04 09:32:07 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): A connection attempt failed because the connected party did not properly respond after a period of time, or established connection failed because connected host has failed to respond.
 C:\laragon\www\jmto-eproc\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2024-06-04 09:32:07 --> Unable to connect to the database
ERROR - 2024-06-04 09:32:21 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): A connection attempt failed because the connected party did not properly respond after a period of time, or established connection failed because connected host has failed to respond.
 C:\laragon\www\jmto-eproc\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2024-06-04 09:32:21 --> Unable to connect to the database
ERROR - 2024-06-04 18:33:16 --> Severity: Warning --> mysqli::set_charset(): Error executing query C:\laragon\www\jmto-eproc\system\database\drivers\mysqli\mysqli_driver.php 285
ERROR - 2024-06-04 18:33:16 --> Unable to set database connection charset: utf8
