<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2024-03-18 18:59:55 --> 404 Page Not Found: Css/style.css.map
<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2024-03-18 18:59:55 --> 404 Page Not Found: Assets_landing/bootstrap.min.css.map
ERROR - 2024-03-18 18:59:55 --> 404 Page Not Found: Assets_landing/jarallax.min.js.map
ERROR - 2024-03-18 18:59:55 --> 404 Page Not Found: Assets_landing/jarallax-video.min.js.map
