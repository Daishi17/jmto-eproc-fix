<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2024-05-14 00:13:16 --> Query error: Unknown column 'periode_penilaian' in 'field list' - Invalid query: UPDATE `tbl_pelaksanaan_total` SET `nomor_kontrak` = '123', `periode_kontrak` = '321', `waktu_penilaian` = '456', `periode_penilaian` = '654', `nama_penilai` = '678', `id_vendor` = '73', `id_rup` = '231'
WHERE `id_vendor` = '73'
AND `id_rup` = '231'
ERROR - 2024-05-14 00:53:35 --> Severity: error --> Exception: Call to undefined method M_laporan_kinerja::cek_pemeliharaan_depthead() C:\laragon\www\jmto-eproc\application\controllers\administrator\Penilaian_kinerja.php 64
ERROR - 2024-05-14 00:53:51 --> Severity: error --> Exception: Call to undefined method M_laporan_kinerja::cek_pemeliharaan_total() C:\laragon\www\jmto-eproc\application\controllers\administrator\Penilaian_kinerja.php 65
ERROR - 2024-05-14 01:38:35 --> Severity: error --> Exception: Too few arguments to function Daftar_paket::by_id_rup(), 0 passed in C:\laragon\www\jmto-eproc\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 388
ERROR - 2024-05-14 01:39:22 --> Query error: Unknown column 'NAN' in 'field list' - Invalid query: UPDATE `tbl_vendor` SET `nilai_vendor` = NAN
WHERE `id_vendor` = '123'
ERROR - 2024-05-14 01:40:14 --> Severity: error --> Exception: Too few arguments to function Daftar_paket::by_id_rup(), 0 passed in C:\laragon\www\jmto-eproc\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 388
ERROR - 2024-05-14 01:40:34 --> Severity: error --> Exception: Too few arguments to function Daftar_paket::by_id_rup(), 0 passed in C:\laragon\www\jmto-eproc\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 388
ERROR - 2024-05-14 02:03:03 --> Severity: error --> Exception: Too few arguments to function Daftar_paket::by_id_rup(), 0 passed in C:\laragon\www\jmto-eproc\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 388
ERROR - 2024-05-14 02:19:27 --> Query error: Unknown column 'Array' in 'where clause' - Invalid query: SELECT *
FROM `tbl_rup`
LEFT JOIN `tbl_panitia` ON `tbl_rup`.`id_rup` = `tbl_panitia`.`id_rup`
WHERE `tbl_panitia`.`id_manajemen_user` = Array
AND `tbl_rup`.`id_metode_pengadaan` = 1
AND `tbl_rup`.`status_paket_diumumkan` = 1
GROUP BY `tbl_rup`.`id_rup`
ERROR - 2024-05-14 02:19:30 --> Query error: Unknown column 'Array' in 'where clause' - Invalid query: SELECT *
FROM `tbl_rup`
LEFT JOIN `tbl_panitia` ON `tbl_rup`.`id_rup` = `tbl_panitia`.`id_rup`
WHERE `tbl_panitia`.`id_manajemen_user` = Array
AND `tbl_rup`.`id_metode_pengadaan` = 1
AND `tbl_rup`.`status_paket_diumumkan` = 1
GROUP BY `tbl_rup`.`id_rup`
ERROR - 2024-05-14 02:19:49 --> Query error: Unknown column 'Array' in 'where clause' - Invalid query: SELECT *
FROM `tbl_rup`
LEFT JOIN `tbl_panitia` ON `tbl_rup`.`id_rup` = `tbl_panitia`.`id_rup`
WHERE `tbl_panitia`.`id_manajemen_user` = Array
AND `tbl_rup`.`id_metode_pengadaan` = 1
AND `tbl_rup`.`status_paket_diumumkan` = 1
GROUP BY `tbl_rup`.`id_rup`
ERROR - 2024-05-14 02:21:21 --> Query error: Unknown column 'Array' in 'where clause' - Invalid query: SELECT *
FROM `tbl_rup`
LEFT JOIN `tbl_panitia` ON `tbl_rup`.`id_rup` = `tbl_panitia`.`id_rup`
WHERE `tbl_panitia`.`id_manajemen_user` = Array
AND `tbl_rup`.`id_metode_pengadaan` = 1
AND `tbl_rup`.`status_paket_diumumkan` = 1
GROUP BY `tbl_rup`.`id_rup`
ERROR - 2024-05-14 02:26:00 --> Severity: error --> Exception: Call to undefined method M_count::gettable_daftar_paket_tender_juksung() C:\laragon\www\jmto-eproc\application\controllers\administrator\Penilaian_kinerja.php 146
ERROR - 2024-05-14 02:26:34 --> Severity: error --> Exception: Call to undefined method M_count::gettable_daftar_paket_tender_juksung() C:\laragon\www\jmto-eproc\application\controllers\administrator\Penilaian_kinerja.php 146
ERROR - 2024-05-14 02:26:37 --> Severity: error --> Exception: Call to undefined method M_count::gettable_daftar_paket_tender_juksung() C:\laragon\www\jmto-eproc\application\controllers\administrator\Penilaian_kinerja.php 146
ERROR - 2024-05-14 02:26:43 --> Severity: error --> Exception: Call to undefined method M_count::gettable_daftar_paket_tender_juksung() C:\laragon\www\jmto-eproc\application\controllers\administrator\Penilaian_kinerja.php 146
ERROR - 2024-05-14 02:47:52 --> Query error: Unknown column 'NAN' in 'field list' - Invalid query: UPDATE `tbl_vendor` SET `nilai_vendor` = NAN
WHERE `id_vendor` = '86'
