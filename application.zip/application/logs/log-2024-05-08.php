<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2024-05-08 05:29:25 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): A connection attempt failed because the connected party did not properly respond after a period of time, or established connection failed because connected host has failed to respond.
 C:\laragon\www\jmto-eproc\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2024-05-08 05:29:25 --> Unable to connect to the database
ERROR - 2024-05-08 05:29:36 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): A connection attempt failed because the connected party did not properly respond after a period of time, or established connection failed because connected host has failed to respond.
 C:\laragon\www\jmto-eproc\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2024-05-08 05:29:36 --> Unable to connect to the database
ERROR - 2024-05-08 07:19:30 --> 404 Page Not Found: Aitj/index
ERROR - 2024-05-08 08:25:01 --> 404 Page Not Found: Css/style.css.map
ERROR - 2024-05-08 08:25:01 --> 404 Page Not Found: Assets_landing/bootstrap.min.css.map
ERROR - 2024-05-08 08:25:02 --> 404 Page Not Found: Assets_landing/jarallax.min.js.map
ERROR - 2024-05-08 08:25:02 --> 404 Page Not Found: Assets_landing/jarallax-video.min.js.map
