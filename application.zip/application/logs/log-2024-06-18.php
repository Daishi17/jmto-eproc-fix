<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2024-06-18 08:18:57 --> 404 Page Not Found: Laporan_tkdn/get_rup
ERROR - 2024-06-18 16:02:18 --> Severity: Warning --> mysqli::real_connect(): Error while reading greeting packet. PID=1204 C:\laragon\www\jmto-eproc\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2024-06-18 16:02:18 --> Severity: Warning --> mysqli::real_connect(): (HY000/2006): MySQL server has gone away C:\laragon\www\jmto-eproc\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2024-06-18 16:02:18 --> Unable to connect to the database
ERROR - 2024-06-18 13:37:19 --> Severity: Warning --> mysqli::real_connect(): php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\laragon\www\jmto-eproc\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2024-06-18 13:37:19 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\laragon\www\jmto-eproc\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2024-06-18 13:37:19 --> Unable to connect to the database
ERROR - 2024-06-18 20:37:28 --> Severity: Warning --> mysqli::real_connect(): Error while reading greeting packet. PID=1204 C:\laragon\www\jmto-eproc\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2024-06-18 20:37:28 --> Severity: Warning --> mysqli::real_connect(): (HY000/2006): MySQL server has gone away C:\laragon\www\jmto-eproc\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2024-06-18 20:37:28 --> Unable to connect to the database
