<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2024-06-06 16:09:58 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\administrator\Sirup_rup.php 458
ERROR - 2024-06-06 16:09:58 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\administrator\Sirup_rup.php 466
ERROR - 2024-06-06 16:09:58 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\administrator\Sirup_rup.php 474
ERROR - 2024-06-06 16:09:58 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\administrator\sirup_rup\form_rup_edit.php 2
ERROR - 2024-06-06 16:09:58 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\administrator\sirup_rup\form_rup_edit.php 36
ERROR - 2024-06-06 16:09:58 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\administrator\sirup_rup\form_rup_edit.php 53
ERROR - 2024-06-06 16:09:58 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\administrator\sirup_rup\form_rup_edit.php 57
ERROR - 2024-06-06 16:09:58 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\administrator\sirup_rup\form_rup_edit.php 71
ERROR - 2024-06-06 16:09:58 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\administrator\sirup_rup\form_rup_edit.php 102
ERROR - 2024-06-06 16:09:58 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\administrator\sirup_rup\form_rup_edit.php 102
ERROR - 2024-06-06 16:09:58 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\administrator\sirup_rup\form_rup_edit.php 135
ERROR - 2024-06-06 16:09:58 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\administrator\sirup_rup\form_rup_edit.php 135
ERROR - 2024-06-06 16:09:58 --> Severity: Notice --> Undefined variable: result_ruas_by_departemnt C:\laragon\www\jmto-eproc\application\views\administrator\sirup_rup\form_rup_edit.php 136
ERROR - 2024-06-06 16:09:58 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\jmto-eproc\application\views\administrator\sirup_rup\form_rup_edit.php 136
ERROR - 2024-06-06 16:09:58 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\administrator\sirup_rup\form_rup_edit.php 174
ERROR - 2024-06-06 16:09:58 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\administrator\sirup_rup\form_rup_edit.php 184
ERROR - 2024-06-06 16:09:58 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\administrator\sirup_rup\form_rup_edit.php 224
ERROR - 2024-06-06 16:09:58 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\administrator\sirup_rup\form_rup_edit.php 224
ERROR - 2024-06-06 16:09:58 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\administrator\sirup_rup\form_rup_edit.php 239
ERROR - 2024-06-06 16:09:58 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\administrator\sirup_rup\form_rup_edit.php 239
ERROR - 2024-06-06 16:09:58 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\administrator\sirup_rup\form_rup_edit.php 254
ERROR - 2024-06-06 16:09:58 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\administrator\sirup_rup\form_rup_edit.php 254
ERROR - 2024-06-06 16:09:58 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\administrator\sirup_rup\form_rup_edit.php 303
ERROR - 2024-06-06 16:09:58 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\administrator\sirup_rup\form_rup_edit.php 303
ERROR - 2024-06-06 16:09:58 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\administrator\sirup_rup\form_rup_edit.php 315
ERROR - 2024-06-06 16:09:58 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\administrator\sirup_rup\form_rup_edit.php 315
ERROR - 2024-06-06 16:09:58 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\administrator\sirup_rup\form_rup_edit.php 325
ERROR - 2024-06-06 16:09:58 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\administrator\sirup_rup\form_rup_edit.php 353
ERROR - 2024-06-06 16:09:58 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\administrator\sirup_rup\form_rup_edit.php 353
ERROR - 2024-06-06 16:09:58 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\administrator\sirup_rup\form_rup_edit.php 368
ERROR - 2024-06-06 16:09:58 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\administrator\sirup_rup\form_rup_edit.php 368
ERROR - 2024-06-06 16:09:58 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\administrator\sirup_rup\form_rup_edit.php 391
ERROR - 2024-06-06 16:09:58 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\administrator\sirup_rup\form_rup_edit.php 391
ERROR - 2024-06-06 16:09:58 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\administrator\sirup_rup\form_rup_edit.php 403
ERROR - 2024-06-06 16:09:58 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\administrator\sirup_rup\form_rup_edit.php 414
ERROR - 2024-06-06 16:09:58 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\administrator\sirup_rup\form_rup_edit.php 415
ERROR - 2024-06-06 16:09:58 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\administrator\sirup_rup\form_rup_edit.php 451
ERROR - 2024-06-06 16:09:58 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\administrator\sirup_rup\form_rup_edit.php 461
ERROR - 2024-06-06 16:09:58 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\administrator\sirup_rup\form_rup_edit.php 471
ERROR - 2024-06-06 16:09:58 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\administrator\sirup_rup\form_rup_edit.php 533
ERROR - 2024-06-06 16:09:58 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\administrator\sirup_rup\form_rup_edit.php 553
ERROR - 2024-06-06 16:09:58 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\administrator\sirup_rup\form_rup_edit.php 555
ERROR - 2024-06-06 16:09:58 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\controllers\administrator\Sirup_rup.php 838
