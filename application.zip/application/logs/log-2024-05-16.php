<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2024-05-16 02:10:44 --> Query error: Unknown column 'NAN' in 'field list' - Invalid query: UPDATE `tbl_vendor` SET `nilai_vendor` = NAN
WHERE `id_vendor` = '86'
ERROR - 2024-05-16 02:35:24 --> Severity: error --> Exception: syntax error, unexpected end of file C:\laragon\www\jmto-eproc\application\views\administrator\penilaian_kinerja\print_penilaian.php 2
ERROR - 2024-05-16 02:45:23 --> Query error: Unknown column 'NAN' in 'field list' - Invalid query: UPDATE `tbl_vendor` SET `nilai_vendor` = NAN
WHERE `id_vendor` = '86'
ERROR - 2024-05-16 02:46:10 --> Query error: Unknown column 'NAN' in 'field list' - Invalid query: UPDATE `tbl_vendor` SET `nilai_vendor` = NAN
WHERE `id_vendor` = '123'
ERROR - 2024-05-16 02:48:06 --> Query error: Unknown column 'NAN' in 'field list' - Invalid query: UPDATE `tbl_vendor` SET `nilai_vendor` = NAN
WHERE `id_vendor` = '86'
ERROR - 2024-05-16 03:27:50 --> Query error: Unknown column 'id_penilaian_vendor' in 'where clause' - Invalid query: SELECT *
FROM `tbl_pelaksanaan_total`
LEFT JOIN `tbl_rup` ON `tbl_pelaksanaan_total`.`id_rup` = `tbl_rup`.`id_rup`
LEFT JOIN `tbl_departemen` ON `tbl_rup`.`id_departemen` = `tbl_departemen`.`id_departemen`
LEFT JOIN `tbl_section` ON `tbl_rup`.`id_section` = `tbl_section`.`id_section`
LEFT JOIN `tbl_vendor` ON `tbl_pelaksanaan_total`.`id_rup` = `tbl_vendor`.`id_vendor`
WHERE `id_penilaian_vendor` = '1'
ERROR - 2024-05-16 03:27:53 --> Query error: Unknown column 'id_penilaian_vendor' in 'where clause' - Invalid query: SELECT *
FROM `tbl_pelaksanaan_total`
LEFT JOIN `tbl_rup` ON `tbl_pelaksanaan_total`.`id_rup` = `tbl_rup`.`id_rup`
LEFT JOIN `tbl_departemen` ON `tbl_rup`.`id_departemen` = `tbl_departemen`.`id_departemen`
LEFT JOIN `tbl_section` ON `tbl_rup`.`id_section` = `tbl_section`.`id_section`
LEFT JOIN `tbl_vendor` ON `tbl_pelaksanaan_total`.`id_rup` = `tbl_vendor`.`id_vendor`
WHERE `id_penilaian_vendor` = '1'
ERROR - 2024-05-16 03:27:59 --> Query error: Unknown column 'id_penilaian_vendor' in 'where clause' - Invalid query: SELECT *
FROM `tbl_pelaksanaan_total`
LEFT JOIN `tbl_rup` ON `tbl_pelaksanaan_total`.`id_rup` = `tbl_rup`.`id_rup`
LEFT JOIN `tbl_departemen` ON `tbl_rup`.`id_departemen` = `tbl_departemen`.`id_departemen`
LEFT JOIN `tbl_section` ON `tbl_rup`.`id_section` = `tbl_section`.`id_section`
LEFT JOIN `tbl_vendor` ON `tbl_pelaksanaan_total`.`id_rup` = `tbl_vendor`.`id_vendor`
WHERE `id_penilaian_vendor` = '1'
ERROR - 2024-05-16 03:28:01 --> Query error: Unknown column 'id_penilaian_vendor' in 'where clause' - Invalid query: SELECT *
FROM `tbl_pelaksanaan_total`
LEFT JOIN `tbl_rup` ON `tbl_pelaksanaan_total`.`id_rup` = `tbl_rup`.`id_rup`
LEFT JOIN `tbl_departemen` ON `tbl_rup`.`id_departemen` = `tbl_departemen`.`id_departemen`
LEFT JOIN `tbl_section` ON `tbl_rup`.`id_section` = `tbl_section`.`id_section`
LEFT JOIN `tbl_vendor` ON `tbl_pelaksanaan_total`.`id_rup` = `tbl_vendor`.`id_vendor`
WHERE `id_penilaian_vendor` = '1'
ERROR - 2024-05-16 03:29:24 --> Query error: Unknown column 'id_penilaian_vendor' in 'where clause' - Invalid query: SELECT *
FROM `tbl_pelaksanaan_total`
LEFT JOIN `tbl_rup` ON `tbl_pelaksanaan_total`.`id_rup` = `tbl_rup`.`id_rup`
LEFT JOIN `tbl_departemen` ON `tbl_rup`.`id_departemen` = `tbl_departemen`.`id_departemen`
LEFT JOIN `tbl_section` ON `tbl_rup`.`id_section` = `tbl_section`.`id_section`
LEFT JOIN `tbl_vendor` ON `tbl_pelaksanaan_total`.`id_rup` = `tbl_vendor`.`id_vendor`
WHERE `id_penilaian_vendor` = '1'
ERROR - 2024-05-16 03:29:29 --> Query error: Unknown column 'id_penilaian_vendor' in 'where clause' - Invalid query: SELECT *
FROM `tbl_pelaksanaan_total`
LEFT JOIN `tbl_rup` ON `tbl_pelaksanaan_total`.`id_rup` = `tbl_rup`.`id_rup`
LEFT JOIN `tbl_departemen` ON `tbl_rup`.`id_departemen` = `tbl_departemen`.`id_departemen`
LEFT JOIN `tbl_section` ON `tbl_rup`.`id_section` = `tbl_section`.`id_section`
LEFT JOIN `tbl_vendor` ON `tbl_pelaksanaan_total`.`id_rup` = `tbl_vendor`.`id_vendor`
WHERE `id_penilaian_vendor` = '1'
ERROR - 2024-05-16 03:29:48 --> Query error: Unknown column 'id_penilaian_total' in 'where clause' - Invalid query: SELECT *
FROM `tbl_pelaksanaan_total`
LEFT JOIN `tbl_rup` ON `tbl_pelaksanaan_total`.`id_rup` = `tbl_rup`.`id_rup`
LEFT JOIN `tbl_departemen` ON `tbl_rup`.`id_departemen` = `tbl_departemen`.`id_departemen`
LEFT JOIN `tbl_section` ON `tbl_rup`.`id_section` = `tbl_section`.`id_section`
LEFT JOIN `tbl_vendor` ON `tbl_pelaksanaan_total`.`id_rup` = `tbl_vendor`.`id_vendor`
WHERE `id_penilaian_total` = '1'
ERROR - 2024-05-16 03:40:19 --> Query error: Unknown column 'jabatan' in 'field list' - Invalid query: UPDATE `tbl_pemeliharaan_satgas` SET `nomor_kontrak` = 'Pemeliharaan 123', `periode_kontrak` = 'Pemeliharaan 123', `waktu_penilaian` = 'Pemeliharaan 123', `periode_penilaian` = 'Pemeliharaan 123', `nama_penilai` = 'jabatan pemeliharaan', `jabatan` = NULL, `nilai1` = 'C+', `nilai_angka1` = '70', `nilai2` = 'C+', `nilai_angka2` = '70', `nilai3` = 'C+', `nilai_angka3` = '70', `nilai4` = 'C+', `nilai_angka4` = '70', `nilai5` = 'C+', `nilai_angka5` = '70', `nilai6` = 'C+', `nilai_angka6` = '70', `penjelasan1` = 'test', `penjelasan2` = 'test', `penjelasan3` = 'test', `penjelasan4` = 'test', `penjelasan5` = 'test', `penjelasan6` = 'test', `hasil` = '70', `hasil_huruf` = 'C+', `user_created` = 'Administrator', `id_vendor` = '73', `id_rup` = '231'
WHERE `id_vendor` = '73'
AND `id_rup` = '231'
ERROR - 2024-05-16 03:43:44 --> Severity: error --> Exception: Call to undefined method M_laporan_kinerja::get_penilaian_pelaksanaan_byid() C:\laragon\www\jmto-eproc\application\controllers\administrator\Penilaian_kinerja.php 1010
ERROR - 2024-05-16 03:44:55 --> Query error: Unknown column 'tbl_pemeliharaan_satgas.id_penilaian_vendor' in 'where clause' - Invalid query: SELECT *
FROM `tbl_pemeliharaan_satgas`
LEFT JOIN `tbl_rup` ON `tbl_pemeliharaan_satgas`.`id_rup` = `tbl_rup`.`id_rup`
LEFT JOIN `tbl_departemen` ON `tbl_rup`.`id_departemen` = `tbl_departemen`.`id_departemen`
LEFT JOIN `tbl_section` ON `tbl_rup`.`id_section` = `tbl_section`.`id_section`
LEFT JOIN `tbl_vendor` ON `tbl_pemeliharaan_satgas`.`id_vendor` = `tbl_vendor`.`id_vendor`
WHERE `tbl_pemeliharaan_satgas`.`id_penilaian_vendor` = '1'
ERROR - 2024-05-16 03:45:17 --> Query error: Unknown column 'tbl_pemeliharaan_satgas.id_penilaian_vendor' in 'where clause' - Invalid query: SELECT *
FROM `tbl_pemeliharaan_satgas`
LEFT JOIN `tbl_rup` ON `tbl_pemeliharaan_satgas`.`id_rup` = `tbl_rup`.`id_rup`
LEFT JOIN `tbl_departemen` ON `tbl_rup`.`id_departemen` = `tbl_departemen`.`id_departemen`
LEFT JOIN `tbl_section` ON `tbl_rup`.`id_section` = `tbl_section`.`id_section`
LEFT JOIN `tbl_vendor` ON `tbl_pemeliharaan_satgas`.`id_vendor` = `tbl_vendor`.`id_vendor`
WHERE `tbl_pemeliharaan_satgas`.`id_penilaian_vendor` = '1'
ERROR - 2024-05-16 03:45:18 --> Query error: Unknown column 'tbl_pemeliharaan_satgas.id_penilaian_vendor' in 'where clause' - Invalid query: SELECT *
FROM `tbl_pemeliharaan_satgas`
LEFT JOIN `tbl_rup` ON `tbl_pemeliharaan_satgas`.`id_rup` = `tbl_rup`.`id_rup`
LEFT JOIN `tbl_departemen` ON `tbl_rup`.`id_departemen` = `tbl_departemen`.`id_departemen`
LEFT JOIN `tbl_section` ON `tbl_rup`.`id_section` = `tbl_section`.`id_section`
LEFT JOIN `tbl_vendor` ON `tbl_pemeliharaan_satgas`.`id_vendor` = `tbl_vendor`.`id_vendor`
WHERE `tbl_pemeliharaan_satgas`.`id_penilaian_vendor` = '1'
ERROR - 2024-05-16 03:47:33 --> Query error: Unknown column 'tbl_pemeliharaan_satgas.id_penilaian_vendor' in 'where clause' - Invalid query: SELECT *
FROM `tbl_pemeliharaan_satgas`
LEFT JOIN `tbl_rup` ON `tbl_pemeliharaan_satgas`.`id_rup` = `tbl_rup`.`id_rup`
LEFT JOIN `tbl_departemen` ON `tbl_rup`.`id_departemen` = `tbl_departemen`.`id_departemen`
LEFT JOIN `tbl_section` ON `tbl_rup`.`id_section` = `tbl_section`.`id_section`
LEFT JOIN `tbl_vendor` ON `tbl_pemeliharaan_satgas`.`id_vendor` = `tbl_vendor`.`id_vendor`
WHERE `tbl_pemeliharaan_satgas`.`id_penilaian_vendor` = '1'
ERROR - 2024-05-16 03:55:37 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\administrator\penilaian_kinerja\print_penilaian_pemeliharaan.php 137
ERROR - 2024-05-16 03:55:37 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\administrator\penilaian_kinerja\print_penilaian_pemeliharaan.php 141
ERROR - 2024-05-16 03:55:37 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\administrator\penilaian_kinerja\print_penilaian_pemeliharaan.php 145
ERROR - 2024-05-16 03:55:37 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\administrator\penilaian_kinerja\print_penilaian_pemeliharaan.php 149
ERROR - 2024-05-16 03:55:37 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\administrator\penilaian_kinerja\print_penilaian_pemeliharaan.php 153
ERROR - 2024-05-16 03:55:37 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\administrator\penilaian_kinerja\print_penilaian_pemeliharaan.php 157
ERROR - 2024-05-16 03:55:37 --> Severity: Notice --> Undefined offset: 2 C:\laragon\www\jmto-eproc\application\views\administrator\penilaian_kinerja\print_penilaian_pemeliharaan.php 54
ERROR - 2024-05-16 03:55:37 --> Severity: Notice --> Undefined offset: 1 C:\laragon\www\jmto-eproc\application\views\administrator\penilaian_kinerja\print_penilaian_pemeliharaan.php 54
ERROR - 2024-05-16 03:55:37 --> Severity: Notice --> Undefined offset: 0 C:\laragon\www\jmto-eproc\application\views\administrator\penilaian_kinerja\print_penilaian_pemeliharaan.php 54
ERROR - 2024-05-16 03:55:37 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\administrator\penilaian_kinerja\print_penilaian_pemeliharaan.php 161
ERROR - 2024-05-16 03:55:37 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\administrator\penilaian_kinerja\print_penilaian_pemeliharaan.php 165
ERROR - 2024-05-16 03:55:37 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\administrator\penilaian_kinerja\print_penilaian_pemeliharaan.php 169
ERROR - 2024-05-16 03:55:37 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\administrator\penilaian_kinerja\print_penilaian_pemeliharaan.php 194
ERROR - 2024-05-16 03:55:37 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\administrator\penilaian_kinerja\print_penilaian_pemeliharaan.php 195
ERROR - 2024-05-16 03:55:37 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\administrator\penilaian_kinerja\print_penilaian_pemeliharaan.php 196
ERROR - 2024-05-16 03:55:37 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\administrator\penilaian_kinerja\print_penilaian_pemeliharaan.php 201
ERROR - 2024-05-16 03:55:37 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\administrator\penilaian_kinerja\print_penilaian_pemeliharaan.php 202
ERROR - 2024-05-16 03:55:37 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\administrator\penilaian_kinerja\print_penilaian_pemeliharaan.php 203
ERROR - 2024-05-16 03:55:37 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\administrator\penilaian_kinerja\print_penilaian_pemeliharaan.php 208
ERROR - 2024-05-16 03:55:37 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\administrator\penilaian_kinerja\print_penilaian_pemeliharaan.php 209
ERROR - 2024-05-16 03:55:37 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\administrator\penilaian_kinerja\print_penilaian_pemeliharaan.php 210
ERROR - 2024-05-16 03:55:37 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\administrator\penilaian_kinerja\print_penilaian_pemeliharaan.php 215
ERROR - 2024-05-16 03:55:37 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\administrator\penilaian_kinerja\print_penilaian_pemeliharaan.php 216
ERROR - 2024-05-16 03:55:37 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\administrator\penilaian_kinerja\print_penilaian_pemeliharaan.php 217
ERROR - 2024-05-16 03:55:37 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\administrator\penilaian_kinerja\print_penilaian_pemeliharaan.php 222
ERROR - 2024-05-16 03:55:37 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\administrator\penilaian_kinerja\print_penilaian_pemeliharaan.php 223
ERROR - 2024-05-16 03:55:37 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\administrator\penilaian_kinerja\print_penilaian_pemeliharaan.php 224
ERROR - 2024-05-16 03:55:37 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\administrator\penilaian_kinerja\print_penilaian_pemeliharaan.php 229
ERROR - 2024-05-16 03:55:37 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\administrator\penilaian_kinerja\print_penilaian_pemeliharaan.php 230
ERROR - 2024-05-16 03:55:37 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\administrator\penilaian_kinerja\print_penilaian_pemeliharaan.php 231
ERROR - 2024-05-16 03:55:37 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\administrator\penilaian_kinerja\print_penilaian_pemeliharaan.php 237
ERROR - 2024-05-16 03:55:37 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\administrator\penilaian_kinerja\print_penilaian_pemeliharaan.php 238
ERROR - 2024-05-16 03:55:37 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\administrator\penilaian_kinerja\print_penilaian_pemeliharaan.php 240
ERROR - 2024-05-16 03:55:37 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\administrator\penilaian_kinerja\print_penilaian_pemeliharaan.php 247
ERROR - 2024-05-16 03:55:37 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\administrator\penilaian_kinerja\print_penilaian_pemeliharaan.php 254
ERROR - 2024-05-16 03:55:37 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\administrator\penilaian_kinerja\print_penilaian_pemeliharaan.php 354
ERROR - 2024-05-16 03:55:37 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\administrator\penilaian_kinerja\print_penilaian_pemeliharaan.php 356
ERROR - 2024-05-16 03:55:37 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\administrator\penilaian_kinerja\print_penilaian_pemeliharaan.php 137
ERROR - 2024-05-16 03:55:37 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\administrator\penilaian_kinerja\print_penilaian_pemeliharaan.php 141
ERROR - 2024-05-16 03:55:37 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\administrator\penilaian_kinerja\print_penilaian_pemeliharaan.php 145
ERROR - 2024-05-16 03:55:37 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\administrator\penilaian_kinerja\print_penilaian_pemeliharaan.php 149
ERROR - 2024-05-16 03:55:37 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\administrator\penilaian_kinerja\print_penilaian_pemeliharaan.php 153
ERROR - 2024-05-16 03:55:37 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\administrator\penilaian_kinerja\print_penilaian_pemeliharaan.php 157
ERROR - 2024-05-16 03:55:37 --> Severity: Notice --> Undefined offset: 2 C:\laragon\www\jmto-eproc\application\views\administrator\penilaian_kinerja\print_penilaian_pemeliharaan.php 54
ERROR - 2024-05-16 03:55:37 --> Severity: Notice --> Undefined offset: 1 C:\laragon\www\jmto-eproc\application\views\administrator\penilaian_kinerja\print_penilaian_pemeliharaan.php 54
ERROR - 2024-05-16 03:55:37 --> Severity: Notice --> Undefined offset: 0 C:\laragon\www\jmto-eproc\application\views\administrator\penilaian_kinerja\print_penilaian_pemeliharaan.php 54
ERROR - 2024-05-16 03:55:37 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\administrator\penilaian_kinerja\print_penilaian_pemeliharaan.php 161
ERROR - 2024-05-16 03:55:37 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\administrator\penilaian_kinerja\print_penilaian_pemeliharaan.php 165
ERROR - 2024-05-16 03:55:37 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\administrator\penilaian_kinerja\print_penilaian_pemeliharaan.php 169
ERROR - 2024-05-16 03:55:37 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\administrator\penilaian_kinerja\print_penilaian_pemeliharaan.php 194
ERROR - 2024-05-16 03:55:37 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\administrator\penilaian_kinerja\print_penilaian_pemeliharaan.php 195
ERROR - 2024-05-16 03:55:37 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\administrator\penilaian_kinerja\print_penilaian_pemeliharaan.php 196
ERROR - 2024-05-16 03:55:37 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\administrator\penilaian_kinerja\print_penilaian_pemeliharaan.php 201
ERROR - 2024-05-16 03:55:37 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\administrator\penilaian_kinerja\print_penilaian_pemeliharaan.php 202
ERROR - 2024-05-16 03:55:37 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\administrator\penilaian_kinerja\print_penilaian_pemeliharaan.php 203
ERROR - 2024-05-16 03:55:37 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\administrator\penilaian_kinerja\print_penilaian_pemeliharaan.php 208
ERROR - 2024-05-16 03:55:37 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\administrator\penilaian_kinerja\print_penilaian_pemeliharaan.php 209
ERROR - 2024-05-16 03:55:37 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\administrator\penilaian_kinerja\print_penilaian_pemeliharaan.php 210
ERROR - 2024-05-16 03:55:37 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\administrator\penilaian_kinerja\print_penilaian_pemeliharaan.php 215
ERROR - 2024-05-16 03:55:37 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\administrator\penilaian_kinerja\print_penilaian_pemeliharaan.php 216
ERROR - 2024-05-16 03:55:37 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\administrator\penilaian_kinerja\print_penilaian_pemeliharaan.php 217
ERROR - 2024-05-16 03:55:37 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\administrator\penilaian_kinerja\print_penilaian_pemeliharaan.php 222
ERROR - 2024-05-16 03:55:37 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\administrator\penilaian_kinerja\print_penilaian_pemeliharaan.php 223
ERROR - 2024-05-16 03:55:37 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\administrator\penilaian_kinerja\print_penilaian_pemeliharaan.php 224
ERROR - 2024-05-16 03:55:37 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\administrator\penilaian_kinerja\print_penilaian_pemeliharaan.php 229
ERROR - 2024-05-16 03:55:37 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\administrator\penilaian_kinerja\print_penilaian_pemeliharaan.php 230
ERROR - 2024-05-16 03:55:37 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\administrator\penilaian_kinerja\print_penilaian_pemeliharaan.php 231
ERROR - 2024-05-16 03:55:37 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\administrator\penilaian_kinerja\print_penilaian_pemeliharaan.php 237
ERROR - 2024-05-16 03:55:37 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\administrator\penilaian_kinerja\print_penilaian_pemeliharaan.php 238
ERROR - 2024-05-16 03:55:37 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\administrator\penilaian_kinerja\print_penilaian_pemeliharaan.php 240
ERROR - 2024-05-16 03:55:37 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\administrator\penilaian_kinerja\print_penilaian_pemeliharaan.php 247
ERROR - 2024-05-16 03:55:37 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\administrator\penilaian_kinerja\print_penilaian_pemeliharaan.php 254
ERROR - 2024-05-16 03:55:37 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\administrator\penilaian_kinerja\print_penilaian_pemeliharaan.php 354
ERROR - 2024-05-16 03:55:37 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\administrator\penilaian_kinerja\print_penilaian_pemeliharaan.php 356
ERROR - 2024-05-16 03:56:49 --> Severity: Notice --> Undefined offset: 2 C:\laragon\www\jmto-eproc\application\views\administrator\penilaian_kinerja\print_penilaian_pemeliharaan.php 54
ERROR - 2024-05-16 03:56:49 --> Severity: Notice --> Undefined offset: 1 C:\laragon\www\jmto-eproc\application\views\administrator\penilaian_kinerja\print_penilaian_pemeliharaan.php 54
ERROR - 2024-05-16 03:56:49 --> Severity: Notice --> Undefined offset: 0 C:\laragon\www\jmto-eproc\application\views\administrator\penilaian_kinerja\print_penilaian_pemeliharaan.php 54
ERROR - 2024-05-16 03:56:50 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\administrator\penilaian_kinerja\print_penilaian_pemeliharaan.php 137
ERROR - 2024-05-16 03:56:50 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\administrator\penilaian_kinerja\print_penilaian_pemeliharaan.php 141
ERROR - 2024-05-16 03:56:50 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\administrator\penilaian_kinerja\print_penilaian_pemeliharaan.php 145
ERROR - 2024-05-16 03:56:50 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\administrator\penilaian_kinerja\print_penilaian_pemeliharaan.php 149
ERROR - 2024-05-16 03:56:50 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\administrator\penilaian_kinerja\print_penilaian_pemeliharaan.php 153
ERROR - 2024-05-16 03:56:50 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\administrator\penilaian_kinerja\print_penilaian_pemeliharaan.php 157
ERROR - 2024-05-16 03:56:50 --> Severity: Notice --> Undefined offset: 2 C:\laragon\www\jmto-eproc\application\views\administrator\penilaian_kinerja\print_penilaian_pemeliharaan.php 54
ERROR - 2024-05-16 03:56:50 --> Severity: Notice --> Undefined offset: 1 C:\laragon\www\jmto-eproc\application\views\administrator\penilaian_kinerja\print_penilaian_pemeliharaan.php 54
ERROR - 2024-05-16 03:56:50 --> Severity: Notice --> Undefined offset: 0 C:\laragon\www\jmto-eproc\application\views\administrator\penilaian_kinerja\print_penilaian_pemeliharaan.php 54
ERROR - 2024-05-16 03:56:50 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\administrator\penilaian_kinerja\print_penilaian_pemeliharaan.php 161
ERROR - 2024-05-16 03:56:50 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\administrator\penilaian_kinerja\print_penilaian_pemeliharaan.php 165
ERROR - 2024-05-16 03:56:50 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\administrator\penilaian_kinerja\print_penilaian_pemeliharaan.php 169
ERROR - 2024-05-16 03:56:50 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\administrator\penilaian_kinerja\print_penilaian_pemeliharaan.php 194
ERROR - 2024-05-16 03:56:50 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\administrator\penilaian_kinerja\print_penilaian_pemeliharaan.php 195
ERROR - 2024-05-16 03:56:50 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\administrator\penilaian_kinerja\print_penilaian_pemeliharaan.php 196
ERROR - 2024-05-16 03:56:50 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\administrator\penilaian_kinerja\print_penilaian_pemeliharaan.php 201
ERROR - 2024-05-16 03:56:50 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\administrator\penilaian_kinerja\print_penilaian_pemeliharaan.php 202
ERROR - 2024-05-16 03:56:50 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\administrator\penilaian_kinerja\print_penilaian_pemeliharaan.php 203
ERROR - 2024-05-16 03:56:50 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\administrator\penilaian_kinerja\print_penilaian_pemeliharaan.php 208
ERROR - 2024-05-16 03:56:50 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\administrator\penilaian_kinerja\print_penilaian_pemeliharaan.php 209
ERROR - 2024-05-16 03:56:50 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\administrator\penilaian_kinerja\print_penilaian_pemeliharaan.php 210
ERROR - 2024-05-16 03:56:50 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\administrator\penilaian_kinerja\print_penilaian_pemeliharaan.php 215
ERROR - 2024-05-16 03:56:50 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\administrator\penilaian_kinerja\print_penilaian_pemeliharaan.php 216
ERROR - 2024-05-16 03:56:50 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\administrator\penilaian_kinerja\print_penilaian_pemeliharaan.php 217
ERROR - 2024-05-16 03:56:50 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\administrator\penilaian_kinerja\print_penilaian_pemeliharaan.php 222
ERROR - 2024-05-16 03:56:50 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\administrator\penilaian_kinerja\print_penilaian_pemeliharaan.php 223
ERROR - 2024-05-16 03:56:50 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\administrator\penilaian_kinerja\print_penilaian_pemeliharaan.php 224
ERROR - 2024-05-16 03:56:50 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\administrator\penilaian_kinerja\print_penilaian_pemeliharaan.php 229
ERROR - 2024-05-16 03:56:50 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\administrator\penilaian_kinerja\print_penilaian_pemeliharaan.php 230
ERROR - 2024-05-16 03:56:50 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\administrator\penilaian_kinerja\print_penilaian_pemeliharaan.php 231
ERROR - 2024-05-16 03:56:50 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\administrator\penilaian_kinerja\print_penilaian_pemeliharaan.php 237
ERROR - 2024-05-16 03:56:50 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\administrator\penilaian_kinerja\print_penilaian_pemeliharaan.php 238
ERROR - 2024-05-16 03:56:50 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\administrator\penilaian_kinerja\print_penilaian_pemeliharaan.php 240
ERROR - 2024-05-16 03:56:50 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\administrator\penilaian_kinerja\print_penilaian_pemeliharaan.php 247
ERROR - 2024-05-16 03:56:50 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\administrator\penilaian_kinerja\print_penilaian_pemeliharaan.php 254
ERROR - 2024-05-16 03:56:50 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\administrator\penilaian_kinerja\print_penilaian_pemeliharaan.php 354
ERROR - 2024-05-16 03:56:50 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\jmto-eproc\application\views\administrator\penilaian_kinerja\print_penilaian_pemeliharaan.php 356
ERROR - 2024-05-16 04:15:07 --> Query error: Unknown column 'NAN' in 'field list' - Invalid query: UPDATE `tbl_vendor` SET `nilai_vendor` = NAN
WHERE `id_vendor` = '86'
