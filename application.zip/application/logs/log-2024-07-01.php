<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2024-07-01 20:32:16 --> Severity: error --> Exception: Too few arguments to function Daftar_paket::by_id_rup(), 0 passed in C:\laragon\www\jmto-eproc\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 388
ERROR - 2024-07-01 20:36:30 --> Severity: error --> Exception: Too few arguments to function Daftar_paket::by_id_rup(), 0 passed in C:\laragon\www\jmto-eproc\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 388
ERROR - 2024-07-01 20:37:09 --> Severity: error --> Exception: Too few arguments to function Daftar_paket::by_id_rup(), 0 passed in C:\laragon\www\jmto-eproc\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 388
ERROR - 2024-07-01 20:41:02 --> Unable to connect to the database
ERROR - 2024-07-01 20:41:23 --> Query error: MySQL server has gone away - Invalid query: SELECT *
FROM `tbl_rup`
LEFT JOIN `tbl_departemen` ON `tbl_rup`.`id_departemen` = `tbl_departemen`.`id_departemen`
LEFT JOIN `tbl_jadwal_tender` ON `tbl_rup`.`id_jadwal_tender` = `tbl_jadwal_tender`.`id_jadwal_tender`
LEFT JOIN `tbl_section` ON `tbl_rup`.`id_section` = `tbl_section`.`id_section`
LEFT JOIN `tbl_rkap` ON `tbl_rup`.`id_rkap` = `tbl_rkap`.`id_rkap`
LEFT JOIN `tbl_provinsi` ON `tbl_rup`.`id_provinsi` = `tbl_provinsi`.`id_provinsi`
LEFT JOIN `tbl_kabupaten` ON `tbl_rup`.`id_kabupaten` = `tbl_kabupaten`.`id_kabupaten`
LEFT JOIN `tbl_jenis_pengadaan` ON `tbl_rup`.`id_jenis_pengadaan` = `tbl_jenis_pengadaan`.`id_jenis_pengadaan`
LEFT JOIN `tbl_metode_pengadaan` ON `tbl_rup`.`id_metode_pengadaan` = `tbl_metode_pengadaan`.`id_metode_pengadaan`
LEFT JOIN `tbl_jenis_anggaran` ON `tbl_rup`.`id_jenis_anggaran` = `tbl_jenis_anggaran`.`id_jenis_anggaran`
LEFT JOIN `mst_ruas` ON `tbl_rup`.`id_ruas` = `mst_ruas`.`id_ruas`
WHERE `id_url_rup` = 'e93537270c814883ba9661c3f79f5b7b'
ERROR - 2024-07-01 20:41:23 --> Unable to connect to the database
ERROR - 2024-07-01 20:47:50 --> Unable to connect to the database
ERROR - 2024-07-01 20:47:50 --> Query error: MySQL server has gone away - Invalid query: SELECT *
FROM `tbl_vendor_syarat_tambahan`
JOIN `tbl_vendor` ON `tbl_vendor_syarat_tambahan`.`id_vendor` = `tbl_vendor`.`id_vendor`
WHERE `tbl_vendor_syarat_tambahan`.`id_rup` = '215'
AND `tbl_vendor_syarat_tambahan`.`status` = 2
GROUP BY `tbl_vendor_syarat_tambahan`.`id_vendor`
ERROR - 2024-07-01 20:47:50 --> Query error: MySQL server has gone away - Invalid query: SELECT *
FROM `tbl_ba_teknis_detail`
WHERE `id_rup` = '215'
ERROR - 2024-07-01 20:47:51 --> Query error: MySQL server has gone away - Invalid query: SELECT *
FROM `tbl_rup`
LEFT JOIN `tbl_departemen` ON `tbl_rup`.`id_departemen` = `tbl_departemen`.`id_departemen`
LEFT JOIN `tbl_jadwal_tender` ON `tbl_rup`.`id_jadwal_tender` = `tbl_jadwal_tender`.`id_jadwal_tender`
LEFT JOIN `tbl_section` ON `tbl_rup`.`id_section` = `tbl_section`.`id_section`
LEFT JOIN `tbl_rkap` ON `tbl_rup`.`id_rkap` = `tbl_rkap`.`id_rkap`
LEFT JOIN `tbl_provinsi` ON `tbl_rup`.`id_provinsi` = `tbl_provinsi`.`id_provinsi`
LEFT JOIN `tbl_kabupaten` ON `tbl_rup`.`id_kabupaten` = `tbl_kabupaten`.`id_kabupaten`
LEFT JOIN `tbl_jenis_pengadaan` ON `tbl_rup`.`id_jenis_pengadaan` = `tbl_jenis_pengadaan`.`id_jenis_pengadaan`
LEFT JOIN `tbl_metode_pengadaan` ON `tbl_rup`.`id_metode_pengadaan` = `tbl_metode_pengadaan`.`id_metode_pengadaan`
LEFT JOIN `tbl_jenis_anggaran` ON `tbl_rup`.`id_jenis_anggaran` = `tbl_jenis_anggaran`.`id_jenis_anggaran`
LEFT JOIN `mst_ruas` ON `tbl_rup`.`id_ruas` = `mst_ruas`.`id_ruas`
WHERE `id_url_rup` = 'e93537270c814883ba9661c3f79f5b7b'
ERROR - 2024-07-01 20:47:51 --> Query error: MySQL server has gone away - Invalid query: SELECT *
FROM `tbl_panitia`
LEFT JOIN `tbl_manajemen_user` ON `tbl_panitia`.`id_manajemen_user` = `tbl_manajemen_user`.`id_manajemen_user`
LEFT JOIN `tbl_pegawai` ON `tbl_manajemen_user`.`id_pegawai` = `tbl_pegawai`.`id_pegawai`
WHERE `id_rup` = '215'
AND `tbl_manajemen_user`.`role` = 5
ORDER BY `tbl_panitia`.`role_panitia` ASC
ERROR - 2024-07-01 20:47:51 --> Query error: MySQL server has gone away - Invalid query: SELECT *
FROM `tbl_rup`
WHERE `tbl_rup`.`id_rup` = '215'
ERROR - 2024-07-01 20:59:35 --> Severity: error --> Exception: Too few arguments to function Daftar_paket::by_id_rup(), 0 passed in C:\laragon\www\jmto-eproc\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 388
ERROR - 2024-07-01 21:13:20 --> Query error: Unknown column 'tbl_rup.id_pemenang_vendor' in 'where clause' - Invalid query: SELECT *
FROM `tbl_rup`
LEFT JOIN `tbl_jadwal_rup` ON `tbl_rup`.`id_rup` = `tbl_jadwal_rup`.`id_rup`
WHERE `tbl_rup`.`id_rup` = '223'
AND `tbl_jadwal_rup`.`waktu_mulai` = '2024-02-06 13:00'
AND `tbl_jadwal_rup`.`waktu_selesai` = '2024-05-02 10:14'
AND `tbl_rup`.`id_pemenang_vendor` = '86'
ERROR - 2024-07-01 21:13:26 --> Query error: Unknown column 'tbl_rup.id_pemenang_vendor' in 'where clause' - Invalid query: SELECT *
FROM `tbl_rup`
LEFT JOIN `tbl_jadwal_rup` ON `tbl_rup`.`id_rup` = `tbl_jadwal_rup`.`id_rup`
WHERE `tbl_rup`.`id_rup` = '223'
AND `tbl_jadwal_rup`.`waktu_mulai` = '2024-02-06 13:00'
AND `tbl_jadwal_rup`.`waktu_selesai` = '2024-05-02 10:14'
AND `tbl_rup`.`id_pemenang_vendor` = '86'
ERROR - 2024-07-01 21:13:30 --> Query error: Unknown column 'tbl_rup.id_pemenang_vendor' in 'where clause' - Invalid query: SELECT *
FROM `tbl_rup`
LEFT JOIN `tbl_jadwal_rup` ON `tbl_rup`.`id_rup` = `tbl_jadwal_rup`.`id_rup`
WHERE `tbl_rup`.`id_rup` = '223'
AND `tbl_jadwal_rup`.`waktu_mulai` = '2024-02-06 13:00'
AND `tbl_jadwal_rup`.`waktu_selesai` = '2024-05-02 10:14'
AND `tbl_rup`.`id_pemenang_vendor` = '86'
ERROR - 2024-07-01 21:23:15 --> Query error: No tables used - Invalid query: SELECT *
ERROR - 2024-07-01 21:23:51 --> Query error: No tables used - Invalid query: SELECT *
ERROR - 2024-07-01 21:23:55 --> Query error: No tables used - Invalid query: SELECT *
