<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2024-05-06 14:46:58 --> Severity: error --> Exception: Unable to locate the model you have specified: M_Laporan C:\laragon\www\jmto-eproc\system\core\Loader.php 349
ERROR - 2024-05-06 14:48:00 --> Severity: Notice --> Undefined variable: departemen C:\laragon\www\jmto-eproc\application\views\administrator\laporan\laporan_efisiensi.php 86
ERROR - 2024-05-06 14:48:00 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\jmto-eproc\application\views\administrator\laporan\laporan_efisiensi.php 86
ERROR - 2024-05-06 14:48:06 --> Severity: Notice --> Undefined variable: departemen C:\laragon\www\jmto-eproc\application\views\administrator\laporan\laporan_efisiensi.php 86
ERROR - 2024-05-06 14:48:06 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\jmto-eproc\application\views\administrator\laporan\laporan_efisiensi.php 86
ERROR - 2024-05-06 14:48:07 --> Severity: Notice --> Undefined variable: departemen C:\laragon\www\jmto-eproc\application\views\administrator\laporan\laporan_efisiensi.php 86
ERROR - 2024-05-06 14:48:07 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\jmto-eproc\application\views\administrator\laporan\laporan_efisiensi.php 86
ERROR - 2024-05-06 17:33:10 --> Severity: Notice --> Undefined property: Laporan_efisiensi::$M_laporan C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 85
ERROR - 2024-05-06 17:33:10 --> Severity: error --> Exception: Call to a member function add_realisasi() on null C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 85
ERROR - 2024-05-06 17:33:15 --> Severity: Notice --> Undefined property: Laporan_efisiensi::$M_laporan C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 85
ERROR - 2024-05-06 17:33:15 --> Severity: error --> Exception: Call to a member function add_realisasi() on null C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 85
ERROR - 2024-05-06 19:16:42 --> Severity: Warning --> Division by zero C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 108
ERROR - 2024-05-06 19:16:43 --> Severity: Warning --> Division by zero C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 113
ERROR - 2024-05-06 19:25:07 --> Severity: error --> Exception: Unsupported operand types C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 121
ERROR - 2024-05-06 19:25:13 --> Severity: error --> Exception: Unsupported operand types C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 121
ERROR - 2024-05-06 19:29:47 --> Severity: Warning --> Division by zero C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 103
ERROR - 2024-05-06 19:29:48 --> Severity: Warning --> Division by zero C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 118
ERROR - 2024-05-06 19:29:48 --> Severity: Warning --> Division by zero C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 121
ERROR - 2024-05-06 19:29:48 --> Severity: Warning --> Division by zero C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 123
ERROR - 2024-05-06 19:30:31 --> Severity: Warning --> Division by zero C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 103
ERROR - 2024-05-06 19:30:31 --> Severity: Warning --> Division by zero C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 118
ERROR - 2024-05-06 19:30:31 --> Severity: Warning --> Division by zero C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 121
ERROR - 2024-05-06 19:30:31 --> Severity: Warning --> Division by zero C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 123
ERROR - 2024-05-06 23:18:04 --> Severity: Notice --> Undefined property: stdClass::$total_pagu_hps C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 240
ERROR - 2024-05-06 23:18:04 --> Severity: Notice --> Undefined property: stdClass::$total_pagu_hps C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 240
ERROR - 2024-05-06 23:18:04 --> Severity: Notice --> Undefined property: stdClass::$total_pagu_hps C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 240
ERROR - 2024-05-06 23:18:04 --> Severity: Notice --> Undefined property: stdClass::$total_pagu_hps C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 240
ERROR - 2024-05-06 23:18:04 --> Severity: Notice --> Undefined property: stdClass::$total_pagu_hps C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 240
ERROR - 2024-05-06 23:18:04 --> Severity: Notice --> Undefined property: stdClass::$total_pagu_hps C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 240
ERROR - 2024-05-06 23:18:04 --> Severity: Notice --> Undefined property: stdClass::$total_pagu_hps C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 240
ERROR - 2024-05-06 23:18:04 --> Severity: Notice --> Undefined property: stdClass::$total_pagu_hps C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 240
ERROR - 2024-05-06 23:18:04 --> Severity: Notice --> Undefined property: stdClass::$total_pagu_hps C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 240
ERROR - 2024-05-06 23:18:04 --> Severity: Notice --> Undefined property: stdClass::$total_pagu_hps C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 240
ERROR - 2024-05-06 23:18:35 --> Severity: Notice --> Undefined property: stdClass::$total_pagu_hps C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 240
ERROR - 2024-05-06 23:18:35 --> Severity: Notice --> Undefined property: stdClass::$total_pagu_hps C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 240
ERROR - 2024-05-06 23:18:35 --> Severity: Notice --> Undefined property: stdClass::$total_pagu_hps C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 240
ERROR - 2024-05-06 23:18:35 --> Severity: Notice --> Undefined property: stdClass::$total_pagu_hps C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 240
ERROR - 2024-05-06 23:18:35 --> Severity: Notice --> Undefined property: stdClass::$total_pagu_hps C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 240
ERROR - 2024-05-06 23:18:35 --> Severity: Notice --> Undefined property: stdClass::$total_pagu_hps C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 240
ERROR - 2024-05-06 23:18:35 --> Severity: Notice --> Undefined property: stdClass::$total_pagu_hps C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 240
ERROR - 2024-05-06 23:18:35 --> Severity: Notice --> Undefined property: stdClass::$total_pagu_hps C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 240
ERROR - 2024-05-06 23:18:35 --> Severity: Notice --> Undefined property: stdClass::$total_pagu_hps C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 240
ERROR - 2024-05-06 23:18:35 --> Severity: Notice --> Undefined property: stdClass::$total_pagu_hps C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 240
ERROR - 2024-05-06 23:18:49 --> Severity: Notice --> Undefined property: stdClass::$nama_usaha C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 239
ERROR - 2024-05-06 23:18:49 --> Severity: Notice --> Undefined property: stdClass::$total_pagu_hps C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 241
ERROR - 2024-05-06 23:18:49 --> Severity: Notice --> Undefined property: stdClass::$nama_usaha C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 239
ERROR - 2024-05-06 23:18:49 --> Severity: Notice --> Undefined property: stdClass::$total_pagu_hps C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 241
ERROR - 2024-05-06 23:18:49 --> Severity: Notice --> Undefined property: stdClass::$nama_usaha C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 239
ERROR - 2024-05-06 23:18:49 --> Severity: Notice --> Undefined property: stdClass::$total_pagu_hps C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 241
ERROR - 2024-05-06 23:18:49 --> Severity: Notice --> Undefined property: stdClass::$nama_usaha C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 239
ERROR - 2024-05-06 23:18:49 --> Severity: Notice --> Undefined property: stdClass::$total_pagu_hps C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 241
ERROR - 2024-05-06 23:18:49 --> Severity: Notice --> Undefined property: stdClass::$nama_usaha C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 239
ERROR - 2024-05-06 23:18:49 --> Severity: Notice --> Undefined property: stdClass::$total_pagu_hps C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 241
ERROR - 2024-05-06 23:18:49 --> Severity: Notice --> Undefined property: stdClass::$nama_usaha C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 239
ERROR - 2024-05-06 23:18:49 --> Severity: Notice --> Undefined property: stdClass::$total_pagu_hps C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 241
ERROR - 2024-05-06 23:18:49 --> Severity: Notice --> Undefined property: stdClass::$nama_usaha C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 239
ERROR - 2024-05-06 23:18:49 --> Severity: Notice --> Undefined property: stdClass::$total_pagu_hps C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 241
ERROR - 2024-05-06 23:18:49 --> Severity: Notice --> Undefined property: stdClass::$nama_usaha C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 239
ERROR - 2024-05-06 23:18:49 --> Severity: Notice --> Undefined property: stdClass::$total_pagu_hps C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 241
ERROR - 2024-05-06 23:18:49 --> Severity: Notice --> Undefined property: stdClass::$nama_usaha C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 239
ERROR - 2024-05-06 23:18:49 --> Severity: Notice --> Undefined property: stdClass::$total_pagu_hps C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 241
ERROR - 2024-05-06 23:18:49 --> Severity: Notice --> Undefined property: stdClass::$nama_usaha C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 239
ERROR - 2024-05-06 23:18:49 --> Severity: Notice --> Undefined property: stdClass::$total_pagu_hps C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 241
ERROR - 2024-05-06 23:18:54 --> Severity: Notice --> Undefined property: stdClass::$nama_usaha C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 239
ERROR - 2024-05-06 23:18:54 --> Severity: Notice --> Undefined property: stdClass::$total_pagu_hps C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 241
ERROR - 2024-05-06 23:18:54 --> Severity: Notice --> Undefined property: stdClass::$nama_usaha C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 239
ERROR - 2024-05-06 23:18:54 --> Severity: Notice --> Undefined property: stdClass::$total_pagu_hps C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 241
ERROR - 2024-05-06 23:18:54 --> Severity: Notice --> Undefined property: stdClass::$nama_usaha C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 239
ERROR - 2024-05-06 23:18:54 --> Severity: Notice --> Undefined property: stdClass::$total_pagu_hps C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 241
ERROR - 2024-05-06 23:18:54 --> Severity: Notice --> Undefined property: stdClass::$nama_usaha C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 239
ERROR - 2024-05-06 23:18:54 --> Severity: Notice --> Undefined property: stdClass::$total_pagu_hps C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 241
ERROR - 2024-05-06 23:18:54 --> Severity: Notice --> Undefined property: stdClass::$nama_usaha C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 239
ERROR - 2024-05-06 23:18:54 --> Severity: Notice --> Undefined property: stdClass::$total_pagu_hps C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 241
ERROR - 2024-05-06 23:18:54 --> Severity: Notice --> Undefined property: stdClass::$nama_usaha C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 239
ERROR - 2024-05-06 23:18:54 --> Severity: Notice --> Undefined property: stdClass::$total_pagu_hps C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 241
ERROR - 2024-05-06 23:18:54 --> Severity: Notice --> Undefined property: stdClass::$nama_usaha C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 239
ERROR - 2024-05-06 23:18:54 --> Severity: Notice --> Undefined property: stdClass::$total_pagu_hps C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 241
ERROR - 2024-05-06 23:18:54 --> Severity: Notice --> Undefined property: stdClass::$nama_usaha C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 239
ERROR - 2024-05-06 23:18:54 --> Severity: Notice --> Undefined property: stdClass::$total_pagu_hps C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 241
ERROR - 2024-05-06 23:18:54 --> Severity: Notice --> Undefined property: stdClass::$nama_usaha C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 239
ERROR - 2024-05-06 23:18:54 --> Severity: Notice --> Undefined property: stdClass::$total_pagu_hps C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 241
ERROR - 2024-05-06 23:18:54 --> Severity: Notice --> Undefined property: stdClass::$nama_usaha C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 239
ERROR - 2024-05-06 23:18:54 --> Severity: Notice --> Undefined property: stdClass::$total_pagu_hps C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 241
ERROR - 2024-05-06 23:19:49 --> Severity: Notice --> Undefined property: stdClass::$total_pagu_hps C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 240
ERROR - 2024-05-06 23:19:49 --> Severity: Notice --> Undefined property: stdClass::$total_pagu_hps C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 240
ERROR - 2024-05-06 23:19:49 --> Severity: Notice --> Undefined property: stdClass::$total_pagu_hps C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 240
ERROR - 2024-05-06 23:19:49 --> Severity: Notice --> Undefined property: stdClass::$total_pagu_hps C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 240
ERROR - 2024-05-06 23:19:49 --> Severity: Notice --> Undefined property: stdClass::$total_pagu_hps C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 240
ERROR - 2024-05-06 23:19:49 --> Severity: Notice --> Undefined property: stdClass::$total_pagu_hps C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 240
ERROR - 2024-05-06 23:19:49 --> Severity: Notice --> Undefined property: stdClass::$total_pagu_hps C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 240
ERROR - 2024-05-06 23:19:49 --> Severity: Notice --> Undefined property: stdClass::$total_pagu_hps C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 240
ERROR - 2024-05-06 23:19:49 --> Severity: Notice --> Undefined property: stdClass::$total_pagu_hps C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 240
ERROR - 2024-05-06 23:19:49 --> Severity: Notice --> Undefined property: stdClass::$total_pagu_hps C:\laragon\www\jmto-eproc\application\controllers\administrator\Laporan_efisiensi.php 240
