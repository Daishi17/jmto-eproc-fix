<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2024-05-15 04:54:18 --> Unable to connect to the database
ERROR - 2024-05-15 04:54:18 --> Unable to connect to the database
ERROR - 2024-05-15 04:54:18 --> Unable to connect to the database
ERROR - 2024-05-15 11:54:42 --> Severity: Notice --> Trying to get property 'nip' of non-object C:\laragon\www\jmto-eproc\application\libraries\Role_login.php 21
ERROR - 2024-05-15 12:40:33 --> Severity: error --> Exception: Too few arguments to function Daftar_paket::by_id_rup(), 0 passed in C:\laragon\www\jmto-eproc\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\laragon\www\jmto-eproc\application\controllers\panitia\daftar_paket\Daftar_paket.php 388
ERROR - 2024-05-15 20:03:05 --> 404 Page Not Found: administrator/Penilaian_kinerja/print_pemeliharaan_manager
ERROR - 2024-05-15 20:11:46 --> Unable to connect to the database
ERROR - 2024-05-15 21:01:45 --> 404 Page Not Found: administrator/Penilaian_kinerja/print_penilaian_pemeliharaan_total
ERROR - 2024-05-15 21:02:10 --> 404 Page Not Found: administrator/Penilaian_kinerja/print_penilaian_pemeliharaan_total
ERROR - 2024-05-15 21:02:25 --> 404 Page Not Found: administrator/Penilaian_kinerja/print_penilaian_pemeliharaan_total
