<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2024-01-30 16:34:01 --> Unable to connect to the database
