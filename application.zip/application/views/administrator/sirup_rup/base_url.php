<!-- ININ UTNUK BASE URL RUP INDEX -->
<input type="hidden" name="url_back_rup" value="<?= base_url('administrator/sirup_rup') ?>">

<input type="hidden" name="url_get_rup" value="<?= base_url('administrator/sirup_rup/get_rup') ?>">

<!-- by rup -->
<input type="hidden" name="url_by_id_rup" value="<?= base_url('administrator/sirup_rup/by_id_rup/') ?>">

<!-- url_get_rkap_table -->
<input type="hidden" name="url_get_rkap" value="<?= base_url('administrator/sirup_rup/get_rkap') ?>">
<!-- buat rup dari rkap -->
<input type="hidden" name="url_by_id_buat_rup" value="<?= base_url('administrator/sirup_rup/prosess_rkap/') ?>">
<!-- buat_rup form -->
<input type="hidden" name="url_buat_rup" value="<?= base_url('administrator/sirup_rup/buat_rup') ?>">
<!-- ubah_rup form -->
<input type="hidden" name="url_ubah_rup" value="<?= base_url('administrator/sirup_rup/ubah_rup/') ?>">
<!-- ubah_rup form -->
<input type="hidden" name="url_hapus_ruas_rup" value="<?= base_url('administrator/sirup_rup/hapus_ruas_rup/') ?>">


<!-- ubah_ruas form -->
<input type="hidden" name="url_ubah_ruas" value="<?= base_url('administrator/sirup_rup/ubah_ruas') ?>">

<!-- get_ruas_lokasi form -->
<input type="hidden" name="url_get_ruas_lokasi" value="<?= base_url('administrator/sirup_rup/get_ruas_lokasi') ?>">

<!-- url_post_rup -->
<input type="hidden" name="url_post_rup" value="<?= base_url('administrator/sirup_rup/simpan_rup') ?>">

<!-- url_get_kode_rup -->
<input type="hidden" name="url_get_kode_rup" value="<?= base_url('administrator/sirup_rup/get_kode_rup') ?>">

<!-- url_get_departemen -->
<input type="hidden" name="url_get_kode_departemen" value="<?= base_url('administrator/sirup_rup/get_kode_departemen') ?>">
<!-- url_get_kode_section -->
<input type="hidden" name="url_get_kode_section" value="<?= base_url('administrator/sirup_rup/get_kode_section') ?>">
<!-- url_get_kode_jenis_anggaran -->
<input type="hidden" name="url_get_kode_jenis_anggaran" value="<?= base_url('administrator/sirup_rup/get_kode_jenis_anggaran') ?>">

<input type="hidden" name="url_get_section_by_departemen" value="<?= base_url('administrator/sirup_rup/get_section/') ?>">
<input type="hidden" name="url_kabupaten" value="<?= base_url('wilayah/dataKecamatan/') ?>">
<input type="hidden" name="url_provinsi" value="<?= base_url('wilayah/dataKabupaten/') ?>">

<!-- required -->
<input type="hidden" name="url_finaliasi_rup" value="<?= base_url('administrator/sirup_rup/finalisasi_rup') ?>">

<!-- INI UNTUK BAGIAN BUAT PAKET URLNYA -->
<input type="hidden" name="url_get_rup_buat_paket" value="<?= base_url('administrator/sirup_buat_paket/get_rup') ?>">
<!-- by paket -->
<input type="hidden" name="url_by_id_rup_paket" value="<?= base_url('administrator/sirup_buat_paket/by_id_rup/') ?>">
<!-- url tambah panitia -->
<input type="hidden" name="url_tambah_panitia" value="<?= base_url('administrator/sirup_buat_paket/tambah_panitia') ?>">

<!-- url_get_panitia_buat_paket -->
<input type="hidden" name="url_get_panitia_buat_paket" value="<?= base_url('administrator/sirup_buat_paket/get_panitia') ?>">
<!--  url_by_id_url_panitia -->
<input type="hidden" name="url_by_id_url_panitia" value="<?= base_url('administrator/sirup_buat_paket/get_by_id_panitia/') ?>">
<!-- url_hapus_panitia -->
<input type="hidden" name="url_hapus_panitia" value="<?= base_url('administrator/sirup_buat_paket/hapus_panitia/') ?>">
<!-- url_buat_rup_panitia -->
<input type="hidden" name="url_buat_rup_panitia" value="<?= base_url('administrator/sirup_buat_paket/simpan_buat_rup') ?>">

<!-- GET RUP PAKET FINAL -->
<!-- url_get_rup_final -->
<input type="hidden" name="url_get_rup_final" value="<?= base_url('administrator/sirup_buat_paket/get_rup_final') ?>">

<!-- url_finaliasai_paket_final_rup -->
<input type="hidden" name="url_finaliasai_paket_final_rup" value="<?= base_url('administrator/sirup_buat_paket/finalisasi_paket_rup_final/') ?>">


<!-- URL BUAT PAKE -->
<input type="hidden" name="url_get_jenis_dokumen_jadwal" value="<?= base_url('administrator/sirup_buat_paket/get_jenis_jadwal_dokumen') ?>">
<input type="hidden" name="url_get_jenis_jadwal" value="<?= base_url('administrator/sirup_buat_paket/get_jenis_jadwal') ?>">

<!-- url_get_all_ruas -->
<input type="hidden" name="url_get_all_ruas" value="<?= base_url('administrator/sirup_rup/get_ruas_data') ?>">
<input type="hidden" name="url_get_id_ruas_rup" value="<?= base_url('administrator/sirup_rup/get_row_id_ruas_rup/') ?>">


