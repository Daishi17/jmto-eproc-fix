<!-- url_get_rkap_table -->
<input type="hidden" name="url_get_rkap" value="<?= base_url('administrator/sirup_rka/get_rkap')?>">
<!-- url url_get_kode_rkap -->
<input type="hidden" name="url_get_kode_rkap" value="<?= base_url('administrator/sirup_rka/get_kode_rkap')?>">
<!-- url_form_rkap -->
<input type="hidden" name="url_form_rkap" value="<?= base_url('administrator/sirup_rka/crud_rkap')?>">
<!-- url_by_id_rkap -->
<input type="hidden" name="url_by_id_rkap" value="<?= base_url('administrator/sirup_rka/by_id_rkap/')?>">
<!-- url_finalisasi_rkap -->
<input type="hidden" name="url_finalisasi_rkap" value="<?= base_url('administrator/sirup_rka/finalisasi_rkap/')?>">

